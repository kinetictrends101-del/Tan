const STORAGE_KEY = "trudyzAmazingNails.ops.v1";
const AUTH_SESSION_KEY = "trudyzAmazingNails.ops.authenticated";
const AUTH_TOKEN_KEY = "trudyzAmazingNails.ops.token";
const TUTORIAL_KEY_PREFIX = "trudyzAmazingNails.ops.tutorialSeen";
const API_BASE = "/api/payroll";
const PAYSLIP_EMAIL_API = "/api/send-payslips";
const APP_SCHEMA_VERSION = 10;
const WEEKLY_BASE_SALARY = 16000;
const FRONT_DESK_MONTHLY_SALARY = 80000;
const MANAGER_MONTHLY_SALARY = 120000;
const MONTHLY_SALARY_DIVISOR = 4;
const PAYE_RATE = 25;
const PAYE_HIGHER_RATE = 30;
const PAYE_WEEKLY_THRESHOLD_2026 = 36583.85;
const PAYE_HIGHER_RATE_WEEKLY_THRESHOLD = 6000000 / 52;
const NIS_RATE = 3;
const NIS_WEEKLY_CEILING = 5000000 / 52;
const NHT_RATE = 2;
const EDUCATION_TAX_RATE = 2.25;
const state = normalizeState(loadState());
let apiToken = sessionStorage.getItem(AUTH_TOKEN_KEY) || "";
let remoteSaveTimer = null;
let remoteSavePending = false;
let sessionAuthenticated = Boolean(apiToken);
if (state.activeRole === "Staff" && !state.signedInEmployeeId) sessionAuthenticated = false;

const money = new Intl.NumberFormat("en-JM", {
  style: "currency",
  currency: "JMD",
  maximumFractionDigits: 0
});

const shortDate = new Intl.DateTimeFormat("en-JM", {
  month: "short",
  day: "numeric",
  year: "numeric"
});

const views = [...document.querySelectorAll("[data-view]")];
const navButtons = [...document.querySelectorAll("[data-view-target]")];
const authGate = document.querySelector("#authGate");
const authGateForm = document.querySelector("#authGateForm");
const employeeDialog = document.querySelector("#employeeDialog");
const employeeForm = document.querySelector("#employeeForm");
const accessDialog = document.querySelector("#accessDialog");
const accessForm = document.querySelector("#accessForm");
const payslipDialog = document.querySelector("#payslipDialog");
const tutorialDialog = document.querySelector("#tutorialDialog");
let selectedEmployeeId = state.selectedEmployeeId || activeEmployees()[0]?.id || state.employees[0]?.id;
let selectedPayslip = null;
let portalError = "";
let tutorialStepIndex = 0;
let tutorialRole = "Admin";

window.addEventListener("load", () => {
  setTimeout(() => document.body.classList.add("loaded"), 320);
  restoreRemoteSession();
});

function uid(prefix = "id") {
  if (window.crypto?.randomUUID) return `${prefix}-${window.crypto.randomUUID().slice(0, 8)}`;
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

function loadState() {
  try {
    const sessionSaved = JSON.parse(sessionStorage.getItem(STORAGE_KEY));
    if (sessionSaved?.employees?.length) return sessionSaved;
  } catch {
    sessionStorage.removeItem(STORAGE_KEY);
  }
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (saved?.employees?.length) return saved;
  } catch {
    localStorage.removeItem(STORAGE_KEY);
  }
  return defaultState();
}

function normalizeState(savedState) {
  savedState.schemaVersion = APP_SCHEMA_VERSION;
  savedState.settings = savedState.settings || {};
  savedState.settings.baseSalary = Number(savedState.settings.baseSalary || WEEKLY_BASE_SALARY);
  savedState.settings.paye = Number(savedState.settings.paye || PAYE_RATE);
  savedState.settings.payeWeeklyThreshold = Number(savedState.settings.payeWeeklyThreshold || PAYE_WEEKLY_THRESHOLD_2026);
  savedState.settings.payeHigherRate = Number(savedState.settings.payeHigherRate || PAYE_HIGHER_RATE);
  savedState.settings.payeHigherRateWeeklyThreshold = Number(savedState.settings.payeHigherRateWeeklyThreshold || PAYE_HIGHER_RATE_WEEKLY_THRESHOLD);
  savedState.settings.nis = Number(savedState.settings.nis || NIS_RATE);
  savedState.settings.nisWeeklyCeiling = Number(savedState.settings.nisWeeklyCeiling || NIS_WEEKLY_CEILING);
  savedState.settings.nht = Number(savedState.settings.nht || NHT_RATE);
  savedState.settings.educationTax = Number(savedState.settings.educationTax || EDUCATION_TAX_RATE);
  savedState.settings.frontDeskMonthlySalary = Number(savedState.settings.frontDeskMonthlySalary || FRONT_DESK_MONTHLY_SALARY);
  savedState.settings.managerMonthlySalary = Number(savedState.settings.managerMonthlySalary || MANAGER_MONTHLY_SALARY);
  savedState.settings.monthlySalaryDivisor = Number(savedState.settings.monthlySalaryDivisor || MONTHLY_SALARY_DIVISOR);
  savedState.settings.salesBonusThreshold = Number(savedState.settings.salesBonusThreshold || 100000);
  savedState.settings.salesBonusAmount = Number(savedState.settings.salesBonusAmount || 2500);
  savedState.settings.lateDeductionAmount = Number(savedState.settings.lateDeductionAmount || 500);
  savedState.settings.missedPunchDeductionAmount = Number(savedState.settings.missedPunchDeductionAmount || 750);
  savedState.settings.commissionTiers = [
    { id: "below-threshold", name: "Below commission threshold", minSales: 0, maxSales: 19999, serviceRate: 0 },
    { id: "tier-18", name: "18% tier", minSales: 20000, maxSales: 40999, serviceRate: 18 },
    { id: "tier-22", name: "22% tier", minSales: 41000, maxSales: 75999, serviceRate: 22 },
    { id: "tier-25", name: "25% tier", minSales: 76000, maxSales: 100999, serviceRate: 25 },
    { id: "tier-28", name: "28% tier", minSales: 101000, maxSales: null, serviceRate: 28 }
  ];
  savedState.employees = (savedState.employees || []).map((employee) => {
    const role = employee.id === "emp-deandra" && /client experience/i.test(employee.role || "") ? "Front Desk" : employee.role;
    const monthlySalary = Number(employee.monthlySalary || defaultMonthlySalaryForRole(employee.role, savedState.settings) || 0);
    return {
      ...employee,
      role,
      monthlySalary,
      baseSalary: Number(
        monthlySalary
          ? weeklySalaryFromMonthly(monthlySalary, savedState.settings)
          : employee.baseSalary || savedState.settings.baseSalary || WEEKLY_BASE_SALARY
      )
    };
  });
  if (!savedState.employees.some((employee) => isManagerEmployee(employee))) {
    savedState.employees.push({
      id: "emp-manager",
      staffId: "TAN-007",
      name: "Salon Manager",
      role: "Salon Manager",
      status: "Active",
      monthlySalary: Number(savedState.settings.managerMonthlySalary || MANAGER_MONTHLY_SALARY),
      baseSalary: weeklySalaryFromMonthly(savedState.settings.managerMonthlySalary || MANAGER_MONTHLY_SALARY, savedState.settings),
      wage: 0,
      commissionRate: 0,
      email: "manager@trudyzamazingnails.com",
      phone: "+1 876 555 0107",
      emergencyContact: "+1 876 555 1107",
      address: "Kingston, Jamaica",
      hired: "2025-01-01",
      permissions: ["Portal", "Payroll", "Books", "Inventory"]
    });
  }
  if (!Array.isArray(savedState.inventory) || !savedState.inventory.length) {
    savedState.inventory = defaultInventory();
  }
  if (!Array.isArray(savedState.inventoryMovements) || !savedState.inventoryMovements.length) {
    savedState.inventoryMovements = defaultInventoryMovements(savedState.inventory);
  }
  if (!Array.isArray(savedState.inventoryCounts)) savedState.inventoryCounts = [];
  if (!Array.isArray(savedState.bookkeepingEntries)) savedState.bookkeepingEntries = defaultBookkeepingEntries();
  if (!Array.isArray(savedState.dailyClosings)) savedState.dailyClosings = [];
  if (!Array.isArray(savedState.weeklyClosings)) savedState.weeklyClosings = [];
  if (!Array.isArray(savedState.ruleDeductions)) savedState.ruleDeductions = [];
  if (!Array.isArray(savedState.salaryAdvances)) savedState.salaryAdvances = [];
  savedState.payslipDeliveries = savedState.payslipDeliveries || {};
  return savedState;
}

function replaceState(nextState) {
  const normalized = normalizeState(nextState || defaultState());
  Object.keys(state).forEach((key) => delete state[key]);
  Object.assign(state, normalized);
  selectedEmployeeId = state.selectedEmployeeId || activeEmployees()[0]?.id || state.employees[0]?.id;
}

function saveState(options = {}) {
  state.selectedEmployeeId = selectedEmployeeId;
  const serialized = JSON.stringify(state);
  if (apiToken) {
    sessionStorage.setItem(STORAGE_KEY, serialized);
    localStorage.removeItem(STORAGE_KEY);
  } else {
    localStorage.setItem(STORAGE_KEY, serialized);
  }
  if (apiToken && !isStaffMode()) queueRemoteStateSave(options);
}

async function apiRequest(action, payload = {}) {
  const headers = { "Content-Type": "application/json" };
  if (apiToken) headers.Authorization = `Bearer ${apiToken}`;
  const response = await fetch(API_BASE, {
    method: "POST",
    headers,
    body: JSON.stringify({ action, ...payload })
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || result.ok === false) {
    throw new Error(result.message || "Payroll server request failed.");
  }
  return result;
}

function queueRemoteStateSave(options = {}) {
  if (!apiToken || isStaffMode()) return;
  const send = async () => {
    remoteSavePending = true;
    try {
      await apiRequest("saveState", {
        state,
        backupReason: options.backupReason || ""
      });
      remoteSavePending = false;
    } catch (error) {
      console.warn("Remote payroll save failed", error);
    }
  };
  if (options.backupReason) {
    clearTimeout(remoteSaveTimer);
    send();
    return;
  }
  clearTimeout(remoteSaveTimer);
  remoteSaveTimer = setTimeout(send, 700);
}

async function restoreRemoteSession() {
  if (!apiToken) return;
  try {
    const result = await apiRequest("loadState");
    if (result.state) replaceState(result.state);
    if (result.session?.role) {
      state.activeRole = result.session.role;
      state.signedInEmployeeId = result.session.employeeId || state.signedInEmployeeId || null;
    }
    setAuthenticated(true, apiToken);
    renderAll();
    openView(signedInHomeView(state.activeRole));
  } catch (error) {
    console.warn("Could not restore payroll session", error);
    signOut("Remote session expired.");
  }
}

function defaultState() {
  return {
    schemaVersion: APP_SCHEMA_VERSION,
    selectedEmployeeId: "emp-charmaine",
    signedInEmployeeId: null,
    activeRole: "Admin",
    payPeriodStart: "2026-05-12",
    saturdayRotation: ["emp-charmaine", "emp-melisa", "emp-movesha", "emp-derina", "emp-shaunakay", "emp-deandra"],
    settings: {
      baseSalary: WEEKLY_BASE_SALARY,
      paye: PAYE_RATE,
      payeWeeklyThreshold: PAYE_WEEKLY_THRESHOLD_2026,
      payeHigherRate: PAYE_HIGHER_RATE,
      payeHigherRateWeeklyThreshold: PAYE_HIGHER_RATE_WEEKLY_THRESHOLD,
      nis: NIS_RATE,
      nisWeeklyCeiling: NIS_WEEKLY_CEILING,
      nht: NHT_RATE,
      educationTax: EDUCATION_TAX_RATE,
      overtimeAfter: 40,
      overtimeMultiplier: 1.5,
      frontDeskMonthlySalary: FRONT_DESK_MONTHLY_SALARY,
      managerMonthlySalary: MANAGER_MONTHLY_SALARY,
      monthlySalaryDivisor: MONTHLY_SALARY_DIVISOR,
      lunchDeductionMinutes: 35,
      salesBonusThreshold: 100000,
      salesBonusAmount: 2500,
      lateDeductionAmount: 500,
      missedPunchDeductionAmount: 750,
      commissionTiers: [
        { id: "below-threshold", name: "Below commission threshold", minSales: 0, maxSales: 19999, serviceRate: 0 },
        { id: "tier-18", name: "18% tier", minSales: 20000, maxSales: 40999, serviceRate: 18 },
        { id: "tier-22", name: "22% tier", minSales: 41000, maxSales: 75999, serviceRate: 22 },
        { id: "tier-25", name: "25% tier", minSales: 76000, maxSales: 100999, serviceRate: 25 },
        { id: "tier-28", name: "28% tier", minSales: 101000, maxSales: null, serviceRate: 28 }
      ]
    },
    serviceCatalog: defaultServiceCatalog(),
    adjustments: {
      "emp-charmaine": { bonus: 5000, deduction: 0 },
      "emp-melisa": { bonus: 3500, deduction: 0 },
      "emp-movesha": { bonus: 3000, deduction: 800 },
      "emp-derina": { bonus: 2500, deduction: 0 },
      "emp-shaunakay": { bonus: 2500, deduction: 0 },
      "emp-deandra": { bonus: 1500, deduction: 0 }
    },
    employees: [
      {
        id: "emp-charmaine",
        staffId: "TAN-001",
        name: "Charmaine Mason",
        role: "Senior Nail Technician",
        status: "Active",
        baseSalary: WEEKLY_BASE_SALARY,
        wage: 1900,
        commissionRate: 18,
        email: "charmaine@trudyzamazingnails.com",
        phone: "+1 876 555 0101",
        emergencyContact: "+1 876 555 1101",
        address: "Kingston, Jamaica",
        hired: "2024-02-01",
        permissions: ["Portal"]
      },
      {
        id: "emp-melisa",
        staffId: "TAN-002",
        name: "Melisa Brown",
        role: "Nail Technician",
        status: "Active",
        baseSalary: WEEKLY_BASE_SALARY,
        wage: 1700,
        commissionRate: 16,
        email: "melisa@trudyzamazingnails.com",
        phone: "+1 876 555 0102",
        emergencyContact: "+1 876 555 1102",
        address: "Kingston, Jamaica",
        hired: "2024-08-12",
        permissions: ["Portal"]
      },
      {
        id: "emp-movesha",
        staffId: "TAN-003",
        name: "Movesha Drummond",
        role: "Nail Technician",
        status: "Active",
        baseSalary: WEEKLY_BASE_SALARY,
        wage: 1600,
        commissionRate: 16,
        email: "movesha@trudyzamazingnails.com",
        phone: "+1 876 555 0103",
        emergencyContact: "+1 876 555 1103",
        address: "Kingston, Jamaica",
        hired: "2025-01-20",
        permissions: ["Portal"]
      },
      {
        id: "emp-derina",
        staffId: "TAN-004",
        name: "Derina Gooden",
        role: "Nail Technician",
        status: "Active",
        baseSalary: WEEKLY_BASE_SALARY,
        wage: 1650,
        commissionRate: 16,
        email: "derina@trudyzamazingnails.com",
        phone: "+1 876 555 0104",
        emergencyContact: "+1 876 555 1104",
        address: "Kingston, Jamaica",
        hired: "2025-05-03",
        permissions: ["Portal"]
      },
      {
        id: "emp-shaunakay",
        staffId: "TAN-005",
        name: "Shaunakay Salmon",
        role: "Nail Technician",
        status: "Active",
        baseSalary: WEEKLY_BASE_SALARY,
        wage: 1650,
        commissionRate: 16,
        email: "shaunakay@trudyzamazingnails.com",
        phone: "+1 876 555 0105",
        emergencyContact: "+1 876 555 1105",
        address: "Kingston, Jamaica",
        hired: "2025-07-15",
        permissions: ["Portal"]
      },
      {
        id: "emp-deandra",
        staffId: "TAN-006",
        name: "Deandra Irving",
        role: "Front Desk",
        status: "Active",
        monthlySalary: FRONT_DESK_MONTHLY_SALARY,
        baseSalary: weeklySalaryFromMonthly(FRONT_DESK_MONTHLY_SALARY),
        wage: 1500,
        commissionRate: 6,
        email: "deandra@trudyzamazingnails.com",
        phone: "+1 876 555 0106",
        emergencyContact: "+1 876 555 1106",
        address: "Kingston, Jamaica",
        hired: "2025-09-02",
        permissions: ["Portal"]
      },
      {
        id: "emp-manager",
        staffId: "TAN-007",
        name: "Salon Manager",
        role: "Salon Manager",
        status: "Active",
        monthlySalary: MANAGER_MONTHLY_SALARY,
        baseSalary: weeklySalaryFromMonthly(MANAGER_MONTHLY_SALARY),
        wage: 0,
        commissionRate: 0,
        email: "manager@trudyzamazingnails.com",
        phone: "+1 876 555 0107",
        emergencyContact: "+1 876 555 1107",
        address: "Kingston, Jamaica",
        hired: "2025-01-01",
        permissions: ["Portal", "Payroll", "Books", "Inventory"]
      }
    ],
    attendance: [
      log("emp-charmaine", "2026-05-12", "09:48", "13:04", "13:41", "19:22"),
      log("emp-charmaine", "2026-05-13", "09:52", "13:15", "13:51", "19:18"),
      log("emp-charmaine", "2026-05-14", "09:47", "13:06", "13:42", "19:30"),
      log("emp-charmaine", "2026-05-15", "09:55", "13:00", "13:36", "19:10"),
      log("emp-charmaine", "2026-05-16", "09:50", "13:22", "13:59", "20:12"),
      log("emp-melisa", "2026-05-12", "10:04", "13:10", "13:46", "19:04"),
      log("emp-melisa", "2026-05-13", "10:01", "13:08", "13:43", "19:06"),
      log("emp-melisa", "2026-05-14", "10:08", "13:12", "13:48", "19:08"),
      log("emp-melisa", "2026-05-15", "09:58", "13:04", "13:39", "19:22"),
      log("emp-melisa", "2026-05-16", "09:54", "13:20", "13:56", "20:16"),
      log("emp-movesha", "2026-05-12", "10:11", "13:08", "13:44", "18:58"),
      log("emp-movesha", "2026-05-13", "10:03", "13:15", "13:50", "19:03"),
      log("emp-movesha", "2026-05-14", "10:21", null, null, "19:04"),
      log("emp-movesha", "2026-05-15", "09:59", "13:01", "13:37", "19:00"),
      log("emp-movesha", "2026-05-16", "10:07", "13:33", "14:08", "20:02"),
      log("emp-derina", "2026-05-12", "09:56", "13:12", "13:47", "19:02"),
      log("emp-derina", "2026-05-13", "10:10", "13:08", "13:43", "18:55"),
      log("emp-derina", "2026-05-14", "10:02", "13:16", "13:51", "19:05"),
      log("emp-derina", "2026-05-15", "10:06", "13:05", "13:40", "19:06"),
      log("emp-derina", "2026-05-16", "10:12", "13:28", null, null),
      log("emp-shaunakay", "2026-05-12", "10:00", "13:05", "13:40", "18:38"),
      log("emp-shaunakay", "2026-05-13", "09:58", "13:07", "13:42", "18:42"),
      log("emp-shaunakay", "2026-05-14", "10:05", "13:13", "13:49", "18:45"),
      log("emp-shaunakay", "2026-05-15", "10:00", "13:09", "13:44", "18:50"),
      log("emp-deandra", "2026-05-12", "10:02", "13:10", "13:45", "19:00"),
      log("emp-deandra", "2026-05-13", "10:00", "13:09", "13:44", "19:02"),
      log("emp-deandra", "2026-05-14", "10:04", "13:15", "13:50", "19:01"),
      log("emp-deandra", "2026-05-15", "10:09", "13:08", "13:43", "19:03")
    ],
    services: [
      sale("emp-charmaine", "2026-05-12", "Gel Pedicure", 6500, 1200),
      sale("emp-movesha", "2026-05-12", "Gel X (Medium)", 9000, 1200),
      sale("emp-melisa", "2026-05-12", "Tips W/ Gel (Long)", 10500, 2200),
      sale("emp-charmaine", "2026-05-13", "Tips W/ Gel (Medium)", 9500, 1500),
      sale("emp-deandra", "2026-05-13", "Regular Pedicure", 5500, 900),
      sale("emp-derina", "2026-05-14", "Gel Polish", 4000, 800),
      sale("emp-melisa", "2026-05-14", "Gel X (Long)", 10000, 1800),
      sale("emp-shaunakay", "2026-05-15", "Tips W/ Regular Polish (Short)", 6500, 1100),
      sale("emp-movesha", "2026-05-15", "Tips W/ Gel (Short)", 8500, 1300),
      sale("emp-charmaine", "2026-05-16", "Gel X (Short)", 8000, 1400),
      sale("emp-derina", "2026-05-16", "Regular Pedicure", 3000, 600)
    ],
    schedule: [
      shift("emp-charmaine", "2026-05-12", "10:00", "19:00", "Senior Tech"),
      shift("emp-melisa", "2026-05-12", "10:00", "19:00", "Tech"),
      shift("emp-movesha", "2026-05-12", "10:00", "19:00", "Tech"),
      shift("emp-deandra", "2026-05-12", "10:00", "19:00", "Client Experience"),
      shift("emp-charmaine", "2026-05-13", "10:00", "19:00", "Senior Tech"),
      shift("emp-melisa", "2026-05-13", "10:00", "19:00", "Tech"),
      shift("emp-movesha", "2026-05-13", "10:00", "19:00", "Tech"),
      shift("emp-deandra", "2026-05-13", "10:00", "19:00", "Client Experience"),
      shift("emp-shaunakay", "2026-05-13", "10:00", "18:30", "Tech"),
      shift("emp-charmaine", "2026-05-14", "10:00", "19:00", "Senior Tech"),
      shift("emp-melisa", "2026-05-14", "10:00", "19:00", "Tech"),
      shift("emp-derina", "2026-05-14", "10:00", "19:00", "Tech"),
      shift("emp-deandra", "2026-05-14", "10:00", "19:00", "Client Experience"),
      shift("emp-shaunakay", "2026-05-14", "10:00", "18:30", "Tech"),
      shift("emp-charmaine", "2026-05-15", "10:00", "19:00", "Senior Tech"),
      shift("emp-movesha", "2026-05-15", "10:00", "19:00", "Tech"),
      shift("emp-derina", "2026-05-15", "10:00", "19:00", "Tech"),
      shift("emp-deandra", "2026-05-15", "10:00", "19:00", "Client Experience"),
      shift("emp-charmaine", "2026-05-16", "10:00", "20:00", "Saturday Lead"),
      shift("emp-melisa", "2026-05-16", "10:00", "20:00", "Tech"),
      shift("emp-movesha", "2026-05-16", "10:00", "20:00", "Tech"),
      shift("emp-derina", "2026-05-16", "10:00", "20:00", "Tech")
    ],
    ...defaultInventoryBundle(),
    bookkeepingEntries: defaultBookkeepingEntries(),
    dailyClosings: [],
    weeklyClosings: [],
    ruleDeductions: [],
    salaryAdvances: [],
    payrollRuns: [],
    payslipDeliveries: {},
    activity: [
      audit("System", "Payroll rates initialized for Jamaican deductions."),
      audit("Manager", "Saturday rotation reviewed for week of May 12."),
      audit("Admin", "Secure payroll register prepared.")
    ]
  };
}

function log(employeeId, date, clockIn, lunchStart, lunchEnd, clockOut) {
  return { id: uid("log"), employeeId, date, clockIn, lunchStart, lunchEnd, clockOut, override: false, note: "" };
}

function serviceItem(name, price) {
  return { id: uid("svc"), name, price, active: true };
}

function defaultServiceCatalog() {
  return [
    serviceItem("Gel Pedicure", 6500),
    serviceItem("Regular Pedicure", 5500),
    serviceItem("Gel Polish", 4000),
    serviceItem("Regular Pedicure", 3000),
    serviceItem("Gel X (Short)", 8000),
    serviceItem("Gel X (Medium)", 9000),
    serviceItem("Gel X (Long)", 10000),
    serviceItem("Tips W/ Gel (Short)", 8500),
    serviceItem("Tips W/ Gel (Medium)", 9500),
    serviceItem("Tips W/ Gel (Long)", 10500),
    serviceItem("Tips W/ Regular Polish (Short)", 6500)
  ];
}

function inventoryItem(name, category, stockOnHand, unit, unitCost, reorderLevel, supplier, location, secured = false) {
  return {
    id: uid("inv"),
    name,
    category,
    stockOnHand,
    unit,
    unitCost,
    reorderLevel,
    supplier,
    location,
    secured,
    status: "Active",
    lastPurchase: "2026-05-12"
  };
}

function inventoryMovement(itemId, type, quantity, unitCost, employeeId = "", reference = "", note = "", date = "2026-05-12", extras = {}) {
  return {
    id: uid("mov"),
    itemId,
    type,
    date,
    at: new Date().toISOString(),
    quantity: round(quantity),
    unitCost: round(unitCost),
    employeeId,
    reference,
    note,
    ...extras
  };
}

function defaultInventory() {
  return [
    inventoryItem("Gel polish core collection", "Color & Gel", 42, "bottles", 1850, 12, "Beauty Supply Jamaica", "Locked color wall", true),
    inventoryItem("Builder gel refill jars", "Gel System", 18, "jars", 2400, 6, "Pro Nail Distributor", "Back bar cabinet", true),
    inventoryItem("Gel X nail tips assorted", "Extensions", 26, "boxes", 2800, 8, "Pro Nail Distributor", "Extension drawer", true),
    inventoryItem("Acetone professional", "Chemicals", 12, "gallons", 1500, 4, "Salon Wholesale", "Chemical cabinet", false),
    inventoryItem("Disposable nail files", "Disposables", 180, "pieces", 85, 60, "Salon Wholesale", "Sanitation station", false),
    inventoryItem("Pedicure liners", "Pedicure Supplies", 95, "pieces", 120, 35, "Spa Supply Co.", "Pedicure station", false),
    inventoryItem("Cuticle oil", "Aftercare", 24, "bottles", 900, 10, "Beauty Supply Jamaica", "Retail-ready drawer", true),
    inventoryItem("Sterilization pouches", "Sanitation", 140, "pouches", 65, 50, "Medical Supply JA", "Sterilization room", false)
  ];
}

function defaultInventoryMovements(items = defaultInventory()) {
  return items.map((item) => inventoryMovement(
    item.id,
    "Opening Stock",
    item.stockOnHand,
    item.unitCost,
    "",
    item.supplier,
    "Initial protected stock register.",
    item.lastPurchase
  ));
}

function defaultInventoryBundle() {
  const inventory = defaultInventory();
  return {
    inventory,
    inventoryMovements: defaultInventoryMovements(inventory),
    inventoryCounts: []
  };
}

function bookEntry(date, type, channel, category, amount, reference, note, actor = "Front Desk") {
  return {
    id: uid("book"),
    date,
    type,
    channel,
    category,
    amount,
    reference,
    note,
    actor,
    at: new Date().toISOString()
  };
}

function defaultBookkeepingEntries() {
  return [
    bookEntry("2026-05-12", "Sale Receipt", "NCB POS Machine", "Service sales", 15500, "NCB-0512", "Card receipts matched to service ledger."),
    bookEntry("2026-05-12", "Sale Receipt", "Cash", "Service sales", 6500, "CASH-0512", "Cash service receipts."),
    bookEntry("2026-05-13", "Sale Receipt", "FYGARO", "Service sales", 15000, "FYG-0513", "Online invoice receipts."),
    bookEntry("2026-05-14", "Sale Receipt", "NCB POS Machine", "Service sales", 14000, "NCB-0514", "POS batch settlement."),
    bookEntry("2026-05-15", "Sale Receipt", "Cash", "Service sales", 15000, "CASH-0515", "Front desk cash close."),
    bookEntry("2026-05-16", "Sale Receipt", "Bank Transfer", "Service sales", 11000, "TRF-0516", "Client transfers received."),
    bookEntry("2026-05-14", "Expense", "Cash", "Supplies", 4200, "EXP-0514", "Disposable files and sanitation supplies."),
    bookEntry("2026-05-16", "Deposit", "Cash", "Bank deposit", 12000, "DEP-0516", "Cash deposited after Saturday close."),
    bookEntry("2026-05-16", "Transfer", "FYGARO", "FYGARO transfer", 15000, "FYG-SETTLE", "FYGARO payout transferred to business account.")
  ];
}

function sale(employeeId, date, service, amount, tips, extras = {}) {
  return { id: uid("sale"), employeeId, date, service, amount, tips, ...extras };
}

function shift(employeeId, date, start, end, role) {
  return { id: uid("shift"), employeeId, date, start, end, role };
}

function audit(actor, message) {
  return { id: uid("audit"), actor, message, at: new Date().toISOString() };
}

function activeEmployees() {
  return state.employees.filter((employee) => employee.status === "Active");
}

function isStaffMode() {
  return state.activeRole === "Staff";
}

function isFrontDeskMode() {
  return state.activeRole === "Front Desk";
}

function isManagerMode() {
  return state.activeRole === "Manager";
}

function isAdminMode() {
  return state.activeRole === "Admin";
}

function isLimitedMode() {
  return isStaffMode() || isFrontDeskMode();
}

function canEdit() {
  return isAdminMode() || isManagerMode();
}

function canManageOperations() {
  return isAdminMode() || isManagerMode();
}

function canManageAttendance() {
  return canManageOperations();
}

function canUseTimeClock() {
  return canManageOperations() || (isStaffMode() && Boolean(signedInEmployee()));
}

function canManageSchedule() {
  return canManageOperations();
}

function canEnterServices() {
  return isAdminMode() || isManagerMode() || isFrontDeskMode();
}

function canEnterBookkeeping() {
  return isAdminMode() || isManagerMode() || isFrontDeskMode();
}

function signedInEmployee() {
  return employeeById(state.signedInEmployeeId);
}

function isAuthenticated() {
  return sessionAuthenticated;
}

function setAuthenticated(value, token = apiToken) {
  sessionAuthenticated = value;
  if (value) {
    sessionStorage.setItem(AUTH_SESSION_KEY, "true");
    if (token) {
      apiToken = token;
      sessionStorage.setItem(AUTH_TOKEN_KEY, token);
    }
  } else {
    apiToken = "";
    sessionStorage.removeItem(AUTH_SESSION_KEY);
    sessionStorage.removeItem(AUTH_TOKEN_KEY);
  }
}

function signedInHomeView(role = state.activeRole) {
  if (role === "Front Desk") return "bookkeeping";
  if (role === "Staff") return "portal";
  return "dashboard";
}

function completeSignIn(role, employee = null, actor = role, nextState = null, token = "") {
  if (nextState) replaceState(nextState);
  state.activeRole = role;
  state.signedInEmployeeId = employee?.id || null;
  if (employee) selectedEmployeeId = employee.id;
  portalError = "";
  setAuthenticated(true, token || apiToken);
  state.activity.unshift(audit("Security", `${actor} signed in.`));
  saveState();
  renderAll();
  openView(signedInHomeView(role));
  maybeOpenFirstLoginTutorial(role, employee);
}

async function authenticateLoginCode(value) {
  const code = value.trim();
  if (!code) return null;
  const result = await apiRequest("login", { code, seedState: state });
  if (result.state) replaceState(result.state);
  if (result.token) {
    apiToken = result.token;
    sessionStorage.setItem(AUTH_TOKEN_KEY, result.token);
  }
  const employee = result.employeeId ? employeeById(result.employeeId) : null;
  return {
    role: result.role,
    employee,
    actor: result.actor || employee?.name || result.role,
    token: result.token,
    state: result.state
  };
}

function signOut(message = "Session signed out.") {
  const hadRemoteSession = Boolean(apiToken);
  setAuthenticated(false);
  state.activeRole = "Staff";
  state.signedInEmployeeId = null;
  portalError = "";
  const authLoginCode = document.querySelector("#authLoginCode");
  const accessCode = document.querySelector("#accessCode");
  if (authLoginCode) authLoginCode.value = "";
  if (accessCode) accessCode.value = "";
  state.activity.unshift(audit("Security", message));
  if (hadRemoteSession) {
    sessionStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(STORAGE_KEY);
  } else {
    saveState();
  }
  renderAll();
}

function guardStaffMutation() {
  if (canEdit()) return false;
  portalError = "This access level cannot edit protected business settings. Use the owner unlock for Admin access.";
  openView(isFrontDeskMode() ? "bookkeeping" : isManagerMode() ? "dashboard" : "portal");
  renderPortal();
  renderServices();
  refreshIcons();
  return true;
}

function guardManagerMutation() {
  if (canManageOperations()) return false;
  portalError = "This account cannot use manager operations. Please sign in as Manager or Admin.";
  openView(isFrontDeskMode() ? "bookkeeping" : "portal");
  renderPortal();
  renderServices();
  refreshIcons();
  return true;
}

function guardServiceEntry() {
  if (canEnterServices()) return false;
  portalError = "Staff portal access is read-only. Please contact management to record service entries.";
  openView("portal");
  renderPortal();
  refreshIcons();
  return true;
}

function guardBookkeepingEntry() {
  if (canEnterBookkeeping()) return false;
  portalError = "Bookkeeping access is limited to front desk, manager, and owner accounts.";
  openView(isStaffMode() ? "portal" : "dashboard");
  renderPortal();
  refreshIcons();
  return true;
}

function employeeById(id) {
  return state.employees.find((employee) => employee.id === id);
}

function periodDates() {
  const start = parseDate(state.payPeriodStart);
  return Array.from({ length: 5 }, (_, index) => toIsoDate(addDays(start, index)));
}

function periodEnd() {
  return periodDates().at(-1);
}

function paymentDate() {
  return toIsoDate(addDays(parseDate(periodEnd()), 3));
}

function parseDate(value) {
  return new Date(`${value}T00:00:00`);
}

function addDays(date, days) {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

function toIsoDate(date) {
  return date.toISOString().slice(0, 10);
}

function displayDate(value) {
  if (!value) return "Pending";
  return shortDate.format(parseDate(value));
}

function minutes(value) {
  if (!value) return null;
  const [hours, mins] = value.split(":").map(Number);
  return hours * 60 + mins;
}

function formatTime(value) {
  if (!value) return "Missing";
  const total = minutes(value);
  const hours24 = Math.floor(total / 60);
  const mins = total % 60;
  const suffix = hours24 >= 12 ? "PM" : "AM";
  const hours12 = hours24 % 12 || 12;
  return `${hours12}:${String(mins).padStart(2, "0")} ${suffix}`;
}

function round(value) {
  return Math.round((Number(value) || 0) * 100) / 100;
}

function formatHours(value) {
  return `${round(value).toFixed(2)}h`;
}

function formatMoney(value) {
  return money.format(Math.round(Number(value) || 0));
}

function isFrontDeskEmployee(employeeOrRole) {
  const role = typeof employeeOrRole === "string" ? employeeOrRole : employeeOrRole?.role;
  return /front\s*desk|client experience/i.test(String(role || ""));
}

function isManagerEmployee(employeeOrRole) {
  const role = typeof employeeOrRole === "string" ? employeeOrRole : employeeOrRole?.role;
  return /manager|owner/i.test(String(role || ""));
}

function defaultMonthlySalaryForRole(role, settings = state?.settings) {
  if (isFrontDeskEmployee(role)) return Number(settings?.frontDeskMonthlySalary || FRONT_DESK_MONTHLY_SALARY);
  if (isManagerEmployee(role)) return Number(settings?.managerMonthlySalary || MANAGER_MONTHLY_SALARY);
  return 0;
}

function weeklySalaryFromMonthly(monthlySalary, settings = null) {
  const monthly = Number(monthlySalary || 0);
  if (!monthly) return 0;
  return round(monthly / Number(settings?.monthlySalaryDivisor || MONTHLY_SALARY_DIVISOR));
}

function salaryModeFor(employee) {
  const monthlySalary = Number(employee?.monthlySalary || defaultMonthlySalaryForRole(employee?.role) || 0);
  if (!monthlySalary) return { type: "weekly", monthlySalary: 0, weeklySalary: Number(employee?.baseSalary || state.settings.baseSalary || WEEKLY_BASE_SALARY) };
  return {
    type: "monthly-paid-weekly",
    monthlySalary,
    weeklySalary: weeklySalaryFromMonthly(monthlySalary)
  };
}

function baseSalaryFor(employee) {
  return Number(salaryModeFor(employee).weeklySalary || state.settings.baseSalary || WEEKLY_BASE_SALARY);
}

function salaryLabelFor(employee) {
  const salary = salaryModeFor(employee);
  if (salary.type === "monthly-paid-weekly") {
    return `${formatMoney(salary.monthlySalary)}/month -> ${formatMoney(salary.weeklySalary)}/week`;
  }
  return `${formatMoney(salary.weeklySalary)}/week`;
}

function overtimeHourlyRateFor(employee) {
  return round(baseSalaryFor(employee) / Number(state.settings.overtimeAfter || 40));
}

function commissionTiers() {
  return state.settings.commissionTiers || [
    { id: "below-threshold", name: "Below commission threshold", minSales: 0, maxSales: 19999, serviceRate: 0 },
    { id: "tier-18", name: "18% tier", minSales: 20000, maxSales: 40999, serviceRate: 18 },
    { id: "tier-22", name: "22% tier", minSales: 41000, maxSales: 75999, serviceRate: 22 },
    { id: "tier-25", name: "25% tier", minSales: 76000, maxSales: 100999, serviceRate: 25 },
    { id: "tier-28", name: "28% tier", minSales: 101000, maxSales: null, serviceRate: 28 }
  ];
}

function commissionTierForWeeklySales(weeklySales) {
  const amount = Number(weeklySales || 0);
  return commissionTiers().find((tier) => {
    const min = Number(tier.minSales || 0);
    const max = tier.maxSales === null || tier.maxSales === undefined ? Infinity : Number(tier.maxSales);
    return amount >= min && amount <= max;
  }) || commissionTiers()[0];
}

function currentWeeklyServiceRevenue(employeeId) {
  return currentPeriodServices(employeeId).reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
}

function commissionTierForEmployeeWeek(employeeId) {
  return commissionTierForWeeklySales(currentWeeklyServiceRevenue(employeeId));
}

function commissionRangeLabel(tier) {
  if (!tier) return "";
  if (tier.maxSales === null || tier.maxSales === undefined) return `${formatMoney(tier.minSales)}+`;
  return `${formatMoney(tier.minSales)} - ${formatMoney(tier.maxSales)}`;
}

function serviceCatalog() {
  if (!state.serviceCatalog?.length) state.serviceCatalog = defaultServiceCatalog();
  return state.serviceCatalog;
}

function activeServiceCatalog() {
  return serviceCatalog().filter((item) => item.active !== false);
}

function catalogItemById(id) {
  return serviceCatalog().find((item) => item.id === id);
}

function serviceCatalogLabel(item) {
  return `${item.name} - ${formatMoney(item.price)}`;
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "\"": "&quot;",
    "'": "&#039;"
  })[char]);
}

function getBusinessHours(date) {
  const day = parseDate(date).getDay();
  if (day >= 2 && day <= 5) return { open: "10:00", close: "19:00", label: "10:00 AM-7:00 PM" };
  if (day === 6) return { open: "10:00", close: "20:00", label: "10:00 AM-8:00 PM" };
  return { open: null, close: null, label: "Closed" };
}

function lunchMinutesFor(logEntry) {
  if (logEntry.lunchStart && logEntry.lunchEnd) {
    return Math.max(0, minutes(logEntry.lunchEnd) - minutes(logEntry.lunchStart));
  }
  if (logEntry.clockIn && logEntry.clockOut) return state.settings.lunchDeductionMinutes;
  return 0;
}

function paidMinutesFor(logEntry) {
  if (!logEntry.clockIn || !logEntry.clockOut) return 0;
  return Math.max(0, minutes(logEntry.clockOut) - minutes(logEntry.clockIn) - lunchMinutesFor(logEntry));
}

function paidHoursFor(logEntry) {
  return round(paidMinutesFor(logEntry) / 60);
}

function attendanceAlert(logEntry) {
  const hours = getBusinessHours(logEntry.date);
  const alerts = [];
  if (!logEntry.clockIn || !logEntry.clockOut) alerts.push("Missed punch");
  if (logEntry.clockIn && hours.open && minutes(logEntry.clockIn) > minutes(hours.open) + 5) alerts.push("Late");
  if (logEntry.lunchStart && !logEntry.lunchEnd) alerts.push("Lunch open");
  if (logEntry.override) alerts.push("Override");
  return alerts;
}

function currentPeriodLogs(employeeId) {
  const dates = new Set(periodDates());
  return state.attendance.filter((entry) => entry.employeeId === employeeId && dates.has(entry.date));
}

function currentPeriodServices(employeeId) {
  const dates = new Set(periodDates());
  return state.services.filter((entry) => entry.employeeId === employeeId && dates.has(entry.date));
}

function serviceCommission(serviceEntry, employee) {
  const tier = commissionTierForEmployeeWeek(employee?.id);
  return round(Number(serviceEntry.amount || 0) * tier.serviceRate / 100);
}

function weeklyStats(employeeId) {
  const logs = currentPeriodLogs(employeeId);
  const services = currentPeriodServices(employeeId);
  const paidHours = round(logs.reduce((sum, entry) => sum + paidHoursFor(entry), 0));
  const lunchDeductionHours = round(logs.reduce((sum, entry) => sum + lunchMinutesFor(entry), 0) / 60);
  const serviceRevenue = services.reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
  const tips = services.reduce((sum, entry) => sum + Number(entry.tips || 0), 0);
  const commissionTier = commissionTierForWeeklySales(serviceRevenue);
  const commission = round(serviceRevenue * commissionTier.serviceRate / 100);
  const missed = logs.filter((entry) => attendanceAlert(entry).includes("Missed punch")).length;
  const late = logs.filter((entry) => attendanceAlert(entry).includes("Late")).length;
  return { logs, services, paidHours, lunchDeductionHours, serviceRevenue, tips, commission, commissionTier, missed, late };
}

function currentPeriodRuleDeductions(employeeId) {
  const dates = new Set(periodDates());
  return (state.ruleDeductions || []).filter((entry) => entry.employeeId === employeeId && dates.has(entry.date));
}

function currentPeriodSalaryAdvances(employeeId) {
  const dates = new Set(periodDates());
  return (state.salaryAdvances || []).filter((entry) => entry.employeeId === employeeId && dates.has(entry.date));
}

function salesBonusFor(stats) {
  const threshold = Number(state.settings.salesBonusThreshold || 0);
  if (!threshold || Number(stats.serviceRevenue || 0) < threshold) return 0;
  return Number(state.settings.salesBonusAmount || 0);
}

function calculateStatutoryDeductions(gross) {
  const grossPay = Number(gross || 0);
  const nisCeiling = Number(state.settings.nisWeeklyCeiling || NIS_WEEKLY_CEILING);
  const nis = Math.min(grossPay, nisCeiling) * Number(state.settings.nis || 0) / 100;
  const nht = grossPay * Number(state.settings.nht || 0) / 100;
  const educationTax = Math.max(0, grossPay - nis) * Number(state.settings.educationTax || 0) / 100;
  const payeThreshold = Number(state.settings.payeWeeklyThreshold || 0);
  const higherRateThreshold = Number(state.settings.payeHigherRateWeeklyThreshold || Infinity);
  const incomeAfterNis = Math.max(0, grossPay - nis);
  const payeChargeableIncome = Math.max(0, incomeAfterNis - payeThreshold);
  const higherBand = Math.max(0, incomeAfterNis - higherRateThreshold);
  const basicBand = Math.max(0, payeChargeableIncome - higherBand);
  const paye = (basicBand * Number(state.settings.paye || 0) / 100) + (higherBand * Number(state.settings.payeHigherRate || state.settings.paye || 0) / 100);
  return {
    paye: round(paye),
    nis: round(nis),
    nht: round(nht),
    educationTax: round(educationTax),
    payeChargeableIncome: round(payeChargeableIncome),
    nisCeiling: round(nisCeiling),
    payeThreshold: round(payeThreshold)
  };
}

function calculatePayrollRun() {
  const records = activeEmployees().map((employee) => {
    const stats = weeklyStats(employee.id);
    const overtimeHours = Math.max(0, stats.paidHours - state.settings.overtimeAfter);
    const regularHours = Math.max(0, stats.paidHours - overtimeHours);
    const salaryMode = salaryModeFor(employee);
    const baseSalary = baseSalaryFor(employee);
    const hourlyEquivalent = overtimeHourlyRateFor(employee);
    const regularPay = baseSalary;
    const overtimePay = overtimeHours * hourlyEquivalent * state.settings.overtimeMultiplier;
    const ruleBreakDeductions = currentPeriodRuleDeductions(employee.id).reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
    const salaryAdvances = currentPeriodSalaryAdvances(employee.id).reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
    const lateDeduction = stats.late * Number(state.settings.lateDeductionAmount || 0);
    const missedPunchDeduction = stats.missed * Number(state.settings.missedPunchDeductionAmount || 0);
    const policyDeductions = ruleBreakDeductions + lateDeduction + missedPunchDeduction + salaryAdvances;
    const salesBonus = salesBonusFor(stats);
    const gross = regularPay + overtimePay + stats.commission + stats.tips + salesBonus;
    const statutoryDeductions = calculateStatutoryDeductions(gross);
    const statutoryDeductionTotal = statutoryDeductions.paye + statutoryDeductions.nis + statutoryDeductions.nht + statutoryDeductions.educationTax;
    const net = gross - statutoryDeductionTotal - policyDeductions;
    return {
      id: `${state.payPeriodStart}-${employee.id}`,
      employeeId: employee.id,
      employeeName: employee.name,
      staffId: employee.staffId,
      role: employee.role,
      email: employee.email,
      payPeriodStart: state.payPeriodStart,
      payPeriodEnd: periodEnd(),
      paymentDate: paymentDate(),
      regularHours: round(regularHours),
      overtimeHours: round(overtimeHours),
      hoursWorked: round(stats.paidHours),
      lunchDeductionHours: round(stats.lunchDeductionHours),
      baseSalary: round(baseSalary),
      monthlySalary: round(salaryMode.monthlySalary || 0),
      salaryType: salaryMode.type,
      hourlyWage: round(hourlyEquivalent),
      regularPay: round(regularPay),
      overtimePay: round(overtimePay),
      commission: round(stats.commission),
      tips: round(stats.tips),
      bonus: round(salesBonus),
      salesBonus: round(salesBonus),
      lateDeduction: round(lateDeduction),
      missedPunchDeduction: round(missedPunchDeduction),
      ruleBreakDeductions: round(ruleBreakDeductions),
      salaryAdvances: round(salaryAdvances),
      deductions: round(policyDeductions),
      payeChargeableIncome: statutoryDeductions.payeChargeableIncome,
      payeThreshold: statutoryDeductions.payeThreshold,
      nisCeiling: statutoryDeductions.nisCeiling,
      taxes: {
        paye: round(statutoryDeductions.paye),
        nis: round(statutoryDeductions.nis),
        nht: round(statutoryDeductions.nht),
        educationTax: round(statutoryDeductions.educationTax)
      },
      taxTotal: round(statutoryDeductionTotal),
      statutoryDeductionTotal: round(statutoryDeductionTotal),
      grossPay: round(gross),
      netPay: round(net)
    };
  });

  return {
    id: `run-${state.payPeriodStart}`,
    processedAt: new Date().toISOString(),
    payPeriodStart: state.payPeriodStart,
    payPeriodEnd: periodEnd(),
    paymentDate: paymentDate(),
    records
  };
}

function latestPayrollRun() {
  const run = state.payrollRuns.find((item) => item.payPeriodStart === state.payPeriodStart);
  if (run?.records?.every((record) => "baseSalary" in record && "salesBonus" in record && "ruleBreakDeductions" in record && "salaryAdvances" in record && "payeChargeableIncome" in record && record.taxes?.nht !== undefined)) return run;
  return calculatePayrollRun();
}

async function processPayroll() {
  if (guardStaffMutation()) return;
  const run = calculatePayrollRun();
  state.payrollRuns = state.payrollRuns.filter((item) => item.payPeriodStart !== state.payPeriodStart);
  state.payrollRuns.unshift(run);
  markPayslipDelivery(run, {
    status: "sending",
    message: "Payroll calculated. Preparing PDF payslip emails.",
    total: run.records.length,
    sent: 0,
    failed: 0
  });
  state.activity.unshift(audit("Admin", `Processed weekly payroll for ${displayDate(run.payPeriodStart)}-${displayDate(run.payPeriodEnd)}.`));
  saveState({ backupReason: `Payroll processed for ${run.payPeriodStart}` });
  renderAll();
  openView("payroll");
  await sendPayslipEmailsForRun(run);
}

function payslipDeliveryKey(runOrPeriodStart = state.payPeriodStart) {
  return typeof runOrPeriodStart === "string" ? runOrPeriodStart : runOrPeriodStart.payPeriodStart;
}

function payslipDeliveryForRun(run = latestPayrollRun()) {
  return state.payslipDeliveries?.[payslipDeliveryKey(run)] || {
    status: "not_sent",
    message: "Payslip emails will send automatically after payroll is processed.",
    total: run.records.length,
    sent: 0,
    failed: 0,
    skipped: 0,
    updatedAt: null
  };
}

function markPayslipDelivery(run, update) {
  state.payslipDeliveries = state.payslipDeliveries || {};
  const key = payslipDeliveryKey(run);
  state.payslipDeliveries[key] = {
    ...payslipDeliveryForRun(run),
    ...update,
    updatedAt: new Date().toISOString()
  };
}

function validEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || "").trim());
}

function payslipEmailSubject(record) {
  return `Trudy'z payslip - ${displayDate(record.payPeriodStart)} to ${displayDate(record.payPeriodEnd)}`;
}

function payslipEmailHtml(record) {
  return `
    <div style="font-family:Arial,sans-serif;color:#17100f;line-height:1.5">
      <h2>Trudy'z Amazing Nails LTD Payslip</h2>
      <p>Hello ${escapeHtml(record.employeeName)},</p>
      <p>Your payroll has been calculated for ${displayDate(record.payPeriodStart)} to ${displayDate(record.payPeriodEnd)}.</p>
      <p><strong>Net pay:</strong> ${formatMoney(record.netPay)}<br>
      <strong>Payment date:</strong> ${displayDate(record.paymentDate)}</p>
      <p>Your PDF payslip is attached. You can also sign in to the staff portal to generate it again.</p>
    </div>
  `;
}

function payslipEmailText(record) {
  return [
    "Trudy'z Amazing Nails LTD Payslip",
    "",
    `Hello ${record.employeeName},`,
    `Your payroll has been calculated for ${displayDate(record.payPeriodStart)} to ${displayDate(record.payPeriodEnd)}.`,
    `Net pay: ${formatMoney(record.netPay)}`,
    `Payment date: ${displayDate(record.paymentDate)}`,
    "",
    "Your PDF payslip is attached. You can also sign in to the staff portal to generate it again."
  ].join("\n");
}

function payslipFilename(record) {
  return `Trudyz-Payslip-${record.staffId}-${record.payPeriodStart}.pdf`;
}

function stringToBase64(value) {
  const bytes = new TextEncoder().encode(value);
  let binary = "";
  const chunkSize = 0x8000;
  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
  }
  return btoa(binary);
}

function payslipEmailPayload(record) {
  return {
    to: record.email,
    employeeName: record.employeeName,
    staffId: record.staffId,
    subject: payslipEmailSubject(record),
    html: payslipEmailHtml(record),
    text: payslipEmailText(record),
    filename: payslipFilename(record),
    pdfBase64: stringToBase64(buildPdf(record, payslipPdfLines(record)))
  };
}

async function sendPayslipEmailsForRun(run = latestPayrollRun()) {
  if (guardManagerMutation()) return;
  const eligibleRecords = run.records.filter((record) => validEmail(record.email));
  const skipped = run.records.length - eligibleRecords.length;
  if (!eligibleRecords.length) {
    markPayslipDelivery(run, {
      status: "queued",
      message: "No valid employee emails were found. Staff can still generate PDF payslips in the portal.",
      total: run.records.length,
      sent: 0,
      failed: 0,
      skipped
    });
    state.activity.unshift(audit("Payroll Email", "Payslip email delivery skipped because no valid employee emails were found."));
    saveState();
    renderPayroll();
    refreshIcons();
    return;
  }

  markPayslipDelivery(run, {
    status: "sending",
    message: "Sending PDF payslips to employee email addresses.",
    total: run.records.length,
    sent: 0,
    failed: 0,
    skipped
  });
  saveState();
  renderPayroll();
  refreshIcons();

  try {
    const response = await fetch(PAYSLIP_EMAIL_API, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(apiToken ? { Authorization: `Bearer ${apiToken}` } : {})
      },
      body: JSON.stringify({
        runId: run.id,
        payPeriodStart: run.payPeriodStart,
        payPeriodEnd: run.payPeriodEnd,
        paymentDate: run.paymentDate,
        payslips: eligibleRecords.map(payslipEmailPayload)
      })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok && response.status !== 207) {
      throw new Error(result.message || "Email function did not confirm delivery.");
    }
    const sent = Number(result.sent || 0);
    const failed = Number(result.failed || 0);
    markPayslipDelivery(run, {
      status: failed ? "partial" : "sent",
      message: failed ? `${sent} payslips sent; ${failed} need review.` : `${sent} PDF payslips emailed successfully.`,
      total: run.records.length,
      sent,
      failed,
      skipped,
      results: result.results || []
    });
    state.activity.unshift(audit("Payroll Email", `Sent ${sent} PDF payslip email${sent === 1 ? "" : "s"} for ${displayDate(run.payPeriodStart)}-${displayDate(run.payPeriodEnd)}.`));
  } catch (error) {
    markPayslipDelivery(run, {
      status: "queued",
      message: "Email sending is queued until the backend email service and Resend settings are live. Staff can still generate PDFs in the portal.",
      total: run.records.length,
      sent: 0,
      failed: eligibleRecords.length,
      skipped,
      error: error.message
    });
    state.activity.unshift(audit("Payroll Email", "PDF payslips prepared; email delivery needs the live email function setup."));
  }

  saveState();
  renderPayroll();
  renderDashboard();
  renderSecurity();
  refreshIcons();
}

function weeklyRevenueByDay() {
  return periodDates().map((date) => ({
    date,
    total: state.services
      .filter((entry) => entry.date === date)
      .reduce((sum, entry) => sum + Number(entry.amount || 0), 0)
  }));
}

function getNotifications() {
  const run = state.payrollRuns.find((item) => item.payPeriodStart === state.payPeriodStart);
  const allLogs = state.attendance.filter((entry) => periodDates().includes(entry.date));
  const missed = allLogs.filter((entry) => attendanceAlert(entry).includes("Missed punch"));
  const late = allLogs.filter((entry) => attendanceAlert(entry).includes("Late"));
  const overtime = calculatePayrollRun().records.filter((record) => record.overtimeHours > 0);
  const lows = lowStockItems();
  const shrinkRisks = shrinkRiskMovements();
  const notices = [];

  if (!run) notices.push({ title: "Payroll ready", detail: "Weekly payroll has not been finalized.", tone: "warm" });
  if (missed.length) notices.push({ title: `${missed.length} missed punch alert`, detail: "Manager review required before final payroll.", tone: "warm" });
  if (late.length) notices.push({ title: `${late.length} late arrivals`, detail: "Attendance trend flagged for the current period.", tone: "neutral" });
  if (overtime.length) notices.push({ title: `${overtime.length} overtime approval`, detail: "Weekly hours exceeded the configured threshold.", tone: "warm" });
  if (lows.length) notices.push({ title: `${lows.length} inventory reorder alert`, detail: "Salon supplies are at or below reorder level.", tone: "warm" });
  if (shrinkRisks.length) notices.push({ title: `${shrinkRisks.length} inventory variance alert`, detail: "Stock counts show shrinkage risk for manager review.", tone: "warm" });
  notices.push({ title: "Payslip automation", detail: `Payment date ${displayDate(paymentDate())}.`, tone: "neutral" });
  notices.push({ title: "Daily books", detail: "Front desk receipts, deposits, transfers, and expenses feed owner reports.", tone: "neutral" });
  return notices;
}

function renderAuthGate() {
  document.body.classList.toggle("auth-required", !isAuthenticated());
  document.body.classList.toggle("authenticated", isAuthenticated());
}

function renderAll() {
  renderAuthGate();
  renderRole();
  renderDashboard();
  renderEmployees();
  renderTimeClock();
  renderPayroll();
  renderSchedule();
  renderServices();
  renderBookkeeping();
  renderInventory();
  renderPortal();
  renderSecurity();
  labelResponsiveTables();
  refreshIcons();
}

function labelResponsiveTables() {
  document.querySelectorAll("table").forEach((table) => {
    const headers = [...table.querySelectorAll("thead th")].map((header) => header.textContent.trim());
    table.querySelectorAll("tbody tr").forEach((row) => {
      [...row.children].forEach((cell, index) => {
        if (headers[index]) cell.dataset.label = headers[index];
      });
    });
  });
}

function renderRole() {
  const roleSelect = document.querySelector("#activeRole");
  roleSelect.value = state.activeRole || "Admin";
  roleSelect.disabled = true;
  document.querySelector("#activeRoleChip").textContent = roleSelect.value;
  document.body.classList.toggle("locked", isLimitedMode());
  document.body.classList.toggle("staff-mode", isStaffMode());
  document.body.classList.toggle("front-desk-mode", isFrontDeskMode());
  document.body.classList.toggle("manager-mode", isManagerMode());
  document.querySelector("#accessLoginOpen span").textContent = isAuthenticated() ? "Switch login" : "Login";
  document.querySelector("#accessLoginOpen").hidden = isAuthenticated() && isStaffMode();
  document.querySelector("#sessionLogout").hidden = !isAuthenticated();
  document.querySelector("#lockSession").hidden = !isAuthenticated();

  navButtons.forEach((button) => {
    const allowed = roleAllowedView(button.dataset.viewTarget);
    button.hidden = !allowed;
    button.disabled = !allowed;
  });

  [
    "#processPayrollTop",
    "#addEmployeeOpen",
    "#processPayroll",
    "#downloadAllPayslips",
    "#rotateSaturday",
    "#seedService",
    "#exportData",
    "#exportExcel",
    "#exportExcelTop"
  ].forEach((selector) => {
    const item = document.querySelector(selector);
    if (!item) return;
    const shouldDisable = ["#rotateSaturday"].includes(selector)
      ? !canManageSchedule()
      : selector === "#seedService"
        ? !canManageOperations()
        : !canEdit();
    item.disabled = shouldDisable;
    item.classList.toggle("is-disabled", shouldDisable);
  });

  const activeView = document.querySelector(".ops-view.is-active")?.dataset.view;
  if (isStaffMode() && !["portal", "timeclock"].includes(activeView)) {
    openView("portal");
  }

  if (isFrontDeskMode() && !["bookkeeping", "services"].includes(activeView)) {
    openView("bookkeeping");
  }

  if (isManagerMode() && !roleAllowedView(document.querySelector(".ops-view.is-active")?.dataset.view)) {
    openView("dashboard");
  }
}

function roleAllowedView(viewName) {
  if (!isAuthenticated()) return false;
  if (!viewName) return false;
  if (isAdminMode() || isManagerMode()) return true;
  if (isFrontDeskMode()) return ["bookkeeping", "services"].includes(viewName);
  if (isStaffMode()) return ["portal", "timeclock"].includes(viewName);
  return false;
}

function renderDashboard() {
  const run = latestPayrollRun();
  const records = run.records;
  const totalNet = records.reduce((sum, record) => sum + record.netPay, 0);
  const totalRevenue = weeklyRevenueByDay().reduce((sum, day) => sum + day.total, 0);
  const missed = state.attendance.filter((entry) => periodDates().includes(entry.date) && attendanceAlert(entry).includes("Missed punch")).length;
  const stockValue = inventoryStockValue();
  const lowStock = lowStockItems().length;

  document.querySelector("#metricGrid").innerHTML = [
    metric("Payroll total", formatMoney(totalNet), `${records.length} weekly payslips`, "badge-dollar-sign"),
    metric("Revenue tracked", formatMoney(totalRevenue), `${state.services.filter((entry) => periodDates().includes(entry.date)).length} completed services`, "chart-no-axes-combined"),
    metric("Inventory value", formatMoney(stockValue), `${lowStock} reorder alerts`, "boxes"),
    metric("Attendance health", `${Math.max(0, 100 - missed * 8)}%`, `${missed} missed punch alerts`, "scan-line")
  ].join("");

  const revenue = weeklyRevenueByDay();
  const maxRevenue = Math.max(...revenue.map((item) => item.total), 1);
  document.querySelector("#revenueChart").innerHTML = revenue.map((item) => {
    const height = 22 + (item.total / maxRevenue) * 78;
    return `
      <div class="bar-item">
        <div class="bar" style="height:${height}%"></div>
        <span>${displayDate(item.date).split(",")[0]}</span>
      </div>
    `;
  }).join("");

  const notices = getNotifications();
  document.querySelector("#notificationCount").textContent = notices.length;
  document.querySelector("#notificationList").innerHTML = notices.map((notice) => noticeItem(notice.title, notice.detail, notice.tone)).join("");

  document.querySelector("#performanceRows").innerHTML = activeEmployees().map((employee) => {
    const stats = weeklyStats(employee.id);
    const commission = stats.commission;
    const status = stats.missed ? `<span class="tag danger">Review</span>` : `<span class="tag success">Clean</span>`;
    return `
      <tr>
        <td>${escapeHtml(employee.name)}<br><span class="tag">${escapeHtml(employee.staffId)}</span></td>
        <td>${escapeHtml(employee.role)}</td>
        <td>${formatHours(stats.paidHours)}</td>
        <td>${stats.services.length}</td>
        <td>${formatMoney(commission)}</td>
        <td>${status}</td>
      </tr>
    `;
  }).join("");
}

function metric(label, value, detail, icon) {
  return `
    <article class="glass-panel metric-card">
      <span>${label}</span>
      <strong>${value}</strong>
      <small>${detail}</small>
      <div class="status-pill" style="margin-top:1rem"><i data-lucide="${icon}"></i><span>Live metric</span></div>
    </article>
  `;
}

function noticeItem(title, detail, tone = "neutral") {
  return `
    <div class="notice">
      <div>
        <strong>${escapeHtml(title)}</strong>
        <span>${escapeHtml(detail)}</span>
      </div>
      <span class="chip ${tone === "warm" ? "warm" : ""}">${tone === "warm" ? "Alert" : "Auto"}</span>
    </div>
  `;
}

function renderEmployees() {
  const grid = document.querySelector("#employeeGrid");
  grid.innerHTML = state.employees.map((employee) => {
    const stats = weeklyStats(employee.id);
    const tier = stats.commissionTier;
    const initials = employee.name.split(" ").map((part) => part[0]).join("").slice(0, 2);
    return `
      <article class="glass-panel employee-card ${employee.id === selectedEmployeeId ? "is-selected" : ""}" data-employee-card="${employee.id}">
        <div class="employee-card-head">
          <div class="avatar">${escapeHtml(initials)}</div>
          <span class="tag ${employee.status === "Active" ? "success" : "danger"}">${escapeHtml(employee.status)}</span>
        </div>
        <div>
          <h3>${escapeHtml(employee.name)}</h3>
          <span class="micro-label">${escapeHtml(employee.staffId)} / ${escapeHtml(employee.role)}</span>
        </div>
        <div class="staff-meta">
          <span class="tag">${escapeHtml(salaryLabelFor(employee))}</span>
          <span class="tag">${escapeHtml(tier.name)}</span>
          <span class="tag">${formatMoney(stats.serviceRevenue)} weekly sales</span>
          <span class="tag">${formatHours(stats.paidHours)}</span>
        </div>
      </article>
    `;
  }).join("");

  const employee = employeeById(selectedEmployeeId) || state.employees[0];
  selectedEmployeeId = employee?.id;
  if (!employee) return;
  const stats = weeklyStats(employee.id);
  const tier = stats.commissionTier;
  document.querySelector("#employeeProfile").innerHTML = `
    <div class="profile-hero">
      <div class="avatar">${escapeHtml(employee.name.split(" ").map((part) => part[0]).join("").slice(0, 2))}</div>
      <div>
        <h3>${escapeHtml(employee.name)}</h3>
        <span>${escapeHtml(employee.role)} / ${escapeHtml(employee.staffId)}</span>
      </div>
    </div>
    <div class="profile-grid">
      <div class="profile-stat"><span>Email</span><strong>${escapeHtml(employee.email)}</strong></div>
      <div class="profile-stat"><span>Phone</span><strong>${escapeHtml(employee.phone)}</strong></div>
      <div class="profile-stat"><span>Emergency contact</span><strong>${escapeHtml(employee.emergencyContact || "Not set")}</strong></div>
      <div class="profile-stat"><span>Address</span><strong>${escapeHtml(employee.address || "Not set")}</strong></div>
      <div class="profile-stat"><span>Salary basis</span><strong>${escapeHtml(salaryLabelFor(employee))}</strong></div>
      <div class="profile-stat"><span>Weekly hours</span><strong>${formatHours(stats.paidHours)}</strong></div>
      <div class="profile-stat"><span>Weekly sales</span><strong>${formatMoney(stats.serviceRevenue)}</strong></div>
      <div class="profile-stat"><span>Commission</span><strong>${formatMoney(stats.commission)}</strong></div>
      <div class="profile-stat"><span>Commission tier</span><strong>${tier.serviceRate}% on ${commissionRangeLabel(tier)}</strong></div>
      <div class="profile-stat"><span>Permissions</span><strong>${employee.permissions.map(escapeHtml).join(", ")}</strong></div>
      <div class="profile-stat"><span>Hired</span><strong>${displayDate(employee.hired)}</strong></div>
    </div>
    ${canEdit() ? `
      <button class="soft-button full" type="button" data-edit-employee="${employee.id}"><i data-lucide="square-pen"></i><span>Edit profile</span></button>
      <button class="soft-button full" type="button" data-toggle-employee="${employee.id}"><i data-lucide="power"></i><span>${employee.status === "Active" ? "Set inactive" : "Reactivate"}</span></button>
      <button class="soft-button full" type="button" data-remove-employee="${employee.id}"><i data-lucide="trash-2"></i><span>Remove employee</span></button>
    ` : noticeItem("Read-only staff access", "Staff can view their own portal only. Editing is disabled.", "warm")}
  `;
}

function renderTimeClock() {
  const signedEmployee = signedInEmployee();
  const clockEmployees = isStaffMode() && signedEmployee ? [signedEmployee] : activeEmployees();
  const attendanceRows = state.attendance.filter((entry) => (
    periodDates().includes(entry.date) && (!isStaffMode() || entry.employeeId === state.signedInEmployeeId)
  ));

  fillEmployeeSelect("#clockEmployee", clockEmployees);
  fillEmployeeSelect("#overrideEmployee", activeEmployees());

  const clockEmployeeSelect = document.querySelector("#clockEmployee");
  if (clockEmployeeSelect) {
    clockEmployeeSelect.disabled = isStaffMode();
    if (isStaffMode() && signedEmployee) clockEmployeeSelect.value = signedEmployee.id;
  }

  const overridePanel = document.querySelector("#managerOverridePanel");
  if (overridePanel) overridePanel.hidden = isStaffMode();

  document.querySelectorAll("[data-punch]").forEach((button) => {
    button.disabled = isStaffMode() && !signedEmployee;
  });

  const rows = attendanceRows
    .sort((a, b) => `${b.date}${b.clockIn || ""}`.localeCompare(`${a.date}${a.clockIn || ""}`))
    .map((entry) => {
      const employee = employeeById(entry.employeeId);
      const alerts = attendanceAlert(entry);
      const lunch = entry.lunchStart || entry.lunchEnd ? `${formatTime(entry.lunchStart)} / ${formatTime(entry.lunchEnd)}` : "Auto 35 min";
      return `
        <tr>
          <td>${escapeHtml(employee?.name || "Unknown")}</td>
          <td>${displayDate(entry.date)}</td>
          <td>${formatTime(entry.clockIn)}</td>
          <td>${lunch}</td>
          <td>${formatTime(entry.clockOut)}</td>
          <td>${formatHours(paidHoursFor(entry))}</td>
          <td>${alerts.length ? alerts.map((alert) => `<span class="tag ${alert.includes("Missed") ? "danger" : "dark"}">${escapeHtml(alert)}</span>`).join(" ") : `<span class="tag success">Clear</span>`}</td>
        </tr>
      `;
    }).join("");

  document.querySelector("#attendanceRows").innerHTML = rows;
  const missed = attendanceRows.filter((entry) => attendanceAlert(entry).includes("Missed punch")).length;
  document.querySelector("#missedPunchCount").textContent = `${missed} missed`;
}

function fillEmployeeSelect(selector, employees) {
  const element = document.querySelector(selector);
  if (!element) return;
  const current = element.value;
  element.innerHTML = employees.map((employee) => `<option value="${employee.id}">${escapeHtml(employee.name)} / ${escapeHtml(employee.staffId)}</option>`).join("");
  if (employees.some((employee) => employee.id === current)) element.value = current;
}

function renderPayroll() {
  const settings = state.settings;
  document.querySelector("#baseSalary").value = settings.baseSalary || WEEKLY_BASE_SALARY;
  document.querySelector("#ratePaye").value = settings.paye;
  document.querySelector("#payeWeeklyThreshold").value = settings.payeWeeklyThreshold || PAYE_WEEKLY_THRESHOLD_2026;
  document.querySelector("#payeHigherRate").value = settings.payeHigherRate || PAYE_HIGHER_RATE;
  document.querySelector("#payeHigherRateWeeklyThreshold").value = settings.payeHigherRateWeeklyThreshold || PAYE_HIGHER_RATE_WEEKLY_THRESHOLD;
  document.querySelector("#rateNis").value = settings.nis;
  document.querySelector("#nisWeeklyCeiling").value = settings.nisWeeklyCeiling || NIS_WEEKLY_CEILING;
  document.querySelector("#rateNht").value = settings.nht;
  document.querySelector("#rateEdu").value = settings.educationTax;
  document.querySelector("#overtimeAfter").value = settings.overtimeAfter;
  document.querySelector("#overtimeMultiplier").value = settings.overtimeMultiplier;
  document.querySelector("#frontDeskMonthlySalary").value = settings.frontDeskMonthlySalary || FRONT_DESK_MONTHLY_SALARY;
  document.querySelector("#managerMonthlySalary").value = settings.managerMonthlySalary || MANAGER_MONTHLY_SALARY;
  document.querySelector("#monthlySalaryDivisor").value = settings.monthlySalaryDivisor || MONTHLY_SALARY_DIVISOR;
  document.querySelector("#salesBonusThreshold").value = settings.salesBonusThreshold || 0;
  document.querySelector("#salesBonusAmount").value = settings.salesBonusAmount || 0;
  document.querySelector("#lateDeductionAmount").value = settings.lateDeductionAmount || 0;
  document.querySelector("#missedPunchDeductionAmount").value = settings.missedPunchDeductionAmount || 0;
  fillEmployeeSelect("#policyDeductionEmployee", activeEmployees());
  fillEmployeeSelect("#salaryAdvanceEmployee", activeEmployees());
  const policyDate = document.querySelector("#policyDeductionDate");
  if (policyDate && !policyDate.value) policyDate.value = businessEntryDate();
  const salaryAdvanceDate = document.querySelector("#salaryAdvanceDate");
  if (salaryAdvanceDate && !salaryAdvanceDate.value) salaryAdvanceDate.value = businessEntryDate();
  document.querySelector("#policyDeductionAmount").value ||= settings.lateDeductionAmount || 500;

  const policyForm = document.querySelector("#policyDeductionForm");
  policyForm?.querySelectorAll("input, select, button").forEach((item) => {
    item.disabled = !canManageOperations();
  });
  const salaryAdvanceForm = document.querySelector("#salaryAdvanceForm");
  salaryAdvanceForm?.querySelectorAll("input, select, button").forEach((item) => {
    item.disabled = !canManageOperations();
  });

  const run = latestPayrollRun();
  const totals = run.records.reduce((acc, record) => {
    acc.net += record.netPay;
    acc.gross += record.grossPay;
    acc.base += record.baseSalary || record.regularPay || 0;
    acc.advances += record.salaryAdvances || 0;
    acc.statutoryDeductions += record.statutoryDeductionTotal || record.taxTotal;
    acc.hours += record.hoursWorked;
    return acc;
  }, { net: 0, gross: 0, base: 0, advances: 0, statutoryDeductions: 0, hours: 0 });

  const processed = state.payrollRuns.some((item) => item.payPeriodStart === state.payPeriodStart);
  const delivery = payslipDeliveryForRun(run);
  const deliveryTone = {
    sent: "success",
    partial: "warm",
    queued: "warm",
    sending: "",
    not_sent: "dark"
  }[delivery.status] || "dark";
  document.querySelector("#payrollSummary").innerHTML = `
    <div class="payroll-total">
      <span class="micro-label">Weekly Payroll Total</span>
      <strong>${formatMoney(totals.net)}</strong>
      <span>${displayDate(run.payPeriodStart)}-${displayDate(run.payPeriodEnd)} / Payment ${displayDate(run.paymentDate)}</span>
      <span class="chip ${processed ? "" : "warm"}">${processed ? "Processed" : "Draft"}</span>
    </div>
    <div class="summary-mini-grid">
      <div><span>Gross</span><strong>${formatMoney(totals.gross)}</strong></div>
      <div><span>Base salaries</span><strong>${formatMoney(totals.base)}</strong></div>
      <div><span>Salary advances</span><strong>${formatMoney(totals.advances)}</strong></div>
      <div><span>Statutory deductions</span><strong>${formatMoney(totals.statutoryDeductions)}</strong></div>
      <div><span>Hours</span><strong>${formatHours(totals.hours)}</strong></div>
    </div>
  `;

  document.querySelector("#payslipEmailPanel").innerHTML = `
    <div class="card-head">
      <div>
        <span class="micro-label">Automatic Payslip Email</span>
        <h3>PDF payslips send after payroll calculations.</h3>
      </div>
      <span class="chip ${deliveryTone}">${escapeHtml(delivery.status.replace("_", " "))}</span>
    </div>
    <div class="summary-mini-grid">
      <div><span>Total payslips</span><strong>${delivery.total || run.records.length}</strong></div>
      <div><span>Emailed</span><strong>${delivery.sent || 0}</strong></div>
      <div><span>Needs review</span><strong>${delivery.failed || 0}</strong></div>
      <div><span>No email</span><strong>${delivery.skipped || 0}</strong></div>
    </div>
    <div class="notice-list">
      ${noticeItem("Delivery status", delivery.message || "Payslip emails will send automatically after payroll is processed.", delivery.status === "sent" ? "neutral" : "warm")}
      ${delivery.updatedAt ? noticeItem("Last update", new Date(delivery.updatedAt).toLocaleString([], { dateStyle: "medium", timeStyle: "short" }), "neutral") : ""}
    </div>
    <button class="soft-button full" type="button" data-send-payslip-emails ${delivery.status === "sending" ? "disabled" : ""}><i data-lucide="send"></i><span>Send PDF Emails Again</span></button>
  `;

  document.querySelector("#payrollRows").innerHTML = run.records.map((record) => `
    <tr>
      <td>${escapeHtml(record.employeeName)}<br><span class="tag">${escapeHtml(record.staffId)}</span><br><small>${escapeHtml(record.email || "No email")}</small></td>
      <td>${displayDate(record.payPeriodStart)}-${displayDate(record.payPeriodEnd)}</td>
      <td>${formatHours(record.hoursWorked)}</td>
      <td>${formatMoney(record.baseSalary || record.regularPay)}</td>
      <td>${formatHours(record.overtimeHours)}</td>
      <td>${formatMoney(record.commission)}</td>
      <td>${formatMoney(record.tips)}</td>
      <td>${formatMoney(record.deductions)}<br><small>Advance ${formatMoney(record.salaryAdvances || 0)}</small></td>
      <td>${formatMoney(record.statutoryDeductionTotal || record.taxTotal)}</td>
      <td>${formatMoney(record.netPay)}</td>
      <td>
        <button class="mini-action" type="button" data-view-payslip="${record.employeeId}"><i data-lucide="eye"></i><span>View</span></button>
        <button class="mini-action" type="button" data-pdf-payslip="${record.employeeId}"><i data-lucide="file-down"></i><span>PDF</span></button>
      </td>
    </tr>
  `).join("");

  document.querySelector("#policyDeductionRows").innerHTML = (state.ruleDeductions || [])
    .filter((entry) => periodDates().includes(entry.date))
    .sort((a, b) => b.date.localeCompare(a.date))
    .map((entry) => {
      const employee = employeeById(entry.employeeId);
      return `
        <tr>
          <td>${displayDate(entry.date)}</td>
          <td>${escapeHtml(employee?.name || "Unknown")}</td>
          <td>${escapeHtml(entry.reason)}</td>
          <td>${formatMoney(entry.amount)}</td>
          <td>${escapeHtml(entry.note || "")}</td>
        </tr>
      `;
    }).join("") || `<tr><td colspan="5">No rule-breaking deductions recorded for this week.</td></tr>`;

  document.querySelector("#salaryAdvanceRows").innerHTML = (state.salaryAdvances || [])
    .filter((entry) => periodDates().includes(entry.date))
    .sort((a, b) => b.date.localeCompare(a.date))
    .map((entry) => {
      const employee = employeeById(entry.employeeId);
      return `
        <tr>
          <td>${displayDate(entry.date)}</td>
          <td>${escapeHtml(employee?.name || "Unknown")}</td>
          <td>${formatMoney(entry.amount)}</td>
          <td>${escapeHtml(entry.note || "")}</td>
        </tr>
      `;
    }).join("") || `<tr><td colspan="4">No salary advances recorded for this week.</td></tr>`;
}

function renderSchedule() {
  if (!document.querySelector("#scheduleGrid")) return;
  const days = periodDates();
  document.querySelector("#scheduleGrid").innerHTML = days.map((date) => {
    const hours = getBusinessHours(date);
    const dayShifts = state.schedule.filter((item) => item.date === date);
    return `
      <article class="glass-panel schedule-day">
        <h3>${displayDate(date).split(",")[0]} <span class="tag">${hours.label}</span></h3>
        ${dayShifts.map((item) => {
          const employee = employeeById(item.employeeId);
          return `
            <div class="shift-card">
              <strong>${escapeHtml(employee?.name || "Open shift")}</strong>
              <span>${formatTime(item.start)}-${formatTime(item.end)}</span>
              <span>${escapeHtml(item.role)}</span>
            </div>
          `;
        }).join("")}
      </article>
    `;
  }).join("");

  document.querySelector("#rotationWeek").textContent = displayDate(state.payPeriodStart);
  document.querySelector("#rotationList").innerHTML = state.saturdayRotation.map((employeeId, index) => {
    const employee = employeeById(employeeId);
    return `
      <div class="rotation-item">
        <div>
          <strong>${index + 1}. ${escapeHtml(employee?.name || "Open")}</strong>
          <span>${escapeHtml(employee?.role || "Coverage")}</span>
        </div>
        <span class="chip">${index < 2 ? "Primary" : "Queue"}</span>
      </div>
    `;
  }).join("");

  const conflicts = getScheduleConflicts();
  document.querySelector("#conflictCount").textContent = conflicts.length;
  document.querySelector("#scheduleConflicts").innerHTML = conflicts.length
    ? conflicts.map((item) => noticeItem(item.title, item.detail, "warm")).join("")
    : noticeItem("Schedule is clean", "No overlapping shifts or coverage gaps detected.", "neutral");
}

function getScheduleConflicts() {
  const conflicts = [];
  periodDates().forEach((date) => {
    const dayShifts = state.schedule.filter((item) => item.date === date);
    const techCount = dayShifts.filter((item) => /Tech|Lead|Manager/i.test(item.role)).length;
    if (techCount < 2) conflicts.push({ title: "Low technician coverage", detail: `${displayDate(date)} has fewer than two service staff.` });
    activeEmployees().forEach((employee) => {
      const shifts = dayShifts.filter((item) => item.employeeId === employee.id);
      if (shifts.length > 1) conflicts.push({ title: "Duplicate shift", detail: `${employee.name} appears more than once on ${displayDate(date)}.` });
    });
  });
  return conflicts;
}

function renderServices() {
  fillEmployeeSelect("#serviceEmployee", activeEmployees());
  const selectedService = document.querySelector("#serviceType").value;
  const services = activeServiceCatalog();
  document.querySelector("#serviceType").innerHTML = services.map((item) => `<option value="${item.id}" data-amount="${item.price}">${escapeHtml(serviceCatalogLabel(item))}</option>`).join("");
  if (services.some((item) => item.id === selectedService)) {
    document.querySelector("#serviceType").value = selectedService;
  }

  const serviceAccess = document.querySelector("#serviceAccess");
      serviceAccess.innerHTML = isFrontDeskMode() ? `
    <div class="signed-in-banner">
      <div>
        <span class="micro-label">Front Desk Service Entry</span>
        <h3>Record service and payment split together.</h3>
        <p>Enter the staff member, service, tips, and payment split. The system posts commission to payroll and creates matching Books receipts automatically.</p>
      </div>
      <span class="chip">Payment ready</span>
    </div>
  ` : `
    <div class="signed-in-banner">
      <div>
        <span class="micro-label">Service Ledger</span>
        <h3>Admin and manager service operations.</h3>
        <p>Completed services entered here feed staff analytics, commissions, tips, payroll, and daily settlement receipts.</p>
      </div>
      <span class="chip">Calculates payroll</span>
    </div>
  `;

  const serviceForm = document.querySelector("#serviceForm");
  serviceForm.querySelectorAll("input, select, button").forEach((item) => {
    item.disabled = !canEnterServices();
  });
  syncServiceForm();

  const catalogForm = document.querySelector("#serviceCatalogForm");
  catalogForm.querySelectorAll("input, button").forEach((item) => {
    item.disabled = !canManageOperations();
  });
  catalogForm.classList.toggle("is-disabled", !canManageOperations());
  document.querySelector("#serviceCatalogList").innerHTML = serviceCatalog().map((item) => `
    <div class="catalog-item ${item.active === false ? "is-inactive" : ""}">
      <div>
        <strong>${escapeHtml(item.name)}</strong>
        <span>${formatMoney(item.price)}</span>
      </div>
      ${canManageOperations() ? `<button class="mini-action" type="button" data-remove-service="${item.id}"><i data-lucide="trash-2"></i><span>Remove</span></button>` : `<span class="tag">Menu item</span>`}
    </div>
  `).join("");

  const periodServiceRows = state.services
    .filter((entry) => periodDates().includes(entry.date))
    .sort((a, b) => b.date.localeCompare(a.date))
    .map((entry) => {
      const employee = employeeById(entry.employeeId);
      const tier = commissionTierForEmployeeWeek(employee?.id);
      return `
        <tr>
          <td>${displayDate(entry.date)}</td>
          <td>${escapeHtml(employee?.name || "Unknown")}</td>
          <td>${escapeHtml(entry.service)}<br><span class="tag">${tier.serviceRate}% weekly tier</span></td>
          <td>${formatMoney(Number(entry.amount || 0))}</td>
          <td>${escapeHtml(servicePaymentSummary(entry.paymentSplit || []))}</td>
          <td>${formatMoney(serviceCommission(entry, employee))}</td>
        </tr>
      `;
    }).join("");
  document.querySelector("#serviceRows").innerHTML = periodServiceRows;
  document.querySelector("#serviceCount").textContent = `${state.services.filter((entry) => periodDates().includes(entry.date)).length} services`;
}

function bookkeepingEntries() {
  if (!Array.isArray(state.bookkeepingEntries)) state.bookkeepingEntries = [];
  return state.bookkeepingEntries;
}

function entriesForDate(date) {
  return bookkeepingEntries().filter((entry) => entry.date === date);
}

function entriesForPeriod() {
  const dates = new Set(periodDates());
  return bookkeepingEntries().filter((entry) => dates.has(entry.date));
}

function serviceRevenueForDate(date) {
  return state.services
    .filter((entry) => entry.date === date)
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
}

function serviceTipsForDate(date) {
  return state.services
    .filter((entry) => entry.date === date)
    .reduce((sum, entry) => sum + Number(entry.tips || 0), 0);
}

function serviceReceivableForDate(date) {
  return state.services
    .filter((entry) => entry.date === date)
    .reduce((sum, entry) => sum + Number(entry.amount || 0) + Number(entry.tips || 0), 0);
}

function salesReceiptTotal(entries) {
  return entries.filter((entry) => entry.type === "Sale Receipt").reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
}

function expenseTotal(entries) {
  return entries.filter((entry) => entry.type === "Expense").reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
}

function depositTotal(entries) {
  return entries.filter((entry) => entry.type === "Deposit").reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
}

function transferTotal(entries) {
  return entries.filter((entry) => entry.type === "Transfer").reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
}

function channelTotal(entries, channel) {
  return entries.filter((entry) => entry.channel === channel).reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
}

function dailyBookkeepingSummary(date) {
  const entries = entriesForDate(date);
  const receiptEntries = entries.filter((entry) => entry.type === "Sale Receipt");
  const cashExpenses = entries.filter((entry) => entry.type === "Expense" && entry.channel === "Cash").reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
  const cashDeposits = entries.filter((entry) => entry.type === "Deposit" && entry.channel === "Cash").reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
  const serviceSales = serviceRevenueForDate(date);
  const tips = serviceTipsForDate(date);
  const expectedReceipts = serviceReceivableForDate(date);
  const receipts = salesReceiptTotal(entries);
  const expenses = expenseTotal(entries);
  const deposits = depositTotal(entries);
  const transfers = transferTotal(entries);
  return {
    date,
    serviceSales,
    tips,
    expectedReceipts,
    receipts,
    expenses,
    deposits,
    transfers,
    variance: receipts - expectedReceipts,
    cash: channelTotal(receiptEntries, "Cash"),
    ncb: channelTotal(receiptEntries, "NCB POS Machine"),
    fygaro: channelTotal(receiptEntries, "FYGARO"),
    bankTransfer: channelTotal(receiptEntries, "Bank Transfer"),
    netCashPosition: channelTotal(receiptEntries, "Cash") - cashExpenses - cashDeposits
  };
}

function weeklyBookkeepingSummary() {
  const entries = entriesForPeriod();
  const receiptEntries = entries.filter((entry) => entry.type === "Sale Receipt");
  const serviceSales = periodDates().reduce((sum, date) => sum + serviceRevenueForDate(date), 0);
  const tips = periodDates().reduce((sum, date) => sum + serviceTipsForDate(date), 0);
  const expectedReceipts = periodDates().reduce((sum, date) => sum + serviceReceivableForDate(date), 0);
  const receipts = salesReceiptTotal(entries);
  const expenses = expenseTotal(entries);
  const deposits = depositTotal(entries);
  const transfers = transferTotal(entries);
  return {
    payPeriodStart: state.payPeriodStart,
    payPeriodEnd: periodEnd(),
    serviceSales,
    tips,
    expectedReceipts,
    receipts,
    expenses,
    deposits,
    transfers,
    variance: receipts - expectedReceipts,
    ncb: channelTotal(receiptEntries, "NCB POS Machine"),
    fygaro: channelTotal(receiptEntries, "FYGARO"),
    cash: channelTotal(receiptEntries, "Cash"),
    bankTransfer: channelTotal(receiptEntries, "Bank Transfer")
  };
}

function closeoutStatus(date) {
  const close = state.dailyClosings?.find((entry) => entry.date === date);
  if (!close) return { label: "Open", tone: "warm" };
  if (Math.abs(Number(close.variance || 0)) > 0) return { label: "Variance", tone: "danger" };
  return { label: "Closed", tone: "success" };
}

function renderBookkeeping() {
  const metricGrid = document.querySelector("#bookkeepingMetricGrid");
  if (!metricGrid) return;
  const date = document.querySelector("#dailyCloseDate")?.value || businessEntryDate();
  const entryDate = document.querySelector("#bookkeepingEntryDate");
  const closeDate = document.querySelector("#dailyCloseDate");
  if (entryDate && !entryDate.value) entryDate.value = date;
  if (closeDate && !closeDate.value) closeDate.value = date;

  document.querySelectorAll("#bookkeepingEntryForm input, #bookkeepingEntryForm select, #bookkeepingEntryForm button, #dailyCloseForm input, #dailyCloseForm button, #weeklyCloseButton").forEach((item) => {
    item.disabled = !canEnterBookkeeping();
  });

  const day = dailyBookkeepingSummary(closeDate.value || date);
  const week = weeklyBookkeepingSummary();
  const status = closeoutStatus(day.date);
  document.querySelector("#dailyCloseStatus").textContent = status.label;
  document.querySelector("#dailyCloseStatus").className = `chip ${status.tone || ""}`;
  document.querySelector("#bookkeepingDateLabel").textContent = displayDate(day.date);
  document.querySelector("#weeklyCloseStatus").textContent = state.weeklyClosings?.some((close) => close.payPeriodStart === state.payPeriodStart) ? "Saved" : "Draft";

  metricGrid.innerHTML = [
    metric("Service sales", formatMoney(day.serviceSales), `${formatMoney(day.tips)} tips collected`, "sparkles"),
    metric("Receipts", formatMoney(day.receipts), `${formatMoney(day.ncb)} NCB / ${formatMoney(day.fygaro)} FYGARO`, "credit-card"),
    metric("Expenses", formatMoney(day.expenses), "Front desk expense log", "receipt-text"),
    metric("Daily variance", formatMoney(day.variance), day.variance === 0 ? "Receipts match service payment total" : "Owner review needed", "scale")
  ].join("");

  document.querySelector("#dailyBookkeepingSummary").innerHTML = `
    <div class="summary-mini-grid bookkeeping-summary-grid">
      <div><span>Expected receipts</span><strong>${formatMoney(day.expectedReceipts)}</strong></div>
      <div><span>Cash</span><strong>${formatMoney(day.cash)}</strong></div>
      <div><span>NCB POS</span><strong>${formatMoney(day.ncb)}</strong></div>
      <div><span>FYGARO</span><strong>${formatMoney(day.fygaro)}</strong></div>
      <div><span>Transfers</span><strong>${formatMoney(day.bankTransfer)}</strong></div>
      <div><span>Deposits</span><strong>${formatMoney(day.deposits)}</strong></div>
      <div><span>Expenses</span><strong>${formatMoney(day.expenses)}</strong></div>
      <div><span>Net cash position</span><strong>${formatMoney(day.netCashPosition)}</strong></div>
      <div><span>Status</span><strong>${escapeHtml(status.label)}</strong></div>
    </div>
  `;

  document.querySelector("#weeklyBookkeepingReport").innerHTML = [
    noticeItem("Weekly receipts", `${formatMoney(week.receipts)} received against ${formatMoney(week.expectedReceipts)} expected service payment total.`, Math.abs(week.variance) ? "warm" : "neutral"),
    noticeItem("Payment channels", `${formatMoney(week.ncb)} NCB POS, ${formatMoney(week.fygaro)} FYGARO, ${formatMoney(week.cash)} cash, ${formatMoney(week.bankTransfer)} transfer.`, "neutral"),
    noticeItem("Owner cash control", `${formatMoney(week.expenses)} expenses, ${formatMoney(week.deposits)} deposits, ${formatMoney(week.transfers)} transfers.`, "neutral")
  ].join("");

  const periodRows = entriesForPeriod()
    .slice()
    .sort((a, b) => `${b.date}${b.at || ""}`.localeCompare(`${a.date}${a.at || ""}`))
    .map((entry) => `
      <tr>
        <td>${displayDate(entry.date)}</td>
        <td><span class="tag ${entry.type === "Expense" ? "danger" : entry.type === "Sale Receipt" ? "success" : "dark"}">${escapeHtml(entry.type)}</span></td>
        <td>${escapeHtml(entry.channel)}</td>
        <td>${escapeHtml(entry.category)}<br><small>${escapeHtml(entry.note || "")}</small></td>
        <td>${formatMoney(entry.amount)}</td>
        <td>${escapeHtml(entry.reference || "-")}</td>
      </tr>
    `).join("");
  document.querySelector("#bookkeepingRows").innerHTML = periodRows;

  const closeRows = (state.dailyClosings || [])
    .slice()
    .sort((a, b) => b.date.localeCompare(a.date))
    .map((close) => `
      <tr>
        <td>${displayDate(close.date)}</td>
        <td>${formatMoney(close.serviceSales)}</td>
        <td>${formatMoney(close.tips || 0)}</td>
        <td>${formatMoney(close.expectedReceipts || close.serviceSales)}</td>
        <td>${formatMoney(close.receipts)}</td>
        <td>${formatMoney(close.expenses)}</td>
        <td>${formatMoney(close.deposits)}</td>
        <td>${formatMoney(close.transfers)}</td>
        <td><span class="tag ${Math.abs(Number(close.variance || 0)) ? "danger" : "success"}">${formatMoney(close.variance)}</span></td>
        <td>${escapeHtml(close.closedBy || "Front Desk")}<br><small>${escapeHtml(close.note || "")}</small></td>
      </tr>
    `).join("");
  document.querySelector("#dailyCloseRows").innerHTML = closeRows || `<tr><td colspan="10">No daily closeouts saved yet.</td></tr>`;
  document.querySelector("#closeoutCount").textContent = `${(state.dailyClosings || []).length + (state.weeklyClosings || []).length} reports`;
}

function addBookkeepingEntry(event) {
  event.preventDefault();
  if (guardBookkeepingEntry()) return;
  const entry = bookEntry(
    document.querySelector("#bookkeepingEntryDate").value || businessEntryDate(),
    document.querySelector("#bookkeepingEntryType").value,
    document.querySelector("#bookkeepingChannel").value,
    document.querySelector("#bookkeepingCategory").value,
    Number(document.querySelector("#bookkeepingAmount").value || 0),
    document.querySelector("#bookkeepingReference").value.trim(),
    document.querySelector("#bookkeepingNote").value.trim(),
    state.activeRole
  );
  if (entry.amount <= 0) return;
  bookkeepingEntries().unshift(entry);
  state.activity.unshift(audit("Bookkeeping", `${entry.type} recorded for ${formatMoney(entry.amount)} via ${entry.channel}.`));
  event.target.reset();
  document.querySelector("#bookkeepingEntryDate").value = entry.date;
  saveState();
  renderAll();
}

function closeDailyBooks(event) {
  event.preventDefault();
  if (guardBookkeepingEntry()) return;
  const date = document.querySelector("#dailyCloseDate").value || businessEntryDate();
  const summary = dailyBookkeepingSummary(date);
  const close = {
    id: uid("close"),
    ...summary,
    note: document.querySelector("#dailyCloseNote").value.trim(),
    closedBy: state.activeRole,
    closedAt: new Date().toISOString()
  };
  state.dailyClosings = (state.dailyClosings || []).filter((item) => item.date !== date);
  state.dailyClosings.unshift(close);
  state.activity.unshift(audit("Bookkeeping", `Daily books closed for ${displayDate(date)} with ${formatMoney(summary.variance)} variance.`));
  event.target.reset();
  document.querySelector("#dailyCloseDate").value = date;
  saveState();
  renderAll();
}

function closeWeeklyBooks() {
  if (guardBookkeepingEntry()) return;
  const summary = weeklyBookkeepingSummary();
  const close = {
    id: uid("week-close"),
    ...summary,
    closedBy: state.activeRole,
    closedAt: new Date().toISOString()
  };
  state.weeklyClosings = (state.weeklyClosings || []).filter((item) => item.payPeriodStart !== state.payPeriodStart);
  state.weeklyClosings.unshift(close);
  state.activity.unshift(audit("Bookkeeping", `Weekly owner report saved for ${displayDate(state.payPeriodStart)}-${displayDate(periodEnd())}.`));
  saveState();
  renderAll();
}

function inventoryItems() {
  if (!Array.isArray(state.inventory)) state.inventory = [];
  return state.inventory;
}

function inventoryMovements() {
  if (!Array.isArray(state.inventoryMovements)) state.inventoryMovements = [];
  return state.inventoryMovements;
}

function inventoryItemById(id) {
  return inventoryItems().find((item) => item.id === id);
}

function activeInventoryItems() {
  return inventoryItems().filter((item) => item.status !== "Inactive");
}

function formatQuantity(value) {
  const amount = Number(value || 0);
  return Number.isInteger(amount) ? String(amount) : amount.toFixed(2);
}

function inventoryStockValue() {
  return inventoryItems().reduce((sum, item) => sum + Number(item.stockOnHand || 0) * Number(item.unitCost || 0), 0);
}

function lowStockItems() {
  return inventoryItems().filter((item) => Number(item.stockOnHand || 0) <= Number(item.reorderLevel || 0));
}

function shrinkRiskMovements() {
  return inventoryMovements().filter((movement) => movement.type === "Count" && Number(movement.variance || 0) < 0);
}

function shrinkRiskValue() {
  return shrinkRiskMovements().reduce((sum, movement) => {
    const item = inventoryItemById(movement.itemId);
    return sum + Math.abs(Number(movement.variance || 0)) * Number(item?.unitCost || movement.unitCost || 0);
  }, 0);
}

function inventoryStatus(item) {
  const stock = Number(item.stockOnHand || 0);
  const reorder = Number(item.reorderLevel || 0);
  const negativeVariance = shrinkRiskMovements().some((movement) => movement.itemId === item.id);
  if (stock < 0) return { label: "Over-issued", tone: "danger" };
  if (negativeVariance && item.secured) return { label: "Audit", tone: "danger" };
  if (stock <= reorder) return { label: "Reorder", tone: "dark" };
  return { label: "Stable", tone: "success" };
}

function inventoryMovementParty(movement) {
  const employee = employeeById(movement.employeeId);
  if (employee) return `${employee.name} / ${employee.staffId}`;
  return movement.reference || "Operations";
}

function fillInventorySelect(selector) {
  const element = document.querySelector(selector);
  if (!element) return;
  const current = element.value;
  element.innerHTML = activeInventoryItems().map((item) => `
    <option value="${item.id}">${escapeHtml(item.name)} / ${formatQuantity(item.stockOnHand)} ${escapeHtml(item.unit)}</option>
  `).join("");
  if (activeInventoryItems().some((item) => item.id === current)) element.value = current;
}

function renderInventory() {
  const metricGrid = document.querySelector("#inventoryMetricGrid");
  if (!metricGrid) return;
  fillInventorySelect("#inventoryIssueItem");
  fillInventorySelect("#inventoryCountItem");
  fillEmployeeSelect("#inventoryIssueEmployee", activeEmployees());
  fillEmployeeSelect("#inventoryCountEmployee", activeEmployees());

  document.querySelectorAll("#inventoryPurchaseForm input, #inventoryPurchaseForm select, #inventoryPurchaseForm button, #inventoryIssueForm input, #inventoryIssueForm select, #inventoryIssueForm button, #inventoryCountForm input, #inventoryCountForm select, #inventoryCountForm button").forEach((item) => {
    item.disabled = !canManageOperations();
  });

  const lows = lowStockItems();
  const shrinkRisks = shrinkRiskMovements();
  const securedCount = inventoryItems().filter((item) => item.secured).length;
  metricGrid.innerHTML = [
    metric("Stock value", formatMoney(inventoryStockValue()), `${inventoryItems().length} tracked supplies`, "boxes"),
    metric("Reorder alerts", String(lows.length), `${lows.slice(0, 2).map((item) => item.name).join(", ") || "All stocked"}`, "bell-ring"),
    metric("Locked items", String(securedCount), "High-value supplies under audit", "lock-keyhole"),
    metric("Variance exposure", formatMoney(shrinkRiskValue()), `${shrinkRisks.length} count variance flags`, "shield-alert")
  ].join("");

  const alerts = [];
  if (lows.length) alerts.push(noticeItem("Reorder list ready", `${lows.length} supplies are at or below reorder level.`, "warm"));
  if (shrinkRisks.length) alerts.push(noticeItem("Shrinkage watch", `${shrinkRisks.length} stock count variances require manager review.`, "warm"));
  if (!alerts.length) alerts.push(noticeItem("Inventory clean", "Stock controls show no reorder or variance alerts.", "neutral"));
  document.querySelector("#inventoryAlertList").innerHTML = alerts.join("");
  document.querySelector("#inventoryItemCount").textContent = `${inventoryItems().length} items`;

  document.querySelector("#inventoryRows").innerHTML = inventoryItems()
    .slice()
    .sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name))
    .map((item) => {
      const status = inventoryStatus(item);
      return `
        <tr>
          <td>${escapeHtml(item.name)}<br><span class="tag">${escapeHtml(item.category)}</span>${item.secured ? ` <span class="tag dark">Locked</span>` : ""}</td>
          <td>${formatQuantity(item.stockOnHand)} ${escapeHtml(item.unit)}</td>
          <td>${formatQuantity(item.reorderLevel)} ${escapeHtml(item.unit)}</td>
          <td>${formatMoney(Number(item.stockOnHand || 0) * Number(item.unitCost || 0))}<br><small>${formatMoney(item.unitCost)} each</small></td>
          <td>${escapeHtml(item.location)}<br><small>${escapeHtml(item.supplier)}</small></td>
          <td><span class="tag ${status.tone}">${escapeHtml(status.label)}</span></td>
        </tr>
      `;
    }).join("");

  const movements = inventoryMovements().slice().sort((a, b) => (b.at || b.date).localeCompare(a.at || a.date));
  document.querySelector("#inventoryMovementCount").textContent = `${movements.length} logs`;
  document.querySelector("#inventoryMovementRows").innerHTML = movements.slice(0, 28).map((movement) => {
    const item = inventoryItemById(movement.itemId);
    const variance = movement.type === "Count" ? Number(movement.variance || 0) : "";
    const varianceText = variance === "" ? "-" : `${variance > 0 ? "+" : ""}${formatQuantity(variance)}`;
    return `
      <tr>
        <td>${displayDate(movement.date)}</td>
        <td><span class="tag ${movement.type === "Count" && variance < 0 ? "danger" : movement.type === "Purchase" ? "success" : "dark"}">${escapeHtml(movement.type)}</span></td>
        <td>${escapeHtml(item?.name || "Unknown item")}</td>
        <td>${formatQuantity(movement.quantity)} ${escapeHtml(item?.unit || "")}</td>
        <td>${escapeHtml(inventoryMovementParty(movement))}</td>
        <td>${escapeHtml(varianceText)}</td>
        <td>${escapeHtml(movement.note || "")}</td>
      </tr>
    `;
  }).join("");
}

function addInventoryPurchase(event) {
  event.preventDefault();
  if (guardManagerMutation()) return;
  const name = document.querySelector("#inventoryItemName").value.trim();
  const quantity = Number(document.querySelector("#inventoryQuantity").value || 0);
  const unitCost = Number(document.querySelector("#inventoryUnitCost").value || 0);
  if (!name || quantity <= 0) return;
  const category = document.querySelector("#inventoryCategory").value;
  const unit = document.querySelector("#inventoryUnit").value;
  const supplier = document.querySelector("#inventorySupplier").value.trim();
  const location = document.querySelector("#inventoryLocation").value.trim();
  const reorderLevel = Number(document.querySelector("#inventoryReorderLevel").value || 0);
  const secured = document.querySelector("#inventorySecureItem").value === "true";
  const existing = inventoryItems().find((item) => item.name.toLowerCase() === name.toLowerCase() && item.category === category);
  const item = existing || inventoryItem(name, category, 0, unit, unitCost, reorderLevel, supplier, location, secured);
  if (!existing) inventoryItems().push(item);
  Object.assign(item, {
    unit,
    unitCost,
    supplier,
    location,
    reorderLevel,
    secured,
    stockOnHand: round(Number(item.stockOnHand || 0) + quantity),
    lastPurchase: toIsoDate(new Date()),
    status: "Active"
  });
  inventoryMovements().unshift(inventoryMovement(item.id, "Purchase", quantity, unitCost, "", supplier, "Stock purchase received.", toIsoDate(new Date())));
  state.activity.unshift(audit("Inventory", `Logged purchase of ${formatQuantity(quantity)} ${unit} of ${name}.`));
  event.target.reset();
  document.querySelector("#inventoryReorderLevel").value = 5;
  saveState();
  renderAll();
}

function issueInventoryItem(event) {
  event.preventDefault();
  if (guardManagerMutation()) return;
  const item = inventoryItemById(document.querySelector("#inventoryIssueItem").value);
  const quantity = Number(document.querySelector("#inventoryIssueQuantity").value || 0);
  if (!item || quantity <= 0) return;
  const employeeId = document.querySelector("#inventoryIssueEmployee").value;
  const note = document.querySelector("#inventoryIssueNote").value.trim() || "Staff supply issue";
  item.stockOnHand = round(Number(item.stockOnHand || 0) - quantity);
  inventoryMovements().unshift(inventoryMovement(item.id, "Issue", quantity, item.unitCost, employeeId, "Staff issue", note, toIsoDate(new Date())));
  const employee = employeeById(employeeId);
  state.activity.unshift(audit("Inventory", `Issued ${formatQuantity(quantity)} ${item.unit} of ${item.name} to ${employee?.name || "staff"}.`));
  event.target.reset();
  saveState();
  renderAll();
}

function countInventoryItem(event) {
  event.preventDefault();
  if (guardManagerMutation()) return;
  const item = inventoryItemById(document.querySelector("#inventoryCountItem").value);
  const counted = Number(document.querySelector("#inventoryCountQuantity").value || 0);
  if (!item || counted < 0) return;
  const employeeId = document.querySelector("#inventoryCountEmployee").value;
  const expected = Number(item.stockOnHand || 0);
  const variance = round(counted - expected);
  const note = document.querySelector("#inventoryCountNote").value.trim() || "Physical stock count";
  item.stockOnHand = round(counted);
  const countRecord = {
    id: uid("cnt"),
    itemId: item.id,
    date: toIsoDate(new Date()),
    expected: round(expected),
    counted: round(counted),
    variance,
    employeeId,
    note
  };
  state.inventoryCounts.push(countRecord);
  inventoryMovements().unshift(inventoryMovement(item.id, "Count", variance, item.unitCost, employeeId, "Physical count", note, countRecord.date, {
    expected: countRecord.expected,
    counted: countRecord.counted,
    variance
  }));
  const employee = employeeById(employeeId);
  const tone = variance < 0 ? "variance flagged" : "count reconciled";
  state.activity.unshift(audit("Inventory", `${item.name} ${tone} by ${employee?.name || "manager"} (${variance > 0 ? "+" : ""}${formatQuantity(variance)} ${item.unit}).`));
  event.target.reset();
  saveState();
  renderAll();
}

function renderPortal() {
  fillEmployeeSelect("#portalEmployee", activeEmployees());
  const portalSelect = document.querySelector("#portalEmployee");
  const portalSelector = document.querySelector(".portal-select");
  const portalAuth = document.querySelector("#portalAuth");
  portalSelector.hidden = isStaffMode();

  if (isStaffMode()) {
    if (!signedInEmployee()) {
      portalAuth.hidden = false;
      portalAuth.innerHTML = staffSignInMarkup();
      document.querySelector("#portalProfile").innerHTML = noticeItem("Staff portal locked", "Sign in with your name and Staff ID to see your own analytics.", "warm");
      document.querySelector("#portalSchedule").innerHTML = noticeItem("Team hours hidden", "Salon hours appear after sign-in.", "neutral");
      document.querySelector("#portalPayslips").innerHTML = noticeItem("Payslips hidden", "Your payroll information appears after sign-in.", "neutral");
      return;
    }
    portalAuth.hidden = false;
    portalAuth.innerHTML = `
      <div class="signed-in-banner">
        <div>
          <span class="micro-label">Staff Portal</span>
          <h3>Signed in as ${escapeHtml(signedInEmployee().name)}</h3>
          <p>Read-only access is active. You can view your own attendance, salon hours, service analytics, and generate your PDF payslip.</p>
        </div>
        <button class="soft-button" type="button" data-staff-signout><i data-lucide="log-out"></i><span>Sign out</span></button>
      </div>
    `;
  } else {
    portalAuth.hidden = false;
    portalAuth.innerHTML = `
      <div class="signed-in-banner">
        <div>
          <span class="micro-label">Admin Preview</span>
          <h3>Manager portal preview</h3>
          <p>Select a staff member to preview what their private portal shows.</p>
        </div>
        <span class="chip">Admin access</span>
      </div>
    `;
  }

  const employeeId = isStaffMode() ? state.signedInEmployeeId : (portalSelect.value || selectedEmployeeId);
  if (!portalSelect.value) portalSelect.value = selectedEmployeeId;
  const employee = employeeById(employeeId) || employeeById(selectedEmployeeId) || activeEmployees()[0];
  if (!employee) return;
  portalSelect.value = employee.id;
  const stats = weeklyStats(employee.id);
  const run = latestPayrollRun();
  const record = run.records.find((item) => item.employeeId === employee.id);

  document.querySelector("#portalProfile").innerHTML = `
    <div class="portal-card-head">
      <div class="avatar">${escapeHtml(employee.name.split(" ").map((part) => part[0]).join("").slice(0, 2))}</div>
      <div>
        <h3>${escapeHtml(employee.name)}</h3>
        <span class="micro-label">${escapeHtml(employee.staffId)} / ${escapeHtml(employee.role)}</span>
      </div>
    </div>
    <div class="portal-lines">
      <div class="portal-line"><div><strong>Hours worked</strong><span>Current pay period</span></div><b>${formatHours(stats.paidHours)}</b></div>
      <div class="portal-line"><div><strong>Salary basis</strong><span>Guaranteed payroll base</span></div><b>${escapeHtml(salaryLabelFor(employee))}</b></div>
      <div class="portal-line"><div><strong>Lunch deductions</strong><span>Automatic unpaid lunch</span></div><b>${formatHours(stats.lunchDeductionHours)}</b></div>
      <div class="portal-line"><div><strong>Weekly service sales</strong><span>Commission tier basis</span></div><b>${formatMoney(stats.serviceRevenue)}</b></div>
      <div class="portal-line"><div><strong>Commission tier</strong><span>${commissionRangeLabel(stats.commissionTier)}</span></div><b>${stats.commissionTier.serviceRate}%</b></div>
      <div class="portal-line"><div><strong>Commission earned</strong><span>Based on weekly service sales</span></div><b>${formatMoney(stats.commission)}</b></div>
      <div class="portal-line"><div><strong>Tips earned</strong><span>Current pay period</span></div><b>${formatMoney(stats.tips)}</b></div>
      <div class="portal-line"><div><strong>Service revenue</strong><span>Tracked completed services</span></div><b>${formatMoney(stats.serviceRevenue)}</b></div>
      <div class="portal-line"><div><strong>Payslip email</strong><span>PDF delivery address</span></div><b>${escapeHtml(employee.email)}</b></div>
      <div class="portal-line"><div><strong>Phone</strong><span>Contact record</span></div><b>${escapeHtml(employee.phone || "Not set")}</b></div>
      <div class="portal-line"><div><strong>Emergency contact</strong><span>Manager-held record</span></div><b>${escapeHtml(employee.emergencyContact || "Not set")}</b></div>
      <div class="portal-line"><div><strong>Address</strong><span>Manager-held record</span></div><b>${escapeHtml(employee.address || "Not set")}</b></div>
      <div class="portal-line"><div><strong>Attendance alerts</strong><span>Late or missed punch flags</span></div><b>${stats.late + stats.missed}</b></div>
    </div>
  `;

  document.querySelector("#portalSchedule").innerHTML = `
    <div class="card-head">
      <div><span class="micro-label">Salon Hours</span><h3>Team operating hours</h3></div>
      <span class="chip">Common hours</span>
    </div>
    <div class="portal-lines">
      ${periodDates().map((date) => {
        const hours = getBusinessHours(date);
        return `<div class="portal-line"><div><strong>${displayDate(date)}</strong><span>All staff follow salon hours</span></div><b>${hours.label}</b></div>`;
      }).join("")}
    </div>
  `;

  document.querySelector("#portalPayslips").innerHTML = record ? `
    <div class="card-head">
      <div><span class="micro-label">Employee PDF Payslip</span><h3>${displayDate(record.payPeriodStart)}-${displayDate(record.payPeriodEnd)}</h3></div>
      <button class="soft-button" type="button" data-pdf-payslip="${record.employeeId}"><i data-lucide="file-down"></i><span>Generate PDF</span></button>
    </div>
    ${payslipMarkup(record)}
  ` : noticeItem("No payslip available", "Payroll has not been generated for this period.", "warm");
}

function staffSignInMarkup() {
  const options = activeEmployees().map((employee) => `<option value="${employee.id}">${escapeHtml(employee.name)}</option>`).join("");
  return `
    <form class="staff-login-form" id="staffSignInForm">
      <div>
        <span class="micro-label">Staff Sign In</span>
        <h3>Your private employee portal</h3>
        <p>Use your own name and Staff ID. Staff accounts are read-only and only show your personal records and PDF payslip.</p>
      </div>
      ${portalError ? `<div class="portal-error">${escapeHtml(portalError)}</div>` : ""}
      <div class="form-grid">
        <label>Name<select id="staffSignEmployee">${options}</select></label>
        <label>Staff ID<input id="staffSignId" placeholder="Example: TAN-001" required></label>
      </div>
      <button class="gold-button full" type="submit"><i data-lucide="log-in"></i><span>Open my portal</span></button>
    </form>
    ${adminUnlockMarkup()}
  `;
}

function adminUnlockMarkup() {
  return `
    <form class="admin-unlock-form" id="adminUnlockForm">
      <label>Owner unlock<input id="adminUnlockCode" type="password" placeholder="Owner PIN"></label>
      <button class="soft-button" type="submit"><i data-lucide="shield-check"></i><span>Admin unlock</span></button>
    </form>
  `;
}

function renderSecurity() {
  document.querySelector("#activityCount").textContent = state.activity.length;
  document.querySelector("#activityLog").innerHTML = state.activity.slice(0, 8).map((entry) => `
    <div class="notice">
      <div>
        <strong>${escapeHtml(entry.actor)}</strong>
        <span>${escapeHtml(entry.message)}</span>
      </div>
      <span class="chip">${new Date(entry.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
    </div>
  `).join("");
}

function openView(name) {
  if (!isAuthenticated()) return;
  if (!roleAllowedView(name)) {
    name = isFrontDeskMode() ? "bookkeeping" : isStaffMode() ? "portal" : "dashboard";
  }
  views.forEach((view) => view.classList.toggle("is-active", view.dataset.view === name));
  navButtons.forEach((button) => {
    if (button.dataset.viewTarget) button.classList.toggle("is-active", button.dataset.viewTarget === name);
  });
  if (name === "services") syncServicePaymentStatus();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function openAccessDialog() {
  document.querySelector("#accessCode").value = "";
  document.querySelector("#accessError").hidden = true;
  document.querySelector("#accessError").textContent = "";
  accessDialog.showModal();
  refreshIcons();
}

function openEmployeeDialog(employeeId = null) {
  if (guardStaffMutation()) return;
  const employee = employeeId ? employeeById(employeeId) : null;
  const tierSelect = document.querySelector("#employeeCommissionTier");
  tierSelect.innerHTML = commissionTiers().map((tier) => `<option value="${tier.id}">${tier.serviceRate}% / ${commissionRangeLabel(tier)}</option>`).join("");
  document.querySelector("#employeeDialogTitle").textContent = employee ? "Edit employee" : "Add employee";
  document.querySelector("#employeeId").value = employee?.id || "";
  document.querySelector("#employeeName").value = employee?.name || "";
  document.querySelector("#employeeStaffId").value = employee?.staffId || `TAN-${String(state.employees.length + 1).padStart(3, "0")}`;
  document.querySelector("#employeeRole").value = employee?.role || "Nail Technician";
  document.querySelector("#employeeStatus").value = employee?.status || "Active";
  document.querySelector("#employeeBaseSalary").value = baseSalaryFor(employee);
  tierSelect.value = weeklyStats(employee?.id).commissionTier.id;
  document.querySelector("#employeeEmail").value = employee?.email || "";
  document.querySelector("#employeePhone").value = employee?.phone || "";
  document.querySelector("#employeeEmergencyContact").value = employee?.emergencyContact || "";
  document.querySelector("#employeeAddress").value = employee?.address || "";
  document.querySelector("#employeePermissions").value = employee?.permissions?.join(", ") || "Services, Portal";
  employeeDialog.showModal();
  refreshIcons();
}

function syncEmployeeSalaryFieldForRole() {
  const role = document.querySelector("#employeeRole")?.value;
  const monthlySalary = defaultMonthlySalaryForRole(role);
  if (!monthlySalary) return;
  document.querySelector("#employeeBaseSalary").value = weeklySalaryFromMonthly(monthlySalary);
}

function saveEmployeeFromForm(event) {
  event.preventDefault();
  if (guardStaffMutation()) return;
  const id = document.querySelector("#employeeId").value || uid("emp");
  const existing = employeeById(id);
  const role = document.querySelector("#employeeRole").value;
  const defaultMonthlySalary = defaultMonthlySalaryForRole(role);
  const formBaseSalary = Number(document.querySelector("#employeeBaseSalary").value || state.settings.baseSalary || WEEKLY_BASE_SALARY);
  const monthlySalary = defaultMonthlySalary ? Number(existing?.monthlySalary || defaultMonthlySalary) : 0;
  const baseSalary = monthlySalary ? weeklySalaryFromMonthly(monthlySalary) : formBaseSalary;
  const employee = {
    id,
    staffId: document.querySelector("#employeeStaffId").value.trim(),
    name: document.querySelector("#employeeName").value.trim(),
    role,
    status: document.querySelector("#employeeStatus").value,
    monthlySalary,
    baseSalary,
    wage: existing?.wage || overtimeHourlyRateFor({ baseSalary }),
    commissionRate: 0,
    email: document.querySelector("#employeeEmail").value.trim(),
    phone: document.querySelector("#employeePhone").value.trim(),
    emergencyContact: document.querySelector("#employeeEmergencyContact").value.trim(),
    address: document.querySelector("#employeeAddress").value.trim(),
    hired: existing?.hired || toIsoDate(new Date()),
    permissions: document.querySelector("#employeePermissions").value.split(",").map((item) => item.trim()).filter(Boolean)
  };
  if (existing) {
    Object.assign(existing, employee);
    state.activity.unshift(audit("Admin", `Updated employee profile for ${employee.name}.`));
  } else {
    state.employees.push(employee);
    state.adjustments[employee.id] = { bonus: 0, deduction: 0 };
    state.activity.unshift(audit("Admin", `Added employee profile for ${employee.name}.`));
  }
  selectedEmployeeId = employee.id;
  saveState();
  employeeDialog.close();
  renderAll();
}

function handlePunch(type) {
  if (!canUseTimeClock()) {
    portalError = "Time clock access is available after signing in with your Staff ID.";
    openView(isFrontDeskMode() ? "services" : "portal");
    renderPortal();
    refreshIcons();
    return;
  }
  const employeeId = isStaffMode() ? state.signedInEmployeeId : document.querySelector("#clockEmployee").value;
  const employee = employeeById(employeeId);
  if (!employee) return;
  const today = toIsoDate(new Date());
  let entry = state.attendance.find((item) => item.employeeId === employeeId && item.date === today);
  if (!entry) {
    entry = { id: uid("log"), employeeId, date: today, clockIn: null, lunchStart: null, lunchEnd: null, clockOut: null, override: false, note: "" };
    state.attendance.push(entry);
  }
  const now = new Date();
  const time = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  entry[type] = time;
  state.activity.unshift(audit("Time Clock", `${employee?.name || "Employee"} recorded ${type.replace(/[A-Z]/g, " $&").toLowerCase()}.`));
  document.querySelector("#clockStationStatus").textContent = "Recorded";
  saveState();
  renderAll();
}

function applyOverride(event) {
  event.preventDefault();
  if (guardManagerMutation()) return;
  const employeeId = document.querySelector("#overrideEmployee").value;
  const date = document.querySelector("#overrideDate").value || state.payPeriodStart;
  const existing = state.attendance.find((entry) => entry.employeeId === employeeId && entry.date === date);
  const values = {
    id: existing?.id || uid("log"),
    employeeId,
    date,
    clockIn: document.querySelector("#overrideIn").value,
    lunchStart: null,
    lunchEnd: null,
    clockOut: document.querySelector("#overrideOut").value,
    override: true,
    note: document.querySelector("#overrideNote").value.trim() || "Manager override"
  };
  if (existing) Object.assign(existing, values);
  else state.attendance.push(values);
  const employee = employeeById(employeeId);
  state.activity.unshift(audit("Manager", `Applied attendance override for ${employee?.name || "employee"} on ${displayDate(date)}.`));
  saveState();
  renderAll();
  event.target.reset();
}

function saveTaxSettings(event) {
  event.preventDefault();
  if (guardStaffMutation()) return;
  state.settings.baseSalary = Number(document.querySelector("#baseSalary").value || WEEKLY_BASE_SALARY);
  state.settings.paye = Number(document.querySelector("#ratePaye").value || 0);
  state.settings.payeWeeklyThreshold = Number(document.querySelector("#payeWeeklyThreshold").value || 0);
  state.settings.payeHigherRate = Number(document.querySelector("#payeHigherRate").value || state.settings.paye || 0);
  state.settings.payeHigherRateWeeklyThreshold = Number(document.querySelector("#payeHigherRateWeeklyThreshold").value || PAYE_HIGHER_RATE_WEEKLY_THRESHOLD);
  state.settings.nis = Number(document.querySelector("#rateNis").value || 0);
  state.settings.nisWeeklyCeiling = Number(document.querySelector("#nisWeeklyCeiling").value || NIS_WEEKLY_CEILING);
  state.settings.nht = Number(document.querySelector("#rateNht").value || 0);
  state.settings.educationTax = Number(document.querySelector("#rateEdu").value || 0);
  state.settings.overtimeAfter = Number(document.querySelector("#overtimeAfter").value || 40);
  state.settings.overtimeMultiplier = Number(document.querySelector("#overtimeMultiplier").value || 1.5);
  state.settings.frontDeskMonthlySalary = Number(document.querySelector("#frontDeskMonthlySalary").value || FRONT_DESK_MONTHLY_SALARY);
  state.settings.managerMonthlySalary = Number(document.querySelector("#managerMonthlySalary").value || MANAGER_MONTHLY_SALARY);
  state.settings.monthlySalaryDivisor = Number(document.querySelector("#monthlySalaryDivisor").value || MONTHLY_SALARY_DIVISOR);
  state.settings.salesBonusThreshold = Number(document.querySelector("#salesBonusThreshold").value || 0);
  state.settings.salesBonusAmount = Number(document.querySelector("#salesBonusAmount").value || 0);
  state.settings.lateDeductionAmount = Number(document.querySelector("#lateDeductionAmount").value || 0);
  state.settings.missedPunchDeductionAmount = Number(document.querySelector("#missedPunchDeductionAmount").value || 0);
  state.employees = state.employees.map((employee) => {
    const monthlySalary = Number(defaultMonthlySalaryForRole(employee.role) || employee.monthlySalary || 0);
    return monthlySalary
      ? { ...employee, monthlySalary, baseSalary: weeklySalaryFromMonthly(monthlySalary) }
      : employee;
  });
  state.activity.unshift(audit("Admin", "Updated salary, sales bonus, policy deduction, Jamaican statutory deduction, and overtime settings."));
  saveState();
  renderAll();
}

function addPolicyDeduction(event) {
  event.preventDefault();
  if (guardManagerMutation()) return;
  const employeeId = document.querySelector("#policyDeductionEmployee").value;
  const amount = Number(document.querySelector("#policyDeductionAmount").value || 0);
  if (!employeeId || amount <= 0) return;
  const entry = {
    id: uid("rule"),
    employeeId,
    date: document.querySelector("#policyDeductionDate").value || businessEntryDate(),
    reason: document.querySelector("#policyDeductionReason").value,
    amount,
    note: document.querySelector("#policyDeductionNote").value.trim(),
    actor: state.activeRole,
    at: new Date().toISOString()
  };
  state.ruleDeductions.push(entry);
  const employee = employeeById(employeeId);
  state.activity.unshift(audit("Payroll", `Rule deduction recorded for ${employee?.name || "staff"}: ${formatMoney(amount)}.`));
  event.target.reset();
  document.querySelector("#policyDeductionDate").value = entry.date;
  saveState();
  renderAll();
}

function addSalaryAdvance(event) {
  event.preventDefault();
  if (guardManagerMutation()) return;
  const employeeId = document.querySelector("#salaryAdvanceEmployee").value;
  const amount = Number(document.querySelector("#salaryAdvanceAmount").value || 0);
  if (!employeeId || amount <= 0) return;
  const entry = {
    id: uid("advance"),
    employeeId,
    date: document.querySelector("#salaryAdvanceDate").value || businessEntryDate(),
    amount,
    note: document.querySelector("#salaryAdvanceNote").value.trim(),
    actor: state.activeRole,
    at: new Date().toISOString()
  };
  state.salaryAdvances = state.salaryAdvances || [];
  state.salaryAdvances.push(entry);
  const employee = employeeById(employeeId);
  state.activity.unshift(audit("Payroll", `Salary advance recorded for ${employee?.name || "staff"}: ${formatMoney(amount)}.`));
  event.target.reset();
  document.querySelector("#salaryAdvanceDate").value = entry.date;
  saveState();
  renderAll();
}

function businessEntryDate() {
  const today = toIsoDate(new Date());
  return periodDates().includes(today) && getBusinessHours(today).open ? today : periodEnd();
}

function selectedServiceName() {
  const selected = catalogItemById(document.querySelector("#serviceType").value);
  return selected?.name || "Unlisted Service";
}

function serviceTotalDue() {
  return Number(document.querySelector("#serviceAmount")?.value || 0) + Number(document.querySelector("#serviceTips")?.value || 0);
}

function servicePaymentSplit() {
  return [
    { channel: "Cash", amount: Number(document.querySelector("#serviceCashPayment")?.value || 0) },
    { channel: "NCB POS Machine", amount: Number(document.querySelector("#serviceNcbPayment")?.value || 0) },
    { channel: "FYGARO", amount: Number(document.querySelector("#serviceFygaroPayment")?.value || 0) },
    { channel: "Bank Transfer", amount: Number(document.querySelector("#serviceTransferPayment")?.value || 0) },
    { channel: "Other", amount: Number(document.querySelector("#serviceOtherPayment")?.value || 0) }
  ].filter((item) => item.amount > 0);
}

function servicePaymentTotal() {
  return servicePaymentSplit().reduce((sum, item) => sum + item.amount, 0);
}

function servicePaymentSummary(split = []) {
  if (!split.length) return "No receipt split";
  return split.map((item) => `${item.channel}: ${formatMoney(item.amount)}`).join(" / ");
}

function syncServicePaymentStatus() {
  const status = document.querySelector("#servicePaymentStatus");
  const chip = document.querySelector("#servicePaymentChip");
  if (!status || !chip) return;
  const expected = serviceTotalDue();
  const paid = servicePaymentTotal();
  const balance = round(expected - paid);
  const balanced = Math.round(balance) === 0 && expected > 0;
  const overpaid = balance < 0;
  chip.textContent = balanced ? "Balanced" : overpaid ? "Overpaid" : "Balance due";
  chip.className = `chip ${balanced ? "success" : overpaid ? "danger" : "warm"}`;
  status.className = `payment-status ${balanced ? "is-balanced" : "is-warning"}`;
  status.textContent = `${formatMoney(expected)} due / ${formatMoney(paid)} paid / ${formatMoney(balance)} balance`;
}

function syncServiceForm() {
  const selected = catalogItemById(document.querySelector("#serviceType").value);
  if (selected) document.querySelector("#serviceAmount").value = selected.price;
  syncServicePaymentStatus();
}

function addServiceFromForm(event) {
  event.preventDefault();
  if (guardServiceEntry()) return;
  const employeeId = document.querySelector("#serviceEmployee").value;
  const serviceType = selectedServiceName();
  const serviceDate = businessEntryDate();
  const serviceAmount = Number(document.querySelector("#serviceAmount").value || 0);
  const tips = Number(document.querySelector("#serviceTips").value || 0);
  const expectedPayment = serviceAmount + tips;
  const paymentSplit = servicePaymentSplit();
  const paidTotal = servicePaymentTotal();
  if (Math.round(paidTotal) !== Math.round(expectedPayment)) {
    syncServicePaymentStatus();
    document.querySelector("#servicePaymentStatus").textContent = `Payment split must equal ${formatMoney(expectedPayment)} before this service can be saved.`;
    return;
  }
  const entry = sale(
    employeeId,
    serviceDate,
    serviceType,
    serviceAmount,
    tips,
    {
      paymentSplit,
      paymentTotal: paidTotal,
      paymentReference: document.querySelector("#servicePaymentReference").value.trim()
    }
  );
  state.services.push(entry);
  const employee = employeeById(employeeId);
  const actor = isFrontDeskMode() ? "Front Desk" : "Services";
  paymentSplit.forEach((payment) => {
    bookkeepingEntries().unshift(bookEntry(
      serviceDate,
      "Sale Receipt",
      payment.channel,
      "Service sales",
      payment.amount,
      entry.paymentReference || entry.id,
      `${serviceType} for ${employee?.name || "technician"}${tips ? `; includes ${formatMoney(tips)} tips in service payment total` : ""}.`,
      actor
    ));
  });
  state.activity.unshift(audit(actor, `Recorded ${serviceType} for ${employee?.name || "technician"} with ${servicePaymentSummary(paymentSplit)}.`));
  event.target.reset();
  saveState();
  renderAll();
}

function addDemoService() {
  if (guardManagerMutation()) return;
  const pool = activeEmployees().filter((employee) => /Technician|Manager/i.test(employee.role));
  const employee = pool[Math.floor(Math.random() * pool.length)] || activeEmployees()[0];
  const services = activeServiceCatalog();
  const pick = services[Math.floor(Math.random() * services.length)] || serviceItem("Gel Pedicure", 6500);
  state.services.push(sale(employee.id, periodEnd(), pick.name, pick.price, 1500));
  state.activity.unshift(audit("Services", `Added demo service for ${employee.name}.`));
  saveState();
  renderAll();
}

function addServiceCatalogItem(event) {
  event.preventDefault();
  if (guardManagerMutation()) return;
  const name = document.querySelector("#catalogServiceName").value.trim();
  const price = Number(document.querySelector("#catalogServicePrice").value || 0);
  if (!name || price <= 0) return;
  state.serviceCatalog.push(serviceItem(name, price));
  state.activity.unshift(audit("Manager", `Added service menu item: ${name}.`));
  event.target.reset();
  saveState();
  renderAll();
}

function rotateSaturday() {
  if (guardManagerMutation()) return;
  const first = state.saturdayRotation.shift();
  if (first) state.saturdayRotation.push(first);
  const saturday = periodEnd();
  const saturdayShifts = state.schedule.filter((item) => item.date === saturday && /Saturday Lead|Tech/i.test(item.role));
  state.saturdayRotation.slice(0, saturdayShifts.length).forEach((employeeId, index) => {
    saturdayShifts[index].employeeId = employeeId;
  });
  state.activity.unshift(audit("Manager", "Rotated Saturday coverage queue."));
  saveState();
  renderAll();
}

function payslipMarkup(record) {
  return `
    <div class="payslip-sheet">
      <div class="payslip-brand">
        <div>
          <strong>Trudy'z Amazing Nails LTD</strong>
          <span>Luxury Payroll Payslip</span>
        </div>
        <span class="chip">${escapeHtml(record.staffId)}</span>
      </div>
      <div class="payslip-grid">
        <div class="payslip-line"><span>Employee</span><b>${escapeHtml(record.employeeName)}</b></div>
        <div class="payslip-line"><span>Payslip email</span><b>${escapeHtml(record.email || "No email")}</b></div>
        <div class="payslip-line"><span>Pay period</span><b>${displayDate(record.payPeriodStart)}-${displayDate(record.payPeriodEnd)}</b></div>
        <div class="payslip-line"><span>Payment date</span><b>${displayDate(record.paymentDate)}</b></div>
        <div class="payslip-line"><span>Salary basis</span><b>${record.monthlySalary ? `${formatMoney(record.monthlySalary)}/month` : "Weekly"}</b></div>
        <div class="payslip-line"><span>Weekly salary paid</span><b>${formatMoney(record.baseSalary || record.regularPay)}</b></div>
        <div class="payslip-line"><span>Hours worked</span><b>${formatHours(record.hoursWorked)}</b></div>
        <div class="payslip-line"><span>Lunch deductions</span><b>${formatHours(record.lunchDeductionHours)}</b></div>
        <div class="payslip-line"><span>Overtime hours</span><b>${formatHours(record.overtimeHours)}</b></div>
        <div class="payslip-line"><span>Commission earned</span><b>${formatMoney(record.commission)}</b></div>
        <div class="payslip-line"><span>Tips earned</span><b>${formatMoney(record.tips)}</b></div>
        <div class="payslip-line"><span>Sales threshold bonus</span><b>${formatMoney(record.bonus)}</b></div>
        <div class="payslip-line"><span>Total deductions</span><b>${formatMoney(record.deductions)}</b></div>
        <div class="payslip-line"><span>Salary advance deduction</span><b>${formatMoney(record.salaryAdvances || 0)}</b></div>
        <div class="payslip-line"><span>Late / missed punch deductions</span><b>${formatMoney((record.lateDeduction || 0) + (record.missedPunchDeduction || 0))}</b></div>
        <div class="payslip-line"><span>Rule-breaking deductions</span><b>${formatMoney(record.ruleBreakDeductions || 0)}</b></div>
        <div class="payslip-line"><span>Statutory deductions</span><b>${formatMoney(record.statutoryDeductionTotal || record.taxTotal)}</b></div>
        <div class="payslip-line"><span>PAYE weekly threshold</span><b>${formatMoney(record.payeThreshold || state.settings.payeWeeklyThreshold || 0)}</b></div>
        <div class="payslip-line"><span>PAYE chargeable income</span><b>${formatMoney(record.payeChargeableIncome || 0)}</b></div>
        <div class="payslip-line"><span>PAYE</span><b>${formatMoney(record.taxes.paye)}</b></div>
        <div class="payslip-line"><span>NIS</span><b>${formatMoney(record.taxes.nis)}</b></div>
        <div class="payslip-line"><span>NHT</span><b>${formatMoney(record.taxes.nht)}</b></div>
        <div class="payslip-line"><span>Education Tax</span><b>${formatMoney(record.taxes.educationTax)}</b></div>
      </div>
      <div class="payslip-net">
        <span>Final net pay</span>
        <strong>${formatMoney(record.netPay)}</strong>
      </div>
    </div>
  `;
}

function openPayslip(employeeId) {
  if (isStaffMode() && employeeId !== state.signedInEmployeeId) {
    guardStaffMutation();
    return;
  }
  const record = latestPayrollRun().records.find((item) => item.employeeId === employeeId);
  if (!record) return;
  selectedPayslip = record;
  document.querySelector("#payslipName").textContent = `${record.employeeName} / ${displayDate(record.payPeriodStart)}`;
  document.querySelector("#payslipPreview").innerHTML = payslipMarkup(record);
  payslipDialog.showModal();
  refreshIcons();
}

function payslipPdfLines(record) {
  return [
    ["Employee", record.employeeName],
    ["Staff ID", record.staffId],
    ["Payslip email", record.email || "No email"],
    ["Role", record.role],
    ["Pay period", `${displayDate(record.payPeriodStart)} to ${displayDate(record.payPeriodEnd)}`],
    ["Payment date", displayDate(record.paymentDate)],
    ["Salary basis", record.monthlySalary ? `${formatMoney(record.monthlySalary)} monthly, paid ${formatMoney(record.baseSalary || record.regularPay)} weekly` : "Weekly salary"],
    ["Weekly salary paid", formatMoney(record.baseSalary || record.regularPay)],
    ["Hours worked", formatHours(record.hoursWorked)],
    ["Lunch deductions", formatHours(record.lunchDeductionHours)],
    ["Overtime hours", formatHours(record.overtimeHours)],
    ["Overtime hourly equivalent", formatMoney(record.hourlyWage)],
    ["Base salary paid", formatMoney(record.regularPay)],
    ["Overtime pay", formatMoney(record.overtimePay)],
    ["Commission earned", formatMoney(record.commission)],
    ["Tips earned", formatMoney(record.tips)],
    ["Sales threshold bonus", formatMoney(record.bonus)],
    ["Total deductions", formatMoney(record.deductions)],
    ["Salary advance deduction", formatMoney(record.salaryAdvances || 0)],
    ["Late deductions", formatMoney(record.lateDeduction || 0)],
    ["Missed punch deductions", formatMoney(record.missedPunchDeduction || 0)],
    ["Rule-breaking deductions", formatMoney(record.ruleBreakDeductions || 0)],
    ["Statutory deductions", formatMoney(record.statutoryDeductionTotal || record.taxTotal)],
    ["PAYE weekly threshold", formatMoney(record.payeThreshold || state.settings.payeWeeklyThreshold || 0)],
    ["PAYE chargeable income", formatMoney(record.payeChargeableIncome || 0)],
    ["PAYE", formatMoney(record.taxes.paye)],
    ["NIS", formatMoney(record.taxes.nis)],
    ["NHT", formatMoney(record.taxes.nht)],
    ["Education Tax", formatMoney(record.taxes.educationTax)],
    ["Gross pay", formatMoney(record.grossPay)],
    ["Final net pay", formatMoney(record.netPay)]
  ];
}

function downloadPayslipPdf(record) {
  if (!record) return;
  if (isStaffMode() && record.employeeId !== state.signedInEmployeeId) {
    guardStaffMutation();
    return;
  }
  const pdf = buildPdf(record, payslipPdfLines(record));
  const blob = new Blob([pdf], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = payslipFilename(record);
  anchor.click();
  URL.revokeObjectURL(url);
}

function buildPdf(record, lines) {
  const content = [];
  const text = (x, y, size, value, font = "F1") => {
    content.push(`BT /${font} ${size} Tf ${x} ${y} Td (${escapePdf(value)}) Tj ET`);
  };
  content.push("0.96 0.88 0.73 rg 0 742 612 50 re f");
  content.push("0.09 0.06 0.05 rg 0 0 612 742 re f");
  content.push("0.99 0.97 0.94 rg 36 54 540 650 re f");
  content.push("0.86 0.71 0.43 RG 36 704 540 0 l S");
  text(54, 760, 22, "Trudy'z Amazing Nails LTD", "F2");
  text(54, 735, 11, "Luxury Payroll Payslip", "F1");
  text(390, 735, 11, `Payment Date: ${displayDate(record.paymentDate)}`, "F1");
  text(54, 680, 15, record.employeeName, "F2");
  text(54, 662, 10, `${record.staffId} / ${record.role}`, "F1");
  text(54, 638, 10, `Pay Period: ${displayDate(record.payPeriodStart)} to ${displayDate(record.payPeriodEnd)}`, "F1");
  let y = 604;
  const rowStep = lines.length > 28 ? 15 : 19;
  lines.forEach(([label, value], index) => {
    if (index === lines.length - 1) {
      content.push("0.09 0.06 0.05 rg 54 82 504 56 re f");
      text(70, 116, 11, "Final Net Pay", "F1");
      text(390, 106, 21, value, "F2");
      return;
    }
    content.push("0.74 0.61 0.42 RG 54 " + (y - 8) + " 504 0 l S");
    text(60, y, 9, label, "F1");
    text(370, y, 10, value, "F2");
    y -= rowStep;
  });
  const stream = content.join("\n");
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> /Contents 4 0 R >>",
    `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`,
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>"
  ];
  let pdf = "%PDF-1.4\n";
  const offsets = [0];
  objects.forEach((object, index) => {
    offsets.push(pdf.length);
    pdf += `${index + 1} 0 obj\n${object}\nendobj\n`;
  });
  const xref = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n`;
  pdf += "0000000000 65535 f \n";
  offsets.slice(1).forEach((offset) => {
    pdf += `${String(offset).padStart(10, "0")} 00000 n \n`;
  });
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return pdf;
}

function escapePdf(value) {
  return String(value ?? "").replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
}

function exportData() {
  if (guardStaffMutation()) return;
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = "trudyz-operations-export.json";
  anchor.click();
  URL.revokeObjectURL(url);
  state.activity.unshift(audit("Admin", "Exported operations data snapshot."));
  saveState();
  renderSecurity();
}

function exportExcelWorkbook() {
  if (guardStaffMutation()) return;
  const workbookXml = buildOperationsWorkbookXml();
  const blob = new Blob([workbookXml], { type: "application/vnd.ms-excel;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `Trudyz-Operations-Workbook-${toIsoDate(new Date())}.xls`;
  anchor.click();
  URL.revokeObjectURL(url);
  state.activity.unshift(audit("Admin", "Exported full operations Excel workbook."));
  saveState();
  renderAll();
}

function buildOperationsWorkbookXml() {
  const run = latestPayrollRun();
  const payrollRecords = run.records;
  const attendanceRows = state.attendance
    .slice()
    .sort((a, b) => `${a.date}${a.employeeId}`.localeCompare(`${b.date}${b.employeeId}`))
    .map((entry) => {
      const employee = employeeById(entry.employeeId);
      return [
        employee?.staffId || "",
        employee?.name || "Unknown",
        entry.date,
        formatTime(entry.clockIn),
        formatTime(entry.lunchStart),
        formatTime(entry.lunchEnd),
        formatTime(entry.clockOut),
        round(lunchMinutesFor(entry) / 60),
        paidHoursFor(entry),
        attendanceAlert(entry).join(", ") || "Clear",
        entry.override ? "Yes" : "No",
        entry.note || ""
      ];
    });

  const serviceRows = state.services
    .slice()
    .sort((a, b) => `${a.date}${a.employeeId}`.localeCompare(`${b.date}${b.employeeId}`))
    .map((entry) => {
      const employee = employeeById(entry.employeeId);
      const weeklySales = currentWeeklyServiceRevenue(entry.employeeId);
      const tier = commissionTierForWeeklySales(weeklySales);
      const split = entry.paymentSplit || [];
      return [
        entry.date,
        employee?.staffId || "",
        employee?.name || "Unknown",
        tier.name,
        commissionRangeLabel(tier),
        weeklySales,
        tier.serviceRate,
        entry.service,
        Number(entry.amount || 0),
        Number(entry.tips || 0),
        Number(entry.paymentTotal || 0),
        servicePaymentSummary(split),
        entry.paymentReference || "",
        serviceCommission(entry, employee),
        Number(entry.amount || 0)
      ];
    });

  const businessHoursRows = periodDates().map((date) => {
    const hours = getBusinessHours(date);
    return [
      date,
      hours.label,
      hours.open ? formatTime(hours.open) : "Closed",
      hours.close ? formatTime(hours.close) : "Closed",
      "All staff follow common salon operating hours"
    ];
  });

  const bookkeepingRows = bookkeepingEntries()
    .slice()
    .sort((a, b) => `${a.date}${a.type}`.localeCompare(`${b.date}${b.type}`))
    .map((entry) => [
      entry.date,
      entry.type,
      entry.channel,
      entry.category,
      entry.amount,
      entry.reference || "",
      entry.note || "",
      entry.actor || ""
    ]);

  const dailyCloseRows = (state.dailyClosings || []).map((close) => [
    close.date,
    close.serviceSales,
    close.tips || 0,
    close.expectedReceipts || close.serviceSales,
    close.receipts,
    close.expenses,
    close.deposits,
    close.transfers,
    close.variance,
    close.cash,
    close.ncb,
    close.fygaro,
    close.bankTransfer,
    close.closedBy || "",
    close.note || ""
  ]);

  const weeklyCloseRows = (state.weeklyClosings || []).map((close) => [
    close.payPeriodStart,
    close.payPeriodEnd,
    close.serviceSales,
    close.tips || 0,
    close.expectedReceipts || close.serviceSales,
    close.receipts,
    close.expenses,
    close.deposits,
    close.transfers,
    close.variance,
    close.cash,
    close.ncb,
    close.fygaro,
    close.bankTransfer,
    close.closedBy || ""
  ]);

  const employeeRows = state.employees.map((employee) => {
    const stats = weeklyStats(employee.id);
    const tier = stats.commissionTier;
    return [
      employee.staffId,
      employee.name,
      employee.role,
      employee.status,
      employee.email,
      employee.phone,
      employee.emergencyContact || "",
      employee.address || "",
      employee.hired,
      employee.monthlySalary || 0,
      baseSalaryFor(employee),
      overtimeHourlyRateFor(employee),
      tier.name,
      commissionRangeLabel(tier),
      stats.serviceRevenue,
      tier.serviceRate,
      stats.paidHours,
      stats.serviceRevenue,
      stats.commission,
      stats.tips,
      stats.late,
      stats.missed,
      employee.permissions.join(", ")
    ];
  });

  const payrollRows = payrollRecords.map((record) => [
    record.staffId,
    record.employeeName,
    record.role,
    record.email,
    record.payPeriodStart,
    record.payPeriodEnd,
    record.paymentDate,
    record.hoursWorked,
    record.lunchDeductionHours,
    record.monthlySalary || 0,
    record.baseSalary || record.regularPay,
    record.regularHours,
    record.overtimeHours,
    record.hourlyWage,
    record.regularPay,
    record.overtimePay,
    record.commission,
    record.tips,
    record.bonus,
    record.deductions,
    record.salaryAdvances || 0,
    record.lateDeduction || 0,
    record.missedPunchDeduction || 0,
    record.ruleBreakDeductions || 0,
    record.payeThreshold || 0,
    record.payeChargeableIncome || 0,
    record.nisCeiling || 0,
    record.taxes.paye,
    record.taxes.nis,
    record.taxes.nht,
    record.taxes.educationTax,
    record.statutoryDeductionTotal || record.taxTotal,
    record.grossPay,
    record.netPay
  ]);

  const revenue = weeklyRevenueByDay();
  const weeklyBooks = weeklyBookkeepingSummary();
  const summaryRows = [
    ["Metric", "Value"],
    ["Brand", "Trudy'z Amazing Nails LTD"],
    ["Generated", new Date().toLocaleString()],
    ["Pay period start", state.payPeriodStart],
    ["Pay period end", periodEnd()],
    ["Payment date", paymentDate()],
    ["Active staff", activeEmployees().length],
    ["Total payroll net", payrollRecords.reduce((sum, record) => sum + record.netPay, 0)],
    ["Total payroll gross", payrollRecords.reduce((sum, record) => sum + record.grossPay, 0)],
    ["Total weekly base salaries", payrollRecords.reduce((sum, record) => sum + (record.baseSalary || record.regularPay || 0), 0)],
    ["Total statutory deductions", payrollRecords.reduce((sum, record) => sum + (record.statutoryDeductionTotal || record.taxTotal), 0)],
    ["Tracked service revenue", serviceRows.reduce((sum, row) => sum + Number(row[8] || 0), 0)],
    ["Tracked tips", serviceRows.reduce((sum, row) => sum + Number(row[9] || 0), 0)],
    ["Tracked payments", serviceRows.reduce((sum, row) => sum + Number(row[10] || 0), 0)],
    ["Tracked commissions", serviceRows.reduce((sum, row) => sum + Number(row[13] || 0), 0)],
    ["Bookkeeping receipts", weeklyBooks.receipts],
    ["Bookkeeping expenses", weeklyBooks.expenses],
    ["Bookkeeping deposits", weeklyBooks.deposits],
    ["Bookkeeping transfers", weeklyBooks.transfers],
    ["Bookkeeping variance", weeklyBooks.variance],
    ["NCB POS receipts", weeklyBooks.ncb],
    ["FYGARO receipts", weeklyBooks.fygaro],
    ["Inventory stock value", inventoryStockValue()],
    ["Inventory reorder alerts", lowStockItems().length],
    ["Inventory variance exposure", shrinkRiskValue()],
    ["Missed punch alerts", state.attendance.filter((entry) => attendanceAlert(entry).includes("Missed punch")).length],
    ["Late arrival alerts", state.attendance.filter((entry) => attendanceAlert(entry).includes("Late")).length],
    [],
    ["Daily Revenue", "Amount"],
    ...revenue.map((day) => [day.date, day.total])
  ];

  const taxRows = [
    ["Deduction Setting", "Value"],
    ["Default weekly base salary", state.settings.baseSalary || WEEKLY_BASE_SALARY],
    ["PAYE %", state.settings.paye],
    ["PAYE weekly threshold", state.settings.payeWeeklyThreshold],
    ["PAYE higher rate %", state.settings.payeHigherRate],
    ["PAYE higher weekly threshold", state.settings.payeHigherRateWeeklyThreshold],
    ["NIS %", state.settings.nis],
    ["NIS weekly ceiling", state.settings.nisWeeklyCeiling],
    ["NHT %", state.settings.nht],
    ["Education Tax %", state.settings.educationTax],
    ["Overtime after hours", state.settings.overtimeAfter],
    ["Overtime multiplier", state.settings.overtimeMultiplier],
    ["Front Desk monthly salary", state.settings.frontDeskMonthlySalary],
    ["Manager monthly salary", state.settings.managerMonthlySalary],
    ["Monthly salary divisor", state.settings.monthlySalaryDivisor],
    ["Automatic lunch deduction minutes", state.settings.lunchDeductionMinutes],
    ["Sales bonus threshold", state.settings.salesBonusThreshold],
    ["Sales bonus amount", state.settings.salesBonusAmount],
    ["Late deduction amount", state.settings.lateDeductionAmount],
    ["Missed punch deduction amount", state.settings.missedPunchDeductionAmount],
    ["Commission basis", "Weekly service sales"]
  ];

  const tierRows = commissionTiers().map((tier) => [
    tier.id,
    tier.name,
    tier.minSales,
    tier.maxSales === null || tier.maxSales === undefined ? "No cap" : tier.maxSales,
    tier.serviceRate
  ]);

  const activityRows = state.activity.map((entry) => [
    entry.at,
    entry.actor,
    entry.message
  ]);

  const catalogRows = serviceCatalog().map((item) => [
    item.id,
    item.name,
    item.price,
    item.active === false ? "Inactive" : "Active"
  ]);

  const inventoryRows = inventoryItems().map((item) => {
    const status = inventoryStatus(item);
    return [
      item.id,
      item.name,
      item.category,
      item.stockOnHand,
      item.unit,
      item.unitCost,
      Number(item.stockOnHand || 0) * Number(item.unitCost || 0),
      item.reorderLevel,
      item.supplier,
      item.location,
      item.secured ? "Locked / high value" : "Standard",
      status.label,
      item.lastPurchase || ""
    ];
  });

  const inventoryMovementRows = inventoryMovements().map((movement) => {
    const item = inventoryItemById(movement.itemId);
    return [
      movement.date,
      movement.type,
      item?.name || "Unknown item",
      item?.category || "",
      movement.quantity,
      item?.unit || "",
      movement.unitCost,
      inventoryMovementParty(movement),
      movement.expected ?? "",
      movement.counted ?? "",
      movement.variance ?? "",
      movement.note || ""
    ];
  });

  const inventoryCountRows = (state.inventoryCounts || []).map((count) => {
    const item = inventoryItemById(count.itemId);
    const employee = employeeById(count.employeeId);
    return [
      count.date,
      item?.name || "Unknown item",
      item?.category || "",
      count.expected,
      count.counted,
      count.variance,
      item?.unitCost || 0,
      Math.abs(Number(count.variance || 0)) * Number(item?.unitCost || 0),
      employee?.name || "",
      count.note || ""
    ];
  });

  const policyDeductionRows = (state.ruleDeductions || []).map((entry) => {
    const employee = employeeById(entry.employeeId);
    return [
      entry.date,
      employee?.staffId || "",
      employee?.name || "Unknown",
      entry.reason,
      entry.amount,
      entry.note || "",
      entry.actor || ""
    ];
  });

  const salaryAdvanceRows = (state.salaryAdvances || []).map((entry) => {
    const employee = employeeById(entry.employeeId);
    return [
      entry.date,
      employee?.staffId || "",
      employee?.name || "Unknown",
      entry.amount,
      entry.note || "",
      entry.actor || ""
    ];
  });

  const sheets = [
    { name: "Summary", rows: summaryRows },
    { name: "Employees", rows: [["Staff ID", "Name", "Role", "Status", "Email", "Phone", "Emergency Contact", "Address", "Hired", "Monthly Salary", "Weekly Base Salary", "Overtime Hourly Equivalent", "Weekly Sales Tier", "Tier Range", "Weekly Service Sales", "Commission Rate %", "Paid Hours", "Service Revenue", "Commission Earned", "Tips", "Late Alerts", "Missed Punches", "Permissions"], ...employeeRows] },
    { name: "Attendance", rows: [["Staff ID", "Name", "Date", "Clock In", "Lunch Start", "Lunch End", "Clock Out", "Lunch Deduction Hours", "Paid Hours", "Alerts", "Override", "Note"], ...attendanceRows] },
    { name: "Services", rows: [["Date", "Staff ID", "Technician", "Weekly Sales Tier", "Tier Range", "Weekly Service Sales", "Commission Rate %", "Service", "Service Amount", "Tips", "Payment Total", "Payment Split", "Payment Reference", "Commission", "Revenue Total"], ...serviceRows] },
    { name: "Service Catalog", rows: [["Service ID", "Service Name", "Price", "Status"], ...catalogRows] },
    { name: "Business Hours", rows: [["Date", "Business Hours", "Open", "Close", "Staff Rule"], ...businessHoursRows] },
    { name: "Bookkeeping", rows: [["Date", "Type", "Channel", "Category", "Amount", "Reference", "Note", "Recorded By"], ...bookkeepingRows] },
    { name: "Daily Closeouts", rows: [["Date", "Service Sales", "Tips", "Expected Receipts", "Receipts", "Expenses", "Deposits", "Transfers", "Variance", "Cash", "NCB POS", "FYGARO", "Bank Transfer", "Closed By", "Note"], ...dailyCloseRows] },
    { name: "Weekly Reports", rows: [["Period Start", "Period End", "Service Sales", "Tips", "Expected Receipts", "Receipts", "Expenses", "Deposits", "Transfers", "Variance", "Cash", "NCB POS", "FYGARO", "Bank Transfer", "Closed By"], ...weeklyCloseRows] },
    { name: "Payroll", rows: [["Staff ID", "Employee", "Role", "Email", "Period Start", "Period End", "Payment Date", "Hours Worked", "Lunch Deduction Hours", "Monthly Salary", "Weekly Base Salary", "Regular Hours", "Overtime Hours", "Overtime Hourly Equivalent", "Base Salary Paid", "Overtime Pay", "Commission", "Tips", "Sales Bonus", "Total Deductions", "Salary Advances", "Late Deductions", "Missed Punch Deductions", "Rule-Breaking Deductions", "PAYE Weekly Threshold", "PAYE Chargeable Income", "NIS Weekly Ceiling", "PAYE", "NIS", "NHT", "Education Tax", "Statutory Deduction Total", "Gross Pay", "Net Pay"], ...payrollRows] },
    { name: "Policy Deductions", rows: [["Date", "Staff ID", "Employee", "Reason", "Amount", "Note", "Recorded By"], ...policyDeductionRows] },
    { name: "Salary Advances", rows: [["Date", "Staff ID", "Employee", "Advance Amount", "Note", "Recorded By"], ...salaryAdvanceRows] },
    { name: "Inventory Register", rows: [["Item ID", "Item", "Category", "Stock On Hand", "Unit", "Unit Cost", "Stock Value", "Reorder Level", "Supplier", "Location", "Security Control", "Status", "Last Purchase"], ...inventoryRows] },
    { name: "Inventory Movements", rows: [["Date", "Type", "Item", "Category", "Quantity", "Unit", "Unit Cost", "Staff / Supplier", "Expected", "Counted", "Variance", "Note"], ...inventoryMovementRows] },
    { name: "Inventory Counts", rows: [["Date", "Item", "Category", "Expected", "Counted", "Variance", "Unit Cost", "Variance Value", "Counted By", "Note"], ...inventoryCountRows] },
    { name: "Deduction Settings", rows: taxRows },
    { name: "Commission Tiers", rows: [["Tier ID", "Tier Name", "Minimum Weekly Sales", "Maximum Weekly Sales", "Commission Rate %"], ...tierRows] },
    { name: "Activity Logs", rows: [["Timestamp", "Actor", "Event"], ...activityRows] }
  ];

  return `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
  xmlns:o="urn:schemas-microsoft-com:office:office"
  xmlns:x="urn:schemas-microsoft-com:office:excel"
  xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
  <Styles>
    <Style ss:ID="Title"><Font ss:Bold="1" ss:Size="15" ss:Color="#090706"/><Interior ss:Color="#F8E5A5" ss:Pattern="Solid"/></Style>
    <Style ss:ID="Header"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#17100F" ss:Pattern="Solid"/></Style>
    <Style ss:ID="Text"><Alignment ss:Vertical="Center"/></Style>
    <Style ss:ID="Number"><NumberFormat ss:Format="#,##0.00"/></Style>
  </Styles>
  ${sheets.map((sheet) => worksheetXml(sheet.name, sheet.rows)).join("\n")}
</Workbook>`;
}

function worksheetXml(name, rows) {
  const safeName = excelSheetName(name);
  const titleRow = `<Row><Cell ss:StyleID="Title"><Data ss:Type="String">${xmlEscape(name)}</Data></Cell></Row>`;
  const blankRow = "<Row></Row>";
  const dataRows = rows.map((row, rowIndex) => {
    const style = rowIndex === 0 ? "Header" : "Text";
    return `<Row>${row.map((value) => cellXml(value, style)).join("")}</Row>`;
  }).join("");
  return `
  <Worksheet ss:Name="${xmlEscape(safeName)}">
    <Table>
      ${titleRow}
      ${blankRow}
      ${dataRows}
    </Table>
    <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
      <FreezePanes/>
      <FrozenNoSplit/>
      <SplitHorizontal>3</SplitHorizontal>
      <TopRowBottomPane>3</TopRowBottomPane>
      <ActivePane>2</ActivePane>
    </WorksheetOptions>
  </Worksheet>`;
}

function cellXml(value, style) {
  if (value === null || value === undefined || value === "") {
    return `<Cell ss:StyleID="${style}"><Data ss:Type="String"></Data></Cell>`;
  }
  if (typeof value === "number" && Number.isFinite(value)) {
    return `<Cell ss:StyleID="Number"><Data ss:Type="Number">${value}</Data></Cell>`;
  }
  return `<Cell ss:StyleID="${style}"><Data ss:Type="String">${xmlEscape(value)}</Data></Cell>`;
}

function xmlEscape(value) {
  return String(value ?? "").replace(/[<>&"']/g, (char) => ({
    "<": "&lt;",
    ">": "&gt;",
    "&": "&amp;",
    "\"": "&quot;",
    "'": "&apos;"
  })[char]);
}

function excelSheetName(value) {
  return String(value).replace(/[:\\/?*\[\]]/g, " ").slice(0, 31) || "Sheet";
}

function refreshIcons() {
  if (window.lucide) window.lucide.createIcons();
}

function tutorialStepsFor(role = state.activeRole) {
  const sharedFinal = {
    title: "Getting help later",
    body: "Use the Guide button in the top bar any time you want this walkthrough again. When you are finished, use Logout or Lock session before leaving the device.",
    view: signedInHomeView(role),
    bullets: ["Guide reopens these steps.", "Lock session protects payroll privacy.", "Ask a manager before changing payroll records."]
  };

  if (role === "Staff") {
    return [
      {
        title: "Your private staff portal",
        body: "Staff access opens directly to your own portal. You can view your attendance, salon hours, service performance, and payslip details only for your own account.",
        view: "portal",
        bullets: ["Your records are read-only.", "Other employees' payslips stay hidden.", "Use Sign out when finished."]
      },
      {
        title: "Generate your PDF payslip",
        body: "In the payslip panel, select Generate PDF to download your official payslip. If payroll has already been processed, your payslip may also arrive by email.",
        view: "portal",
        bullets: ["Check the pay period dates.", "Review salary, tips, advances, and deductions.", "Raise any issue with management before payday."]
      },
      {
        title: "Clock in and out",
        body: "Use the Time Clock page for Clock In, Lunch Start, Lunch End, and Clock Out. Missing punches may affect payroll until a manager corrects them.",
        view: "timeclock",
        bullets: ["Use your own account only.", "Record lunch accurately.", "Tell management if you forget a punch."]
      },
      sharedFinal
    ];
  }

  if (role === "Front Desk") {
    return [
      {
        title: "Front desk workspace",
        body: "Front Desk access opens the daily bookkeeping and service-entry tools. Your entries feed owner reports, payroll commissions, receipts, and payment totals.",
        view: "bookkeeping",
        bullets: ["Record receipts, deposits, expenses, and transfers.", "Use the correct payment channel.", "Add references for POS, cash, transfer, or invoice records."]
      },
      {
        title: "Record services correctly",
        body: "Use Services to assign completed work to the correct technician, capture tips, and split payments by channel. These records feed commission and payroll reports.",
        view: "services",
        bullets: ["Choose the technician before saving.", "Enter tips separately.", "Match the payment split to the service total."]
      },
      {
        title: "Close the day",
        body: "At day end, use Daily Check-Off to record closeout notes and flag variances. Managers can review receipts, expenses, deposits, and transfers from your entries.",
        view: "bookkeeping",
        bullets: ["Check expected receipts against actual receipts.", "Explain any variance.", "Keep payment references clear."]
      },
      sharedFinal
    ];
  }

  return [
    {
      title: "Manager command center",
      body: "Admin and Manager access can manage employees, attendance, services, books, inventory, payroll, salary advances, PDF payslips, and email delivery.",
      view: "dashboard",
      bullets: ["Review dashboard alerts first.", "Fix missed punches before payroll.", "Use exports and backups after payroll approval."]
    },
    {
      title: "Prepare payroll",
      body: "Before processing weekly payroll, confirm attendance, service revenue, tips, Front Desk and Manager salaries, tax settings, and any salary advances.",
      view: "payroll",
      bullets: ["Front Desk is paid monthly salary divided weekly.", "Manager is paid monthly salary divided weekly.", "Salary advances appear as separate payslip deductions."]
    },
    {
      title: "Process and email payslips",
      body: "When payroll is correct, select Process Weekly Payroll. The system calculates payslips, saves the run, prepares PDF files, and sends emails when the backend email setup is live.",
      view: "payroll",
      bullets: ["Review totals before processing.", "Use Send PDF Emails Again only when needed.", "Employees can still generate their own PDF in the portal."]
    },
    {
      title: "Protect records",
      body: "Use the Security and export tools to keep records traceable. The live version saves payroll to the private PostgreSQL backend and keeps backup snapshots.",
      view: "security",
      bullets: ["Use owner access for sensitive settings.", "Keep login codes private.", "Lock the session before stepping away."]
    },
    sharedFinal
  ];
}

function tutorialSeenKey(role = state.activeRole, employee = signedInEmployee()) {
  return `${TUTORIAL_KEY_PREFIX}.${role}.${employee?.id || "business"}`;
}

function maybeOpenFirstLoginTutorial(role = state.activeRole, employee = signedInEmployee()) {
  const key = tutorialSeenKey(role, employee);
  if (localStorage.getItem(key) === "true") return;
  setTimeout(() => openTutorial(role, { firstLogin: true, employee }), 450);
}

function openTutorial(role = state.activeRole, options = {}) {
  tutorialRole = role || state.activeRole || "Admin";
  tutorialStepIndex = 0;
  tutorialDialog?.showModal();
  renderTutorialStep();
  if (options.firstLogin) localStorage.setItem(tutorialSeenKey(tutorialRole, options.employee), "true");
}

function renderTutorialStep() {
  if (!tutorialDialog?.open) return;
  const steps = tutorialStepsFor(tutorialRole);
  const step = steps[tutorialStepIndex] || steps[0];
  const progress = Math.round(((tutorialStepIndex + 1) / steps.length) * 100);
  document.querySelector("#tutorialKicker").textContent = `${tutorialRole} Guide / Step ${tutorialStepIndex + 1} of ${steps.length}`;
  document.querySelector("#tutorialTitle").textContent = step.title;
  document.querySelector("#tutorialProgress").style.width = `${progress}%`;
  document.querySelector("#tutorialBody").innerHTML = `
    <p>${escapeHtml(step.body)}</p>
    <div class="tutorial-bullets">
      ${(step.bullets || []).map((item) => `<div><i data-lucide="check"></i><span>${escapeHtml(item)}</span></div>`).join("")}
    </div>
  `;
  document.querySelector("#tutorialBack").disabled = tutorialStepIndex === 0;
  document.querySelector("#tutorialNext span").textContent = tutorialStepIndex === steps.length - 1 ? "Finish" : "Next";
  if (step.view && isAuthenticated() && roleAllowedView(step.view)) openView(step.view);
  refreshIcons();
}

function advanceTutorial(delta) {
  const steps = tutorialStepsFor(tutorialRole);
  const nextIndex = tutorialStepIndex + delta;
  if (nextIndex >= steps.length) {
    tutorialDialog.close();
    return;
  }
  tutorialStepIndex = Math.max(0, nextIndex);
  renderTutorialStep();
}

navButtons.forEach((button) => {
  button.addEventListener("click", () => {
    const target = button.dataset.viewTarget;
    if (!roleAllowedView(target)) {
      openView(isFrontDeskMode() ? "bookkeeping" : isStaffMode() ? "portal" : "dashboard");
      return;
    }
    if (target) openView(target);
  });
});

document.querySelector("#processPayroll")?.addEventListener("click", processPayroll);
document.querySelector("#processPayrollTop")?.addEventListener("click", processPayroll);
document.querySelector("#addEmployeeOpen")?.addEventListener("click", () => openEmployeeDialog());
document.querySelector("#overrideForm")?.addEventListener("submit", applyOverride);
document.querySelector("#taxSettingsForm")?.addEventListener("submit", saveTaxSettings);
document.querySelector("#policyDeductionForm")?.addEventListener("submit", addPolicyDeduction);
document.querySelector("#salaryAdvanceForm")?.addEventListener("submit", addSalaryAdvance);
document.querySelector("#serviceForm")?.addEventListener("submit", addServiceFromForm);
document.querySelector("#serviceCatalogForm")?.addEventListener("submit", addServiceCatalogItem);
document.querySelector("#bookkeepingEntryForm")?.addEventListener("submit", addBookkeepingEntry);
document.querySelector("#dailyCloseForm")?.addEventListener("submit", closeDailyBooks);
document.querySelector("#weeklyCloseButton")?.addEventListener("click", closeWeeklyBooks);
document.querySelector("#inventoryPurchaseForm")?.addEventListener("submit", addInventoryPurchase);
document.querySelector("#inventoryIssueForm")?.addEventListener("submit", issueInventoryItem);
document.querySelector("#inventoryCountForm")?.addEventListener("submit", countInventoryItem);
document.querySelector("#seedService")?.addEventListener("click", addDemoService);
document.querySelector("#rotateSaturday")?.addEventListener("click", rotateSaturday);
document.querySelector("#exportData")?.addEventListener("click", exportData);
document.querySelector("#exportExcel")?.addEventListener("click", exportExcelWorkbook);
document.querySelector("#exportExcelTop")?.addEventListener("click", exportExcelWorkbook);
document.querySelector("#downloadPayslip")?.addEventListener("click", () => downloadPayslipPdf(selectedPayslip));
document.querySelector("#closePayslip")?.addEventListener("click", () => payslipDialog.close());
document.querySelector("#openTutorial")?.addEventListener("click", () => openTutorial(state.activeRole));
document.querySelector("#closeTutorial")?.addEventListener("click", () => tutorialDialog?.close());
document.querySelector("#tutorialBack")?.addEventListener("click", () => advanceTutorial(-1));
document.querySelector("#tutorialNext")?.addEventListener("click", () => advanceTutorial(1));
document.querySelector("#downloadAllPayslips")?.addEventListener("click", () => {
  latestPayrollRun().records.forEach((record, index) => {
    setTimeout(() => downloadPayslipPdf(record), index * 180);
  });
});

employeeForm.addEventListener("submit", saveEmployeeFromForm);

document.addEventListener("submit", async (event) => {
  if (event.target.matches("#authGateForm")) {
    event.preventDefault();
    const error = document.querySelector("#authGateError");
    error.hidden = true;
    error.textContent = "";
    let credential;
    try {
      credential = await authenticateLoginCode(document.querySelector("#authLoginCode").value);
    } catch (loginError) {
      error.textContent = loginError.message || "Login code was not accepted.";
      error.hidden = false;
      return;
    }
    document.querySelector("#authLoginCode").value = "";
    completeSignIn(credential.role, credential.employee, credential.actor, credential.state, credential.token);
    return;
  }

  if (event.target.matches("#accessForm")) {
    event.preventDefault();
    const error = document.querySelector("#accessError");
    let credential;
    try {
      credential = await authenticateLoginCode(document.querySelector("#accessCode").value);
    } catch (loginError) {
      error.textContent = loginError.message || "Login code was not accepted.";
      error.hidden = false;
      return;
    }
    document.querySelector("#accessCode").value = "";
    accessDialog.close();
    completeSignIn(credential.role, credential.employee, credential.actor, credential.state, credential.token);
    return;
  }

  if (event.target.matches("#adminUnlockForm")) {
    event.preventDefault();
    const code = document.querySelector("#adminUnlockCode").value.trim();
    try {
      const credential = await authenticateLoginCode(code);
      if (credential.role !== "Admin") throw new Error("Owner PIN was not accepted.");
      completeSignIn("Admin", null, "Owner", credential.state, credential.token);
    } catch (unlockError) {
      portalError = unlockError.message || "Owner PIN was not accepted.";
      renderPortal();
      renderServices();
      refreshIcons();
    }
    return;
  }

  if (!event.target.matches("#staffSignInForm")) return;
  event.preventDefault();
  const employeeId = document.querySelector("#staffSignEmployee").value;
  const staffId = document.querySelector("#staffSignId").value.trim();
  let credential;
  try {
    credential = await authenticateLoginCode(staffId);
  } catch {
    credential = null;
  }
  if (!credential?.employee || credential.employee.id !== employeeId) {
    portalError = "That Staff ID does not match the selected employee.";
    renderPortal();
    refreshIcons();
    return;
  }
  completeSignIn("Staff", credential.employee, credential.employee.name, credential.state, credential.token);
});

document.addEventListener("click", (event) => {
  const employeeCard = event.target.closest("[data-employee-card]");
  if (employeeCard) {
    selectedEmployeeId = employeeCard.dataset.employeeCard;
    saveState();
    renderEmployees();
    refreshIcons();
  }

  const editEmployee = event.target.closest("[data-edit-employee]");
  if (editEmployee) {
    if (guardStaffMutation()) return;
    openEmployeeDialog(editEmployee.dataset.editEmployee);
  }

  const toggleEmployee = event.target.closest("[data-toggle-employee]");
  if (toggleEmployee) {
    if (guardStaffMutation()) return;
    const employee = employeeById(toggleEmployee.dataset.toggleEmployee);
    employee.status = employee.status === "Active" ? "Inactive" : "Active";
    state.activity.unshift(audit("Admin", `${employee.name} status changed to ${employee.status}.`));
    saveState();
    renderAll();
  }

  const removeEmployee = event.target.closest("[data-remove-employee]");
  if (removeEmployee) {
    if (guardStaffMutation()) return;
    const employee = employeeById(removeEmployee.dataset.removeEmployee);
    state.employees = state.employees.filter((item) => item.id !== employee.id);
    state.activity.unshift(audit("Admin", `Removed employee profile for ${employee.name}.`));
    selectedEmployeeId = activeEmployees()[0]?.id || state.employees[0]?.id;
    saveState();
    renderAll();
  }

  const punch = event.target.closest("[data-punch]");
  if (punch) handlePunch(punch.dataset.punch);

  const viewPayslip = event.target.closest("[data-view-payslip]");
  if (viewPayslip) openPayslip(viewPayslip.dataset.viewPayslip);

  const pdfPayslip = event.target.closest("[data-pdf-payslip]");
  if (pdfPayslip) {
    const record = latestPayrollRun().records.find((item) => item.employeeId === pdfPayslip.dataset.pdfPayslip);
    downloadPayslipPdf(record);
  }

  const sendPayslipEmails = event.target.closest("[data-send-payslip-emails]");
  if (sendPayslipEmails) {
    sendPayslipEmailsForRun(latestPayrollRun());
  }

  const staffSignOut = event.target.closest("[data-staff-signout]");
  if (staffSignOut) {
    signOut("Staff portal signed out.");
  }

  const removeService = event.target.closest("[data-remove-service]");
  if (removeService) {
    if (guardManagerMutation()) return;
    const service = catalogItemById(removeService.dataset.removeService);
    if (!service) return;
    state.serviceCatalog = state.serviceCatalog.filter((item) => item.id !== service.id);
    state.activity.unshift(audit("Manager", `Removed service menu item: ${service.name}.`));
    saveState();
    renderAll();
  }

  const paymentFill = event.target.closest("[data-payment-fill]");
  if (paymentFill) {
    const field = document.querySelector(`#${paymentFill.dataset.paymentFill}`);
    if (!field) return;
    const balance = round(serviceTotalDue() - servicePaymentTotal());
    if (balance > 0) field.value = round(Number(field.value || 0) + balance);
    syncServicePaymentStatus();
  }

  const paymentClear = event.target.closest("[data-payment-clear]");
  if (paymentClear) {
    ["#serviceCashPayment", "#serviceNcbPayment", "#serviceFygaroPayment", "#serviceTransferPayment", "#serviceOtherPayment"].forEach((selector) => {
      const field = document.querySelector(selector);
      if (field) field.value = 0;
    });
    syncServicePaymentStatus();
  }
});

document.querySelector("#authLoginCode").addEventListener("input", () => {
  document.querySelector("#authGateError").hidden = true;
  document.querySelector("#authGateError").textContent = "";
});

document.querySelector("#activeRole").addEventListener("change", (event) => {
  state.activeRole = event.target.value;
  if (state.activeRole !== "Staff") state.signedInEmployeeId = null;
  state.activity.unshift(audit("Security", `Role session changed to ${state.activeRole}.`));
  saveState();
  renderAll();
  if (state.activeRole === "Staff") openView("portal");
  if (state.activeRole === "Front Desk") openView("bookkeeping");
});

document.querySelector("#accessLoginOpen").addEventListener("click", () => {
  openAccessDialog();
});

document.querySelector("#closeAccess").addEventListener("click", () => accessDialog.close());

document.querySelector("#sessionLogout").addEventListener("click", () => {
  signOut("User logged out.");
});

document.querySelector("#lockSession").addEventListener("click", () => {
  signOut("Session locked and signed out.");
});

document.querySelector("#portalEmployee").addEventListener("change", () => {
  if (isStaffMode()) return;
  renderPortal();
});

document.querySelector("#serviceType").addEventListener("change", (event) => {
  const amount = event.target.selectedOptions[0]?.dataset.amount;
  if (amount) document.querySelector("#serviceAmount").value = amount;
  syncServicePaymentStatus();
});

document.querySelector("#employeeRole")?.addEventListener("change", syncEmployeeSalaryFieldForRole);

document.querySelector("#serviceForm")?.addEventListener("input", (event) => {
  if (event.target.matches("#serviceAmount, #serviceTips, #serviceCashPayment, #serviceNcbPayment, #serviceFygaroPayment, #serviceTransferPayment, #serviceOtherPayment")) {
    syncServicePaymentStatus();
  }
});

document.querySelector("#dailyCloseDate")?.addEventListener("change", () => {
  renderBookkeeping();
  refreshIcons();
});

function tickClock() {
  const now = new Date();
  document.querySelector("#liveClock").textContent = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

tickClock();
setInterval(tickClock, 1000);

function drawAura() {
  const canvas = document.querySelector("#opsAura");
  const ctx = canvas?.getContext("2d");
  if (!canvas || !ctx) return;
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  const resize = () => {
    canvas.width = Math.floor(window.innerWidth * ratio);
    canvas.height = Math.floor(window.innerHeight * ratio);
    canvas.style.width = `${window.innerWidth}px`;
    canvas.style.height = `${window.innerHeight}px`;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  };
  const glints = Array.from({ length: 34 }, () => ({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    s: Math.random() * 2 + 0.8,
    v: Math.random() * 0.18 + 0.05
  }));
  const render = () => {
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    ctx.strokeStyle = "rgba(223, 189, 115, 0.16)";
    ctx.lineWidth = 1;
    for (let i = 0; i < 7; i += 1) {
      const y = (i * 160 + Date.now() * 0.012) % (window.innerHeight + 200) - 100;
      ctx.beginPath();
      ctx.moveTo(-80, y);
      ctx.lineTo(window.innerWidth + 80, y + 120);
      ctx.stroke();
    }
    glints.forEach((glint) => {
      glint.y += glint.v;
      if (glint.y > window.innerHeight + 12) glint.y = -12;
      ctx.fillStyle = "rgba(248, 229, 165, 0.48)";
      ctx.fillRect(glint.x, glint.y, glint.s, glint.s);
    });
    requestAnimationFrame(render);
  };
  resize();
  render();
  window.addEventListener("resize", resize);
}

drawAura();
renderAll();
