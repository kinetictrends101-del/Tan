# Trudy'z Payroll System Only

This is the payroll-only system for Trudy'z Amazing Nails LTD.

This version is set up for a real production launch on your own server/VPS:

- Node.js backend server
- PostgreSQL database
- HTTPS/domain routing through Caddy
- Private environment variables
- PDF payslip download
- Automatic payslip email through Resend
- Role-aware first-login tutorial

It does not include the public booking website, checkout page, gallery, pricing pages, or Fygaro payment links.

## Main Files

- `index.html`: payroll app screen
- `operations.css`: app styling
- `operations.js`: browser app logic
- `server.js`: production backend server
- `package.json`: Node app dependencies
- `Dockerfile`: app container
- `docker-compose.yml`: app, PostgreSQL, and HTTPS stack
- `Caddyfile`: domain and HTTPS routing
- `.env.example`: private settings template
- `database/postgres-schema.sql`: database tables
- `tools/payroll-audit.js`: payroll math audit
- `tools/backup-postgres.sh`: database backup helper
- `tools/restore-postgres.sh`: database restore helper
- `tools/go-live-check.sh`: final server readiness check

## The Real Launch Setup

Use a private VPS or dedicated cloud server. Install Docker and Docker Compose on that server, then run this project with `docker compose`.

Recommended domain pattern:

`payroll.trudyzamazingnails.com`

Point that DNS record to the server IP address before starting the HTTPS service.

## Launch Steps

1. Buy or prepare a VPS/server.
2. Point `payroll.trudyzamazingnails.com` to the server IP address.
3. Install Docker and Docker Compose on the server.
4. Upload this `trudyz-payroll-only` folder to the server.
5. Copy `.env.example` to `.env`.
6. Edit `.env` with real private values.
7. Start the system:

```bash
docker compose up -d --build
```

8. Open:

`https://payroll.trudyzamazingnails.com`

9. Login as Owner/Admin.
10. Confirm employees, staff IDs, roles, salary settings, and email addresses.
11. Run a small test payroll before the first real payday.
12. Run the go-live check:

```bash
sh tools/go-live-check.sh
```

## Launch Tips

- Use a subdomain like `payroll.trudyzamazingnails.com`, not the main public website domain. This keeps payroll separate from customer-facing pages.
- Wait for DNS to fully update before judging the launch. A new domain record can take minutes or sometimes a few hours to resolve everywhere.
- Keep ports `80` and `443` open on the server firewall. Caddy needs them to issue HTTPS automatically.
- Keep `.env` private. It contains payroll login codes, the database password, and the email API key.
- Make `PAYROLL_SESSION_SECRET` long and random. Do not use a normal password or business name.
- Use different private codes for Owner, Manager, and Front Desk. If one code is shared too widely, change only that code and restart the system.
- Before the first real payday, run a test payroll with one employee email that you control. Confirm the PDF downloads and the email arrives.
- After launch, bookmark only the HTTPS link. Do not use the server IP address for daily payroll work.
- Keep a written note of who has Owner/Admin access. Payroll access should be treated like banking access.
- Create a backup before every real payroll run and before every system update.

## Required Environment Variables

These go in `.env` on the server only. Never put these inside browser code.

- `PAYROLL_DOMAIN`
- `POSTGRES_DB`
- `POSTGRES_USER`
- `POSTGRES_PASSWORD`
- `PAYROLL_SESSION_SECRET`
- `PAYROLL_OWNER_CODE`
- `PAYROLL_MANAGER_CODE`
- `PAYROLL_FRONT_DESK_CODE`
- `RESEND_API_KEY`

Email values:

- `PAYSLIP_EMAIL_FROM`
- `PAYSLIP_EMAIL_REPLY_TO`
- `PAYSLIP_EMAIL_BCC`

Backup values:

- `BACKUP_DIR`
- `KEEP_DAYS`

Default sender:

`Trudy'z Payroll <TAN_payroll@trudyzamazingnails.com>`

The domain `trudyzamazingnails.com` must be verified in Resend before live payslip emails will send reliably.

## Statutory Deduction Setup

The payroll system now supports Jamaica statutory deduction settings instead of only flat gross percentages.

Current default fields in Payroll settings:

- PAYE rate: `25%`
- PAYE weekly threshold: `JMD $36,583.85`
- PAYE higher rate: `30%`
- PAYE higher weekly threshold: based on `JMD $6,000,000` annually
- NIS employee rate: `3%`
- NIS weekly ceiling: based on `JMD $5,000,000` annually
- NHT employee rate: `2%`
- Education Tax employee rate: `2.25%`

How deductions are calculated:

- NIS is capped at the weekly NIS ceiling.
- NHT is calculated on gross pay.
- Education Tax is calculated after NIS is deducted.
- PAYE uses gross pay less NIS, then applies the weekly tax-free threshold.
- The payslip and Excel export show PAYE threshold and PAYE chargeable income for audit clarity.

Before the first real payroll run, have your accountant or payroll officer confirm these fields in the Payroll tab.

## Access Setup

Create private login codes in `.env`:

- Owner/Admin code: `PAYROLL_OWNER_CODE`
- Manager code: `PAYROLL_MANAGER_CODE`
- Front Desk code: `PAYROLL_FRONT_DESK_CODE`
- Staff login: each employee uses their own Staff ID saved in the Employees section

Use strong private codes. Do not use public examples for live payroll.

## First Login Tutorial

The system includes a role-aware first-login guide.

- It opens automatically after a user's first successful login on that device.
- Staff see guidance for the portal, time clock, and PDF payslip download.
- Front Desk sees service entry, payment split, and daily close guidance.
- Admin and Manager see dashboard, payroll processing, email payslips, salary advances, and security guidance.
- Users can reopen it anytime from the `Guide` button in the top bar.

## Employee PDF Payslip Workflow

Employees can generate their own PDF payslip from the staff portal.

1. Open the payroll system.
2. Enter the employee Staff ID on the first login screen.
3. The system opens that employee's private portal.
4. Go to the payslip panel.
5. Select `Generate PDF Payslip`.

Staff users can only generate their own payslip. The system blocks staff-mode PDF downloads for other employees.

## Automatic Payslip Email

The payroll system has two payslip delivery options:

- Automatic email after `Process Weekly Payroll`
- Employee self-service `Generate PDF Payslip` from the staff portal

Automatic email is handled by the production backend at:

`/api/send-payslips`

After payroll is processed, the app creates each PDF payslip and sends it to the employee email saved in their profile. If email is not configured yet, employees can still generate their PDF payslips from the portal.

Before real payroll runs, replace demo employee email addresses with real employee emails.

Email tips:

- Verify `trudyzamazingnails.com` in Resend before relying on automatic payslip email.
- Send one test payslip to yourself first.
- Add a BCC archive email if you want a private owner copy of every payslip email.
- If an employee says they did not receive a payslip, check spam/junk first, then use the employee portal PDF download as the backup option.

## Front Desk, Manager, And Salary Advances

Front Desk and Manager employees are included in payroll and get PDF payslips like every other staff member.

- Front Desk monthly salary: JMD $80,000
- Manager monthly salary: JMD $120,000
- Weekly payout basis: monthly salary divided by 4
- Front Desk weekly payout: JMD $20,000
- Manager weekly payout: JMD $30,000

If a Front Desk or Manager staff member takes an advance, record it in the Payroll tab under `Salary Advances`. The advance is deducted only for that pay period and appears separately on the payslip.

## Final Pre-Launch Test

Before giving the system to staff:

1. Login as Owner/Admin.
2. Add or confirm every employee.
3. Add real employee email addresses.
4. Login as Manager.
5. Login as Front Desk.
6. Login as one staff member by Staff ID.
7. Process one small test payroll run.
8. Download at least one PDF payslip.
9. Confirm one test payslip email arrives.
10. Restart the server and confirm the payroll data is still there.
11. Run the payroll audit command.
12. Run the go-live server check.
13. Create a database backup.
14. Lock/logout from all shared devices.

When all items pass, the payroll system is ready for live weekly use.

## Payroll Audit Checks

Run this before launch and after any payroll-rule change:

```bash
npm run audit:payroll
```

This checks:

- Commission tier boundaries and commission amounts
- One sales threshold bonus only, with no bonus stacking
- Late, missed punch, rule-breaking, salary advance, and statutory deductions
- Front Desk and Manager weekly salary rules
- Clean PDF payslip structure

On the live Docker server, run:

```bash
docker compose exec -T app npm run audit:payroll
```

For the full server check, run:

```bash
sh tools/go-live-check.sh
```

## Weekly Use Tips

- Enter salary advances before processing payroll.
- Check Front Desk and Manager advances even if they do not take one every week.
- Fix missed clock punches before processing payroll.
- Confirm every employee has the correct email before sending payslips.
- After payroll is processed, download/export a backup copy for your records.
- If a payroll run looks wrong, do not process a second run immediately. Fix the underlying attendance, service, tips, salary, or advance record first.

## Useful Server Commands

Start or update:

```bash
docker compose up -d --build
```

View logs:

```bash
docker compose logs -f app
```

Stop:

```bash
docker compose down
```

Create a database backup:

```bash
sh tools/backup-postgres.sh
```

Restore from a database backup:

```bash
sh tools/restore-postgres.sh backups/trudyz-payroll-YYYYMMDD-HHMMSS.sql
```

Check server health:

```bash
curl -fsS https://payroll.trudyzamazingnails.com/healthz
```
