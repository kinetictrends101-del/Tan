create table if not exists payroll_state (
  key text primary key,
  state jsonb not null,
  updated_at timestamptz not null default now()
);

create table if not exists payroll_backups (
  id bigserial primary key,
  reason text not null,
  created_by text not null,
  state jsonb not null,
  created_at timestamptz not null default now()
);

create index if not exists payroll_backups_created_at_idx
  on payroll_backups (created_at desc);
