#!/bin/sh
set -eu

if [ ! -f ".env" ]; then
  echo ".env file is missing. Copy .env.example to .env and fill it in first."
  exit 1
fi

set -a
# shellcheck disable=SC1091
. ./.env
set +a

if [ "${PAYROLL_DOMAIN:-}" = "" ]; then
  echo "PAYROLL_DOMAIN is missing in .env."
  exit 1
fi

echo "Checking Docker services..."
docker compose ps

echo "Running payroll math audit..."
docker compose exec -T app npm run audit:payroll

echo "Checking database readiness..."
docker compose exec -T db sh -c 'pg_isready -U "$POSTGRES_USER" -d "$POSTGRES_DB"'

echo "Checking HTTPS health endpoint..."
curl -fsS "https://$PAYROLL_DOMAIN/healthz"
echo

echo "Go-live checks passed."
