const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const rootDir = path.join(__dirname, "..");
const operationsPath = path.join(rootDir, "operations.js");

function createStorage() {
  const values = new Map();
  return {
    getItem(key) {
      return values.has(key) ? values.get(key) : null;
    },
    setItem(key, value) {
      values.set(key, String(value));
    },
    removeItem(key) {
      values.delete(key);
    },
    clear() {
      values.clear();
    }
  };
}

function createElement(selector = "element") {
  const element = {
    selector,
    value: "",
    innerHTML: "",
    textContent: "",
    hidden: false,
    disabled: false,
    checked: false,
    open: false,
    dataset: {},
    style: {},
    selectedOptions: [{ dataset: {}, value: "" }],
    classList: {
      add() {},
      remove() {},
      toggle() {},
      contains() {
        return false;
      }
    },
    addEventListener() {},
    removeEventListener() {},
    setAttribute() {},
    getAttribute() {
      return null;
    },
    appendChild() {},
    click() {},
    focus() {},
    reset() {},
    showModal() {
      this.open = true;
    },
    close() {
      this.open = false;
    },
    matches() {
      return false;
    },
    closest() {
      return null;
    },
    querySelector() {
      return createElement(`${selector} child`);
    },
    querySelectorAll() {
      return [];
    },
    getContext() {
      return null;
    },
    getBoundingClientRect() {
      return { width: 0, height: 0, top: 0, right: 0, bottom: 0, left: 0 };
    }
  };
  return element;
}

function createPayrollApp() {
  const elements = new Map();
  const body = createElement("body");
  const document = {
    body,
    documentElement: { scrollWidth: 1280, clientWidth: 1280 },
    addEventListener() {},
    createElement,
    querySelector(selector) {
      if (!elements.has(selector)) elements.set(selector, createElement(selector));
      return elements.get(selector);
    },
    querySelectorAll() {
      return [];
    }
  };

  const context = {
    console,
    Intl,
    Math,
    Date,
    JSON,
    Number,
    String,
    Array,
    Object,
    RegExp,
    Error,
    Map,
    Set,
    Buffer,
    document,
    localStorage: createStorage(),
    sessionStorage: createStorage(),
    Blob: class Blob {
      constructor(parts = [], options = {}) {
        this.parts = parts;
        this.type = options.type || "";
      }
    },
    URL: {
      createObjectURL() {
        return "blob:audit";
      },
      revokeObjectURL() {}
    },
    window: {
      innerWidth: 1280,
      innerHeight: 720,
      devicePixelRatio: 1,
      addEventListener() {},
      crypto: {
        randomUUID() {
          return `audit-${Math.random().toString(16).slice(2).padEnd(32, "0")}`;
        }
      },
      lucide: null
    },
    setTimeout(callback) {
      if (typeof callback === "function") callback();
      return 0;
    },
    clearTimeout() {},
    setInterval() {
      return 0;
    },
    requestAnimationFrame() {
      return 0;
    },
    fetch() {
      throw new Error("Network calls are disabled in payroll audit.");
    }
  };
  context.globalThis = context;
  context.window.window = context.window;
  context.window.document = document;
  context.window.localStorage = context.localStorage;
  context.window.sessionStorage = context.sessionStorage;

  const code = fs.readFileSync(operationsPath, "utf8");
  vm.createContext(context);
  vm.runInContext(`${code}
globalThis.__payrollAudit = {
  get state() { return state; },
  replaceState,
  normalizeState,
  defaultState,
  calculatePayrollRun,
  commissionTierForWeeklySales,
  payslipPdfLines,
  buildPdf,
  formatMoney
};`, context, { filename: operationsPath });
  return context.__payrollAudit;
}

function baseScenario(app, overrides = {}) {
  app.replaceState({
    schemaVersion: 10,
    selectedEmployeeId: "tech",
    signedInEmployeeId: null,
    activeRole: "Admin",
    payPeriodStart: "2026-06-02",
    settings: {
      baseSalary: 16000,
      paye: 25,
      nis: 3,
      nht: 2,
      educationTax: 2.25,
      overtimeAfter: 40,
      overtimeMultiplier: 1.5,
      frontDeskMonthlySalary: 80000,
      managerMonthlySalary: 120000,
      monthlySalaryDivisor: 4,
      lunchDeductionMinutes: 35,
      salesBonusThreshold: 100000,
      salesBonusAmount: 2500,
      lateDeductionAmount: 500,
      missedPunchDeductionAmount: 750
    },
    employees: [
      {
        id: "tech",
        staffId: "TAN-101",
        name: "Audit Nail Tech",
        role: "Nail Technician",
        status: "Active",
        baseSalary: 16000,
        email: "tech@example.com",
        permissions: ["Portal"]
      },
      {
        id: "frontdesk",
        staffId: "TAN-102",
        name: "Audit Front Desk",
        role: "Front Desk",
        status: "Active",
        monthlySalary: 80000,
        baseSalary: 20000,
        email: "frontdesk@example.com",
        permissions: ["Portal"]
      },
      {
        id: "manager",
        staffId: "TAN-103",
        name: "Audit Manager",
        role: "Salon Manager",
        status: "Active",
        monthlySalary: 120000,
        baseSalary: 30000,
        email: "manager@example.com",
        permissions: ["Portal", "Payroll"]
      }
    ],
    attendance: [],
    services: [],
    schedule: [],
    serviceCatalog: [],
    inventory: [],
    inventoryMovements: [],
    inventoryCounts: [],
    bookkeepingEntries: [],
    dailyClosings: [],
    weeklyClosings: [],
    ruleDeductions: [],
    salaryAdvances: [],
    payrollRuns: [],
    payslipDeliveries: {},
    activity: [],
    ...overrides
  });
}

function recordFor(run, employeeId) {
  const record = run.records.find((item) => item.employeeId === employeeId);
  assert.ok(record, `Missing payroll record for ${employeeId}`);
  return record;
}

function service(employeeId, amount, tips = 0, date = "2026-06-02") {
  return {
    id: `svc-${employeeId}-${amount}-${tips}`,
    employeeId,
    date,
    service: "Audit Service",
    amount,
    tips
  };
}

function log(employeeId, date, clockIn, clockOut) {
  return {
    id: `log-${employeeId}-${date}`,
    employeeId,
    date,
    clockIn,
    lunchStart: null,
    lunchEnd: null,
    clockOut,
    override: false,
    note: ""
  };
}

function almostEqual(actual, expected, label) {
  assert.equal(Number(actual.toFixed(2)), Number(expected.toFixed(2)), label);
}

function runAudit() {
  const app = createPayrollApp();
  const results = [];
  const pass = (name, detail) => results.push({ name, detail });

  const tierChecks = [
    [19999, 0],
    [20000, 18],
    [40500, 18],
    [41000, 22],
    [75500, 22],
    [76000, 25],
    [100500, 25],
    [101000, 28]
  ];
  tierChecks.forEach(([sales, expectedRate]) => {
    const tier = app.commissionTierForWeeklySales(sales);
    assert.equal(tier.serviceRate, expectedRate, `Commission tier mismatch for ${sales}`);
  });
  baseScenario(app, { services: [service("tech", 40500)] });
  almostEqual(recordFor(app.calculatePayrollRun(), "tech").commission, 7290, "Commission amount for 40,500 should be 18%.");
  pass("Commissions calculating correctly", "Tier boundaries are continuous; 40,500 now pays 18%, 75,500 pays 22%, 101,000 pays 28%.");

  baseScenario(app, { services: [service("tech", 150000)] });
  const bonusRecord = recordFor(app.calculatePayrollRun(), "tech");
  assert.equal(bonusRecord.bonus, 2500, "Sales threshold bonus should be one fixed bonus.");
  assert.equal(bonusRecord.salesBonus, 2500, "Sales bonus mirror field should match fixed bonus.");
  assert.ok(bonusRecord.taxes.paye > 0, "High-sales payroll should calculate PAYE above the weekly threshold.");
  pass("Bonuses non-stacking", "A 150,000 sales week pays one 2,500 threshold bonus, not multiple bonuses or legacy adjustment bonuses.");

  baseScenario(app, {
    services: [service("tech", 50000, 1000)],
    attendance: [
      log("tech", "2026-06-02", "10:10", "19:00"),
      log("tech", "2026-06-03", null, null)
    ],
    ruleDeductions: [{ id: "rule-1", employeeId: "tech", date: "2026-06-04", amount: 800, reason: "Audit rule", note: "" }],
    salaryAdvances: [{ id: "advance-1", employeeId: "tech", date: "2026-06-05", amount: 2000, note: "" }]
  });
  const deductionRecord = recordFor(app.calculatePayrollRun(), "tech");
  assert.equal(deductionRecord.lateDeduction, 500, "Late deduction should be one late x 500.");
  assert.equal(deductionRecord.missedPunchDeduction, 750, "Missed punch deduction should be one missed punch x 750.");
  assert.equal(deductionRecord.ruleBreakDeductions, 800, "Rule deduction should be included.");
  assert.equal(deductionRecord.salaryAdvances, 2000, "Salary advance should be included.");
  assert.equal(deductionRecord.deductions, 4050, "Policy deductions should sum late, missed, rule, and advance deductions.");
  almostEqual(deductionRecord.taxes.paye, 0, "PAYE should be zero below the weekly threshold after NIS.");
  almostEqual(deductionRecord.taxes.nis, 840, "NIS should be 3% of gross below the weekly ceiling.");
  almostEqual(deductionRecord.taxes.nht, 560, "NHT should be 2% of gross.");
  almostEqual(deductionRecord.taxes.educationTax, 611.1, "Education Tax should be 2.25% after NIS.");
  almostEqual(deductionRecord.statutoryDeductionTotal, 2011.1, "Statutory deductions should sum PAYE, NIS, NHT, and Education Tax.");
  almostEqual(deductionRecord.netPay, 21938.9, "Net pay should subtract statutory and policy deductions.");
  pass("Deductions correct", "PAYE threshold, NIS ceiling logic, NHT, Education Tax after NIS, late, missed punch, rule, and salary advance deductions add up correctly.");

  baseScenario(app, {
    salaryAdvances: [{ id: "advance-frontdesk", employeeId: "frontdesk", date: "2026-06-02", amount: 5000, note: "" }]
  });
  const salaryRun = app.calculatePayrollRun();
  const frontDesk = recordFor(salaryRun, "frontdesk");
  const manager = recordFor(salaryRun, "manager");
  assert.equal(frontDesk.monthlySalary, 80000, "Front Desk monthly salary should be 80,000.");
  assert.equal(frontDesk.baseSalary, 20000, "Front Desk weekly salary should be 20,000.");
  assert.equal(frontDesk.salaryAdvances, 5000, "Front Desk advance should be deducted.");
  almostEqual(frontDesk.netPay, 13563.5, "Front Desk net should reflect statutory deductions and 5,000 advance.");
  assert.equal(manager.monthlySalary, 120000, "Manager monthly salary should be 120,000.");
  assert.equal(manager.baseSalary, 30000, "Manager weekly salary should be 30,000.");
  almostEqual(manager.netPay, 27845.25, "Manager net should reflect statutory deductions.");
  pass("Staff payments match configured management rules", "Front Desk pays 20,000 weekly from 80,000 monthly; Manager pays 30,000 weekly from 120,000 monthly; advances deduct separately.");

  const pdfLines = app.payslipPdfLines(deductionRecord);
  const pdf = app.buildPdf(deductionRecord, pdfLines);
  assert.ok(pdf.startsWith("%PDF-1.4"), "Payslip PDF should start with a valid PDF header.");
  assert.ok(pdf.includes("/Type /Catalog"), "Payslip PDF should include a catalog object.");
  assert.ok(pdf.includes("Final Net Pay"), "Payslip PDF should include final net pay label.");
  assert.ok(pdf.endsWith("%%EOF"), "Payslip PDF should end with EOF marker.");
  pass("Clean payslip export", "Generated payslip is valid PDF text structure with employee, deductions, gross, and final net pay lines.");

  return results;
}

try {
  const results = runAudit();
  console.log("Payroll audit passed.");
  results.forEach((result) => {
    console.log(`- ${result.name}: ${result.detail}`);
  });
} catch (error) {
  console.error("Payroll audit failed.");
  console.error(error.stack || error.message);
  process.exit(1);
}
