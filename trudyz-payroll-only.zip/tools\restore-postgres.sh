#!/bin/sh
set -eu

if [ "${1:-}" = "" ]; then
  echo "Usage: sh tools/restore-postgres.sh backups/trudyz-payroll-YYYYMMDD-HHMMSS.sql"
  exit 1
fi

BACKUP_FILE="$1"

if [ ! -f "$BACKUP_FILE" ]; then
  echo "Backup file not found: $BACKUP_FILE"
  exit 1
fi

echo "This will restore PostgreSQL from: $BACKUP_FILE"
echo "Type RESTORE to continue:"
read -r CONFIRM

if [ "$CONFIRM" != "RESTORE" ]; then
  echo "Restore cancelled."
  exit 1
fi

cat "$BACKUP_FILE" | docker compose exec -T db sh -c 'psql -U "$POSTGRES_USER" "$POSTGRES_DB"'

echo "Restore complete."
