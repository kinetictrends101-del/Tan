const compression = require("compression");
const crypto = require("node:crypto");
require("dotenv").config();
const fs = require("node:fs/promises");
const path = require("node:path");
const express = require("express");
const helmet = require("helmet");
const { Pool } = require("pg");

const PORT = Number(process.env.PORT || 3000);
const STATE_KEY = "main";
const SESSION_TTL_MS = 12 * 60 * 60 * 1000;
const ROOT_DIR = __dirname;
const loginAttempts = new Map();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === "true"
    ? { rejectUnauthorized: process.env.DATABASE_SSL_REJECT_UNAUTHORIZED !== "false" }
    : undefined
});

const app = express();

app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      "default-src": ["'self'"],
      "base-uri": ["'self'"],
      "connect-src": ["'self'"],
      "font-src": ["'self'", "https://fonts.gstatic.com", "data:"],
      "form-action": ["'self'"],
      "frame-ancestors": ["'none'"],
      "img-src": ["'self'", "data:", "blob:"],
      "object-src": ["'none'"],
      "script-src": ["'self'", "https://unpkg.com"],
      "style-src": ["'self'", "https://fonts.googleapis.com", "'unsafe-inline'"],
      "upgrade-insecure-requests": process.env.NODE_ENV === "production" ? [] : null
    }
  },
  crossOriginEmbedderPolicy: false
}));
app.use(compression());
app.use(express.json({ limit: "35mb" }));

app.get("/healthz", healthCheck);
app.post("/api/payroll", payrollApi);
app.post("/api/send-payslips", sendPayslipsApi);

app.use(express.static(ROOT_DIR, {
  etag: true,
  maxAge: process.env.NODE_ENV === "production" ? "1h" : 0,
  setHeaders(res, filePath) {
    if (filePath.endsWith(".html")) {
      res.setHeader("Cache-Control", "no-store");
    }
  }
}));

app.get("*", (req, res) => {
  res.sendFile(path.join(ROOT_DIR, "index.html"));
});

async function start() {
  await migrateDatabase();
  const server = app.listen(PORT, () => {
    console.log(`Trudy'z payroll server running on port ${PORT}`);
  });
  const shutdown = async (signal) => {
    console.log(`${signal} received. Closing payroll server.`);
    server.close(async () => {
      await pool.end();
      process.exit(0);
    });
  };
  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
}

start().catch((error) => {
  console.error("Payroll server failed to start", error);
  process.exit(1);
});

async function migrateDatabase() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL is required.");
  }
  const schemaPath = path.join(ROOT_DIR, "database", "postgres-schema.sql");
  const schema = await fs.readFile(schemaPath, "utf8");
  await pool.query(schema);
}

async function healthCheck(req, res) {
  const critical = setupStatus(["DATABASE_URL", "PAYROLL_SESSION_SECRET", "PAYROLL_OWNER_CODE"]);
  const email = setupStatus(["RESEND_API_KEY"]);
  let database = "ok";
  try {
    await pool.query("select 1");
  } catch (error) {
    database = "error";
  }
  const ok = critical.ok && database === "ok";
  return sendJson(res, ok ? 200 : 503, {
    ok,
    service: "trudyz-payroll",
    database,
    criticalMissing: critical.missing,
    emailReady: email.ok,
    emailMissing: email.missing,
    checkedAt: new Date().toISOString()
  });
}

async function payrollApi(req, res) {
  const setup = setupStatus(["DATABASE_URL", "PAYROLL_SESSION_SECRET", "PAYROLL_OWNER_CODE"]);
  if (!setup.ok) return sendJson(res, 503, { ok: false, setupNeeded: true, message: setup.message, missing: setup.missing });

  try {
    if (req.body.action === "login") return await login(req, res);
    if (req.body.action === "loadState") return await loadState(req, res);
    if (req.body.action === "saveState") return await saveState(req, res);
    if (req.body.action === "backupState") return await backupState(req, res);
    return sendJson(res, 400, { ok: false, message: "Unknown payroll API action." });
  } catch (error) {
    console.error(error);
    return sendJson(res, error.statusCode || 500, { ok: false, message: error.message || "Payroll API failed." });
  }
}

async function login(req, res) {
  assertLoginAllowed(req);

  const code = String(req.body.code || "").trim();
  if (!code) {
    recordLoginAttempt(req, false);
    return sendJson(res, 401, { ok: false, message: "Login code is required." });
  }

  let appState = await getStoredState();
  if (!appState && req.body.seedState?.employees?.length) {
    appState = req.body.seedState;
    await putStoredState(appState);
    await insertBackup(appState, "Initial payroll state created", "System");
  }
  if (!appState?.employees?.length) {
    recordLoginAttempt(req, false);
    return sendJson(res, 409, { ok: false, message: "Payroll database is empty. Sign in as owner first from the seeded app." });
  }

  const role = roleForCode(code);
  if (role) {
    recordLoginAttempt(req, true);
    const actor = role === "Admin" ? "Owner/Admin" : role;
    return sendJson(res, 200, sessionPayload({ role, actor, employeeId: null }, appState));
  }

  const employee = activeEmployees(appState).find((item) => equalsIgnoreCase(item.staffId, code));
  if (!employee) {
    recordLoginAttempt(req, false);
    return sendJson(res, 401, { ok: false, message: "Login code was not accepted." });
  }

  recordLoginAttempt(req, true);
  return sendJson(res, 200, sessionPayload({
    role: "Staff",
    actor: employee.name,
    employeeId: employee.id
  }, appState));
}

async function loadState(req, res) {
  const session = verifySession(req);
  const appState = await getStoredState();
  if (!appState) return sendJson(res, 404, { ok: false, message: "Payroll state was not found." });
  return sendJson(res, 200, { ok: true, state: appState, session });
}

async function saveState(req, res) {
  const session = verifySession(req);
  if (!["Admin", "Manager", "Front Desk"].includes(session.role)) {
    return sendJson(res, 403, { ok: false, message: "This account cannot save payroll database changes." });
  }
  if (!req.body.state?.employees?.length) return sendJson(res, 400, { ok: false, message: "Valid payroll state is required." });
  await putStoredState(req.body.state);
  if (req.body.backupReason) await insertBackup(req.body.state, req.body.backupReason, session.actor || session.role);
  return sendJson(res, 200, { ok: true, savedAt: new Date().toISOString() });
}

async function backupState(req, res) {
  const session = verifySession(req);
  if (!["Admin", "Manager"].includes(session.role)) {
    return sendJson(res, 403, { ok: false, message: "Only Admin or Manager can create server backups." });
  }
  const appState = req.body.state?.employees?.length ? req.body.state : await getStoredState();
  await insertBackup(appState, req.body.reason || "Manual payroll backup", session.actor || session.role);
  return sendJson(res, 200, { ok: true, backedUpAt: new Date().toISOString() });
}

async function sendPayslipsApi(req, res) {
  const setup = setupStatus(["PAYROLL_SESSION_SECRET", "RESEND_API_KEY"]);
  if (!setup.ok) return sendJson(res, 503, { ok: false, setupNeeded: true, message: setup.message, missing: setup.missing });

  let session;
  try {
    session = verifySession(req);
  } catch (error) {
    return sendJson(res, error.statusCode || 401, { ok: false, message: error.message || "Session expired. Please sign in again." });
  }
  if (!["Admin", "Manager"].includes(session.role)) {
    return sendJson(res, 403, { ok: false, message: "Only Admin or Manager can send payslip emails." });
  }

  const payslips = Array.isArray(req.body.payslips) ? req.body.payslips : [];
  if (!payslips.length) return sendJson(res, 400, { ok: false, message: "No payslips were supplied." });

  const results = [];
  for (const payslip of payslips.slice(0, 50)) {
    const result = await sendOnePayslip({
      apiKey: process.env.RESEND_API_KEY,
      from: process.env.PAYSLIP_EMAIL_FROM || "Trudy'z Payroll <TAN_payroll@trudyzamazingnails.com>",
      replyTo: process.env.PAYSLIP_EMAIL_REPLY_TO,
      bcc: process.env.PAYSLIP_EMAIL_BCC,
      payslip,
      runId: req.body.runId
    });
    results.push(result);
  }

  const sent = results.filter((result) => result.sent).length;
  const failed = results.length - sent;
  return sendJson(res, failed ? 207 : 200, {
    ok: failed === 0,
    sent,
    failed,
    results,
    message: failed ? `${sent} payslips sent; ${failed} failed.` : `${sent} payslips sent.`
  });
}

function setupStatus(required) {
  const missing = required.filter((name) => !process.env[name]);
  return {
    ok: missing.length === 0,
    missing,
    message: missing.length ? `Payroll backend setup is missing: ${missing.join(", ")}.` : ""
  };
}

function roleForCode(code) {
  const checks = [
    ["Admin", process.env.PAYROLL_OWNER_CODE],
    ["Manager", process.env.PAYROLL_MANAGER_CODE],
    ["Front Desk", process.env.PAYROLL_FRONT_DESK_CODE]
  ];
  const match = checks.find(([, expected]) => expected && secureEqual(code, expected));
  return match?.[0] || null;
}

function sessionPayload(session, state) {
  return {
    ok: true,
    token: signSession(session),
    role: session.role,
    actor: session.actor,
    employeeId: session.employeeId,
    state
  };
}

function signSession(session) {
  const body = {
    ...session,
    exp: Date.now() + SESSION_TTL_MS,
    iat: Date.now()
  };
  const encoded = base64url(JSON.stringify(body));
  const signature = hmac(encoded);
  return `${encoded}.${signature}`;
}

function verifySession(req) {
  const header = req.get("authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  const [encoded, signature] = token.split(".");
  if (!encoded || !signature || !secureEqual(signature, hmac(encoded))) {
    throw Object.assign(new Error("Session expired. Please sign in again."), { statusCode: 401 });
  }
  const session = JSON.parse(Buffer.from(encoded, "base64url").toString("utf8"));
  if (!session.exp || Date.now() > session.exp) {
    throw Object.assign(new Error("Session expired. Please sign in again."), { statusCode: 401 });
  }
  return session;
}

async function getStoredState() {
  const result = await pool.query("select state from payroll_state where key = $1", [STATE_KEY]);
  return result.rows?.[0]?.state || null;
}

async function putStoredState(state) {
  await pool.query(
    `insert into payroll_state (key, state, updated_at)
     values ($1, $2::jsonb, now())
     on conflict (key)
     do update set state = excluded.state, updated_at = now()`,
    [STATE_KEY, JSON.stringify(state)]
  );
}

async function insertBackup(state, reason, createdBy) {
  await pool.query(
    `insert into payroll_backups (state, reason, created_by, created_at)
     values ($1::jsonb, $2, $3, now())`,
    [JSON.stringify(state), reason, createdBy]
  );
}

async function sendOnePayslip({ apiKey, from, replyTo, bcc, payslip, runId }) {
  if (!isEmail(payslip.to)) {
    return { sent: false, to: payslip.to || "", staffId: payslip.staffId || "", message: "Invalid recipient email." };
  }
  if (!payslip.pdfBase64 || !payslip.filename) {
    return { sent: false, to: payslip.to, staffId: payslip.staffId || "", message: "Missing PDF attachment." };
  }

  const body = {
    from,
    to: [payslip.to],
    subject: payslip.subject || "Your Trudy'z payroll payslip",
    html: payslip.html || "<p>Your PDF payslip is attached.</p>",
    text: payslip.text || "Your PDF payslip is attached.",
    attachments: [{ filename: payslip.filename, content: payslip.pdfBase64 }],
    tags: [
      { name: "type", value: "payslip" },
      { name: "staff_id", value: safeTagValue(payslip.staffId || "unknown") }
    ]
  };

  if (replyTo) body.reply_to = replyTo;
  if (bcc) body.bcc = bcc.split(",").map((value) => value.trim()).filter(Boolean);

  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      "Idempotency-Key": safeIdempotencyKey(`${runId || "payroll"}-${payslip.staffId || payslip.to}`)
    },
    body: JSON.stringify(body)
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    return {
      sent: false,
      to: payslip.to,
      staffId: payslip.staffId || "",
      message: data.message || data.error || "Resend rejected this email."
    };
  }

  return {
    sent: true,
    to: payslip.to,
    staffId: payslip.staffId || "",
    emailId: data.id || "",
    message: "Sent"
  };
}

function assertLoginAllowed(req) {
  const key = req.ip || req.socket.remoteAddress || "unknown";
  const now = Date.now();
  const windowMs = 10 * 60 * 1000;
  const record = loginAttempts.get(key) || { count: 0, first: now };
  if (now - record.first > windowMs) {
    loginAttempts.set(key, { count: 0, first: now });
    return;
  }
  if (record.count >= 12) {
    throw Object.assign(new Error("Too many login attempts. Please wait a few minutes and try again."), { statusCode: 429 });
  }
}

function recordLoginAttempt(req, success) {
  const key = req.ip || req.socket.remoteAddress || "unknown";
  if (success) {
    loginAttempts.delete(key);
    return;
  }
  const now = Date.now();
  const record = loginAttempts.get(key) || { count: 0, first: now };
  record.count += 1;
  loginAttempts.set(key, record);
}

function activeEmployees(state) {
  return (state.employees || []).filter((employee) => employee.status === "Active");
}

function hmac(value) {
  return crypto.createHmac("sha256", process.env.PAYROLL_SESSION_SECRET).update(value).digest("base64url");
}

function base64url(value) {
  return Buffer.from(value).toString("base64url");
}

function secureEqual(a, b) {
  const left = Buffer.from(String(a || ""));
  const right = Buffer.from(String(b || ""));
  if (left.length !== right.length) return false;
  return crypto.timingSafeEqual(left, right);
}

function equalsIgnoreCase(a, b) {
  return String(a || "").trim().toLowerCase() === String(b || "").trim().toLowerCase();
}

function isEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || "").trim());
}

function safeTagValue(value) {
  return String(value).replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 256) || "unknown";
}

function safeIdempotencyKey(value) {
  return String(value).replace(/[^a-zA-Z0-9_.:-]/g, "_").slice(0, 256);
}

function sendJson(res, statusCode, body) {
  return res
    .status(statusCode)
    .set("Cache-Control", "no-store")
    .json(body);
}
