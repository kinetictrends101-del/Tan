#!/bin/sh
set -eu

BACKUP_DIR="${BACKUP_DIR:-backups}"
KEEP_DAYS="${KEEP_DAYS:-30}"
STAMP="$(date -u +%Y%m%d-%H%M%S)"
FILE="$BACKUP_DIR/trudyz-payroll-$STAMP.sql"

mkdir -p "$BACKUP_DIR"

docker compose exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" "$POSTGRES_DB"' > "$FILE"

find "$BACKUP_DIR" -type f -name 'trudyz-payroll-*.sql' -mtime +"$KEEP_DAYS" -delete 2>/dev/null || true

echo "Backup saved: $FILE"
